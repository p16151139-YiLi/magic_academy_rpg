"""Single authoritative Traditional Chinese UI font loader.

A missing font must never silently become SDL's Latin-only default and
produce blank/square Chinese glyphs in the player menu or other UI.
The deployment Colab downloads the OFL-licensed font into assets/fonts
before SDL validation and the pygbag build (font file is not in source ZIP).
"""
from pathlib import Path
import pygame

ROOT = Path(__file__).resolve().parents[1]
FONT_PATH = ROOT / "assets/fonts/NotoSansTC-Regular.ttf"
SYSTEM_FONTS = (
    Path("C:/Windows/Fonts/msjh.ttc"),
    Path("C:/Windows/Fonts/msyh.ttc"),
    Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
    Path("/usr/share/fonts/truetype/arphic/ukai.ttc"),
)


def load_cjk_font(size):
    """Load a font with Chinese glyphs; explain the missing dependency."""
    size = max(10, int(size))
    candidates = (FONT_PATH,) + SYSTEM_FONTS
    for candidate in candidates:
        if not candidate.is_file():
            continue
        try:
            font = pygame.font.Font(str(candidate), size)
            # In SDL_ttf/pygame, an absent glyph has None metrics.
            glyph_metrics = font.metrics('中文學院冒險背包')
            if all(metric is not None for metric in glyph_metrics):
                return font
        except (pygame.error, OSError, ValueError):
            continue
    raise RuntimeError(
        "遊戲缺少可顯示繁體中文的字型。請先執行 "
        "python tools/install_tc_font.py，或使用新版 Colab 部署筆記本；"
        "找不到 assets/fonts/NotoSansTC-Regular.ttf，不能改用預設字型。"
    )
