"""Character overview/attribute upgrade renderer for the six-tab player menu.

V9.8.10: consistent 880x226 logical canvas, no clipped derived stats, alpha-clean
class portraits, and clickable upgrade buttons in the same coordinate system.
"""
from pathlib import Path
import pygame
from systems.character_progression import CharacterProgression, STATS
from ui.font_support import load_cjk_font

ROOT = Path(__file__).resolve().parents[1]
LABELS = {'str':'力量','vit':'體質','int':'智力','spi':'精神','agi':'敏捷','luk':'幸運'}
PORTRAITS = {
    'balanced_mage':'balanced_mage_portrait.png',
    'melee_mage':'melee_mage_portrait.png',
    'ranged_mage':'ranged_mage_portrait.png',
}
PANEL_SIZE = (880, 226)
PORTRAIT_RECT = (18, 35, 120, 140)
# All content is kept inside the panel height. Label baseline ends before 226px.
DERIVED_STATS_Y = 207
STAT_ROWS_Y = (158, 183)
BAR_ROWS_Y = (40, 69, 98)

class StatAllocationPanel:
    def __init__(self):
        self.progress = CharacterProgression()
        self.buttons = {}
        self.fonts = {}
        self._text_cache = {}
        self._portrait_cache = {}
        self.message = ''
        self._snapshot_cache = None

    def invalidate(self):
        self._snapshot_cache = None

    def snapshot(self):
        if self._snapshot_cache is None:
            self._snapshot_cache = self.progress.snapshot()
        return self._snapshot_cache

    def font(self, size):
        size = max(11, int(size))
        if size not in self.fonts:
            self.fonts[size] = load_cjk_font(size)
        return self.fonts[size]

    def _fit(self, value, size, max_width):
        value = str(value)
        f = self.font(size)
        if f.size(value)[0] <= max_width:
            return value
        ellipsis = '…'
        while value and f.size(value + ellipsis)[0] > max_width:
            value = value[:-1]
        return value + ellipsis

    def label(self, surface, value, pos, size=16, color=(241,234,214), max_width=None):
        if max_width is not None:
            value = self._fit(value, size, max_width)
        key = (str(value), int(size), tuple(color))
        glyph = self._text_cache.get(key)
        if glyph is None:
            glyph = self.font(size).render(str(value), True, color)
            if len(self._text_cache) >= 180:
                self._text_cache.clear()
            self._text_cache[key] = glyph
        surface.blit(glyph, (int(pos[0]), int(pos[1])))

    def portrait(self, class_id):
        if class_id not in self._portrait_cache:
            filename = PORTRAITS.get(class_id)
            path = ROOT/'assets/characters/portraits'/filename if filename else None
            result = None
            if path is not None and path.is_file():
                try:
                    loaded = pygame.image.load(str(path))
                    if pygame.display.get_surface() is not None:
                        loaded = loaded.convert_alpha()
                    visible = loaded.get_bounding_rect(min_alpha=12)
                    if visible.width and visible.height:
                        clean = loaded.subsurface(visible).copy()
                        pw, ph = PORTRAIT_RECT[2]-6, PORTRAIT_RECT[3]-6
                        ratio = min(pw/visible.width, ph/visible.height)
                        size = (max(1, round(visible.width*ratio)), max(1, round(visible.height*ratio)))
                        result = pygame.transform.smoothscale(clean, size)
                except (pygame.error, ValueError, OSError) as exc:
                    print('[CHARACTER PORTRAIT ERROR]', path, repr(exc), flush=True)
            self._portrait_cache[class_id] = result
        return self._portrait_cache[class_id]

    def _bar(self, surface, x, y, label, current, maximum, color):
        max_safe = max(1, float(maximum))
        ratio = max(0.0, min(1.0, float(current)/max_safe))
        self.label(surface, f'{label}  {current}/{maximum}', (x+160, y), 15,
                   (232,234,243), max_width=190)
        bx, by, bw, bh = x+370, y+5, 485, 13
        pygame.draw.rect(surface, (17,20,34), (bx,by,bw,bh), border_radius=3)
        fw = round(bw*ratio)
        if fw > 0:
            pygame.draw.rect(surface, color, (bx,by,fw,bh), border_radius=3)
        pygame.draw.rect(surface, (132,136,161), (bx,by,bw,bh), 1, border_radius=3)

    def draw(self, surface, rect):
        r = pygame.Rect(rect)
        if r.size != PANEL_SIZE:
            raise ValueError(f'Character panel requires logical {PANEL_SIZE}, got {r.size}')
        snap = self.snapshot()
        data, stat = snap['player'], snap['stats']
        x,y = r.topleft
        # The widget paints only inside the logical panel, not over menu tabs/back button.
        pygame.draw.rect(surface, (27,29,54), r, border_radius=8)
        pygame.draw.rect(surface, (185,147,87), r, 2, border_radius=8)
        pygame.draw.rect(surface, (46,41,70), (x+11,y+27,136,160),border_radius=6)
        pygame.draw.rect(surface, (145,118,91), (x+11,y+27,136,160),2,border_radius=6)
        pygame.draw.line(surface,(100,87,118),(x+151,y+30),(x+151,y+216),1)
        portrait = self.portrait(data.get('class_id','balanced_mage'))
        if portrait is None:
            self.label(surface,'角色', (x+52,y+90),17)
        else:
            px,py,pw,ph = PORTRAIT_RECT
            surface.blit(portrait, (x+px+(pw-portrait.get_width())//2,
                                    y+py+(ph-portrait.get_height())//2))
        # Long names are truncated; no text can cover the class/level fields.
        self.label(surface,data.get('name','冒險者'),(x+158,y+8),20,(255,219,153),max_width=330)
        self.label(surface,data.get('class_name',''),(x+493,y+12),15,(219,227,241),max_width=208)
        self.label(surface,'Lv.{}'.format(data.get('level',1)),(x+713,y+11),18,(255,218,153),max_width=138)
        self.label(surface,f"金幣：{data.get('gold',0)}",(x+20,y+190),14,(255,220,149),max_width=117)
        self.label(surface,f"可分配：{data.get('unspent_points',0)}",(x+20,y+204),12,(255,220,149),max_width=117)
        self._bar(surface,x,y+BAR_ROWS_Y[0],'HP',data.get('hp',0),stat.get('max_hp',1),(207,83,98))
        self._bar(surface,x,y+BAR_ROWS_Y[1],'MP',data.get('mp',0),stat.get('max_mp',1),(84,139,222))
        self._bar(surface,x,y+BAR_ROWS_Y[2],'EXP',data.get('exp',0),data.get('exp_to_next_level',1),(124,185,118))
        pygame.draw.line(surface,(153,117,84),(x+157,y+130),(x+858,y+130),1)
        self.label(surface,'屬性配點', (x+160,y+135),15,(246,211,149))
        self.buttons = {}
        for i,key in enumerate(STATS):
            col,row = i%3,i//3
            sx=x+160+col*224
            sy=y+STAT_ROWS_Y[row]
            self.label(surface,f"{LABELS[key]}  {data['base_stats'][key]}",(sx,sy),15,
                       (240,229,206),max_width=122)
            btn=pygame.Rect(sx+143,sy-2,25,23)
            pygame.draw.rect(surface,(59,111,80) if data.get('unspent_points',0)>0 else
                             (74,76,91),btn,border_radius=4)
            pygame.draw.rect(surface,(154,156,166),btn,1,border_radius=4)
            self.label(surface,'+', (btn.x+7,btn.y-1),17,(255,247,207))
            self.buttons[key]=btn
        # Previous build printed this at y=208 with taller font, clipping the bottom.
        summary=('物攻 {:g}  魔攻 {:g}  物防 {:g}  魔防 {:g}').format(
            stat['physical_attack'],stat['magic_attack'],
            stat['physical_defense'],stat['magic_defense'])
        self.label(surface,summary,(x+160,y+DERIVED_STATS_Y),12,(213,218,235),max_width=690)
        if self.message:
            self.label(surface,self.message,(x+650,y+135),13,(255,218,148),max_width=200)

    def handle_event(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return False
        for key,rect in self.buttons.items():
            if rect.collidepoint(event.pos):
                result = self.progress.allocate(key)
                self.invalidate()
                self.message = ('已提升'+LABELS[key]) if result else '沒有可分配的點數'
                return True
        return False
