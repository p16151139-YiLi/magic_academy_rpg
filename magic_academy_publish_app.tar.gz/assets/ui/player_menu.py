
import pygame
import json
from pathlib import Path

from ui.character_panel import CharacterPanel
from ui.inventory_panel import InventoryPanel
from ui.stat_allocation_panel import StatAllocationPanel

ROOT = Path(__file__).resolve().parents[1]


class PlayerMenu:

    TABS = [
        "角色資訊",
        "背包",
        "技能樹",
        "任務日誌",
        "世界地圖",
        "操作說明"
    ]

    def __init__(self, screen, draw_text=None):

        self.screen = screen
        self.draw_text = draw_text

        self.opened = False
        self.tab = -1  # -1 is the real six-button parent menu.
        self.hover = -1
        self.home_hover = -1

        self.template = pygame.image.load(
            str(
                ROOT /
                "assets/ui/player_menu/player_menu_template.png"
            )
        ).convert_alpha()

        with open(
            ROOT / "data/ui/controls.json",
            encoding="utf-8"
        ) as f:
            self.controls = json.load(f)

        # The unified stat overview now draws character information directly.
        # Do not allocate an unused second panel/font set on every game entry.
        self.character_info_panel = None
        self.character_panel = CharacterPanel()

        self.inventory_panel = InventoryPanel()
        self.stat_allocation_panel = StatAllocationPanel()

        self.font_path = str(
            ROOT / "assets/fonts/NotoSansTC-Regular.ttf"
        )

        self.fonts = {}

        self.origin = (0, 0)
        self.scale = 1.0
        self._shade_surface = None
        self._shade_size = None
        self._template_scaled = None
        self._template_scaled_size = None
        self._text_cache = {}
        self._tab_overlay_cache = {}
        self._info_canvas = None
        self._info_target = None

    def font(self, size):

        size = max(10, int(size))

        if size not in self.fonts:
            font_path = self.font_path if Path(self.font_path).is_file() else None
            self.fonts[size] = pygame.font.Font(font_path, size)

        return self.fonts[size]

    def _cached_text(self, value, size, color):
        key = (str(value), max(10,int(size)), tuple(color))
        image = self._text_cache.get(key)
        if image is None:
            image = self.font(key[1]).render(key[0], True, key[2])
            if len(self._text_cache) >= 384:
                self._text_cache.clear()
            self._text_cache[key] = image
        return image

    def text(
        self,
        value,
        x,
        y,
        size=22,
        color=(240, 230, 205)
    ):

        surf = self._cached_text(value, size, color)

        self.screen.blit(
            surf,
            (int(x), int(y))
        )

    def rect(self, x, y, w, h):

        ox, oy = self.origin
        s = self.scale

        return pygame.Rect(
            round(ox + x * s),
            round(oy + y * s),
            round(w * s),
            round(h * s)
        )

    def set_layout(self):

        sw, sh = self.screen.get_size()

        self.scale = min(
            sw / 1040,
            sh / 620,
            1.0
        )

        self.origin = (
            (sw - 1000 * self.scale) / 2,
            (sh - 580 * self.scale) / 2
        )

    def inventory_rect(self):
        sw, sh = self.screen.get_size()
        scale = min((sw-20)/1100,(sh-14)/620,1.25)
        w,h=round(1100*scale),round(620*scale)
        return pygame.Rect((sw-w)//2,(sh-h)//2,w,h)

    def inventory_back_rect(self):
        r=self.inventory_rect()
        scale=r.width/1100
        return pygame.Rect(r.x+round(28*scale),r.y+round(24*scale),
                           round(142*scale),round(47*scale))

    def open(self, tab=None):
        if tab is not None:
            self.tab = tab
        elif not self.opened:
            self.tab = -1
        self.opened = True
        if self.tab in (-1, 0) and hasattr(self, "stat_allocation_panel"):
            self.stat_allocation_panel.invalidate()
        if self.tab == 1:
            self.inventory_panel.closed = False
            self.inventory_panel.back_requested = False
            self.inventory_panel.manager.reload()

    def close(self):
        self.opened = False
        self.tab = -1
        self.inventory_panel.closed = False

    def return_from_inventory(self):
        """Keep the original V9.2 two-action design:

        Back returns to the character/player menu; Close exits to the world.
        Both keyboard and mouse use this single transition.
        """
        self.inventory_panel.back_requested = False
        self.inventory_panel.closed = False
        self.tab = -1
        self.opened = True

    def return_home(self):
        """Back means the six-item parent menu; never jump into character info."""
        self.inventory_panel.back_requested = False
        self.inventory_panel.closed = False
        self.tab = -1
        self.opened = True
        if hasattr(self, "stat_allocation_panel"):
            self.stat_allocation_panel.invalidate()

    def handle_key(self, key):
        if not self.opened:
            return False
        if key == pygame.K_TAB:
            self.close()
            return True
        if key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
            if self.tab == -1:
                self.close()
            else:
                self.return_home()
            return True
        shortcuts = {pygame.K_c: 0, pygame.K_i: 1,
                     pygame.K_k: 2, pygame.K_m: 4, pygame.K_h: 5}
        if key in shortcuts:
            requested = shortcuts[key]
            if requested == self.tab:
                self.return_home()
            else:
                self.open(requested)
            return True
        if self.tab == 1 and self.inventory_panel.handle_key(key):
            if self.inventory_panel.back_requested:
                self.return_home()
            elif self.inventory_panel.closed:
                self.close()
            return True
        return False

    def handle_event(self, event):
        """滑鼠事件僅在玩家介面開啟時處理；鍵盤由 GameScene 發送。"""
        if not self.opened:
            return False

        self.set_layout()

        if self.tab != 1 and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect(875, 28, 85, 62).collidepoint(event.pos):
                self.close()
                return True
            if self.tab >= 0 and self.rect(744, 492, 208, 57).collidepoint(event.pos):
                self.return_home()
                return True

        if self.tab == 0 and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            destination=self.rect(58,260,880,226)
            if destination.collidepoint(event.pos):
                logical_x=(event.pos[0]-destination.x)*880/max(1,destination.width)
                logical_y=(event.pos[1]-destination.y)*226/max(1,destination.height)
                logical=pygame.event.Event(pygame.MOUSEBUTTONDOWN,{'button':1,
                    'pos':(round(logical_x),round(logical_y))})
                if self.stat_allocation_panel.handle_event(logical):
                    return True

        if self.tab == 1:
            self.inventory_panel.handle_event(event,self.inventory_rect())
            if self.inventory_panel.back_requested:
                self.return_from_inventory()
            elif self.inventory_panel.closed:
                self.close()
            return True

        if event.type == pygame.MOUSEMOTION:
            self.hover = -1
            self.home_hover = -1
            for i in range(len(self.TABS)):
                rect = self.rect(35 + i * 155, 102, 145, 62)
                if rect.collidepoint(event.pos):
                    self.hover = i
                    break
            if self.tab == -1:
                for i in range(len(self.TABS)):
                    if self._home_card_rect(i).collidepoint(event.pos):
                        self.home_hover = i
                        break
            return True

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i in range(len(self.TABS)):
                rect = self.rect(35 + i * 155, 102, 145, 62)
                if rect.collidepoint(event.pos):
                    self.open(i)  # Use the same initialization path as keyboard switching.
                    return True
            if self.tab == -1:
                for i in range(len(self.TABS)):
                    if self._home_card_rect(i).collidepoint(event.pos):
                        self.open(i)
                        return True
            return True

        return True

    # The same logical card coordinates are used for drawing, hover and clicks.
    def _home_card_rect(self, index):
        return self.rect(70 + (index % 3) * 293,
                         274 + (index // 3) * 104, 269, 91)

    def draw(self):
        """V9.8.42 player codex: ornamental home, real status, legacy controls.

        Coordinates stay in the 1000x580 logical panel; mouse rectangles
        are unchanged, so keyboard, equipment, inventory, and stat clicks
        retain their existing contracts.
        """
        if not self.opened:
            return
        self.set_layout()
        sw, sh = self.screen.get_size()
        s = self.scale
        ox, oy = self.origin

        if self._shade_size != (sw, sh):
            self._shade_surface = pygame.Surface((sw, sh), pygame.SRCALPHA)
            self._shade_surface.fill((3, 5, 18, 190))
            self._shade_size = (sw, sh)
        self.screen.blit(self._shade_surface, (0, 0))

        # The inventory retains its independent, fully interactive panel.
        if self.tab == 1:
            self.inventory_panel.draw(self.screen, self.inventory_rect())
            return

        template_size = (round(1000 * s), round(580 * s))
        if template_size != self._template_scaled_size:
            self._template_scaled = pygame.transform.scale(self.template, template_size)
            self._template_scaled_size = template_size
        self.screen.blit(self._template_scaled, (round(ox), round(oy)))

        GOLD=(242,204,132)
        LIGHT=(246,234,212)
        DIM=(172,166,194)
        BORDER=(153,115,77)
        def txt(value,x,y,size=20,color=LIGHT):
            glyph=self._cached_text(str(value),max(10,round(size*s)),color)
            self.screen.blit(glyph,(round(ox+x*s),round(oy+y*s)))
        def centered(value,rectangle,size=18,color=LIGHT):
            g=self._cached_text(str(value),max(10,round(size*s)),color)
            self.screen.blit(g,g.get_rect(center=rectangle.center))
        def panel(coords,fill=(30,31,56),edge=BORDER,width=1):
            r=self.rect(*coords)
            pygame.draw.rect(self.screen,fill,r,border_radius=max(4,round(8*s)))
            pygame.draw.rect(self.screen,edge,r,max(1,round(width*s)),
                             border_radius=max(4,round(8*s)))
            return r
        def line(x1,y1,x2,y2,color=BORDER,width=1):
            pygame.draw.line(self.screen,color,
                (round(ox+x1*s),round(oy+y1*s)),
                (round(ox+x2*s),round(oy+y2*s)),max(1,round(width*s)))
        def star(cx,cy,color=GOLD,radius=7):
            px=ox+cx*s;py=oy+cy*s;rr=max(2,round(radius*s))
            pygame.draw.line(self.screen,color,(round(px-rr),round(py)),
                             (round(px+rr),round(py)),max(1,round(s)))
            pygame.draw.line(self.screen,color,(round(px),round(py-rr)),
                             (round(px),round(py+rr)),max(1,round(s)))
        def tiny_bar(x,y,w,value,maximum,color):
            maximum=max(1.0,float(maximum))
            ratio=max(0.,min(1.,float(value)/maximum))
            r=self.rect(x,y,w,8)
            pygame.draw.rect(self.screen,(17,21,35),r,border_radius=max(2,round(3*s)))
            filled=self.rect(x,y,max(0,w*ratio),8)
            if filled.width:
                pygame.draw.rect(self.screen,color,filled,border_radius=max(2,round(3*s)))
            pygame.draw.rect(self.screen,(96,85,108),r,1,border_radius=max(2,round(3*s)))

        # New illustrated manuscript-like header, without any new large PNG.
        star(77,55,radius=12)
        txt('冒 險 者 手 冊',106,29,28,(255,219,152))
        txt('MAGIC ACADEMY  /  THE LOST ANCIENT MAGIC',109,65,11,(169,160,186))
        line(526,58,853,58,(93,77,103))
        close=self.rect(875,28,85,62)
        pygame.draw.rect(self.screen,(78,43,63),close,border_radius=max(3,round(7*s)))
        pygame.draw.rect(self.screen,(221,174,111),close,max(1,round(2*s)),
                         border_radius=max(3,round(7*s)))
        self._cached_text('關閉', max(10,round(17*s)), (255,231,196))
        centered('關閉 ×',close,17,(255,231,196))

        # Top navigation remains keyboard+mouse addressable at legacy geometry.
        for i,name in enumerate(self.TABS):
            r=self.rect(35+i*155,102,145,62)
            active=i==self.tab
            hover=i==self.hover or (self.tab==-1 and i==self.home_hover)
            color=(83,57,108) if active else (55,50,82) if hover else (30,30,54)
            edge=(247,209,137) if active else (179,143,99) if hover else (87,78,107)
            pygame.draw.rect(self.screen,color,r,border_radius=max(4,round(7*s)))
            pygame.draw.rect(self.screen,edge,r,max(1,round((2 if active else 1)*s)),
                             border_radius=max(4,round(7*s)))
            if active:
                underline=self.rect(53+i*155,160,108,3)
                pygame.draw.rect(self.screen,(241,190,103),underline)
            centered(name,r,17,(255,223,169) if active else (221,213,219))

        heading=self.TABS[self.tab] if self.tab>=0 else '旅程總覽'
        txt(heading,74,198,26,(251,218,154))
        descriptions={-1:'冒險者的成長、裝備與學院紀錄',0:'確認能力、分配點數',
                      2:'魔法技能與成長規劃',3:'追蹤主線與支線',
                      4:'探索學院的各個區域',5:'移動、快捷鍵與互動'}
        txt(descriptions.get(self.tab,''),318,211,14,(192,185,204))
        line(71,238,928,238,(126,100,99))
        star(944,238,(202,158,98),5)

        if self.tab==-1:
            # A live profile strip from the existing CharacterProgression data.
            # Do not show fictional abilities, locations or statistics.
            try:
                data=self.stat_allocation_panel.snapshot()
                player=data['player'];stats=data['stats']
                name=str(player.get('name','冒險者'))
                level=int(player.get('level',1))
                gold=int(player.get('gold',0))
                hp=player.get('hp',0);max_hp=stats.get('max_hp',1)
                mp=player.get('mp',0);max_mp=stats.get('max_mp',1)
                exp=player.get('exp',0);max_exp=player.get('exp_to_next_level',1)
            except (OSError, KeyError, ValueError, TypeError):
                name='冒險者';level=1;gold=0
                hp=max_hp=mp=max_mp=exp=max_exp=0
            panel((71,245,857,24),(44,39,67),(113,91,101))
            label=f'{name[:9]}    Lv.{level}    金幣 {gold}'
            txt(label,83,248,13,(245,224,184))
            txt('HP',425,249,12,(244,171,161))
            tiny_bar(455,252,100,hp,max_hp,(201,86,105))
            txt('MP',567,249,12,(162,187,251))
            tiny_bar(595,252,100,mp,max_mp,(87,148,232))
            txt('EXP',706,249,12,(171,220,173))
            tiny_bar(747,252,164,exp,max_exp,(135,191,120))

            # Six genuine clickable entries (the same rects are used in input).
            names=('角色資訊','背包','技能樹','任務日誌','世界地圖','操作說明')
            subtitles=('狀態  •  屬性配點','道具  •  裝備  •  快捷列',
                       '魔法研究  •  規劃中','任務紀錄  •  規劃中',
                       '區域資訊  •  規劃中','遊戲按鍵  •  操作指引')
            tags=('C','I','K','誌','M','H')
            for i,name in enumerate(names):
                r=self._home_card_rect(i)
                active=i==self.home_hover
                pygame.draw.rect(self.screen,(77,57,102) if active else (35,33,60),r,
                                 border_radius=max(4,round(8*s)))
                pygame.draw.rect(self.screen,(243,202,121) if active else (132,104,108),r,
                                 max(1,round((2 if active else 1)*s)),
                                 border_radius=max(4,round(8*s)))
                cx=83+(i%3)*293
                cy=289+(i//3)*104
                tile=panel((cx,cy,51,55),(66,52,87),(182,141,97))
                star(cx+25,cy+13,(226,175,98),7)
                centered(tags[i],self.rect(cx,cy+17,51,33),15,(255,225,160))
                xx=149+(i%3)*293
                yy=287+(i//3)*104
                txt(name,xx,yy,19,(254,229,184))
                txt(subtitles[i],xx,yy+35,13,(188,187,205))

        elif self.tab==0:
            # Existing attribute widget owns *all* upgrade hit geometry.
            if self._info_canvas is None:
                self._info_canvas=pygame.Surface((880, 226), pygame.SRCALPHA)
            self._info_canvas.fill((0,0,0,0))
            self.stat_allocation_panel.draw(self._info_canvas,
                                            pygame.Rect(0,0,880,226))
            dest=self.rect(58,260,880,226)
            scaled=(self._info_canvas if dest.size==(880,226) else
                    pygame.transform.scale(self._info_canvas,dest.size))
            self.screen.blit(scaled,dest.topleft)

        elif self.tab==5:
            for i,(key,description) in enumerate(self.controls):
                col,row=i//5,i%5
                xx=70+col*435;yy=269+row*42
                panel((xx,yy,416,37),(34,36,61),(91,81,105))
                txt(key,xx+12,yy+8,15,(248,211,144))
                txt(description,xx+180,yy+8,13,(228,223,235))
        else:
            # Keep unavailable functionality honest and non-interactive.
            panel((75,277,850,185),(34,35,62),(126,102,119))
            star(130,366,(231,187,109),19)
            text_for={2:('技能樹尚未開放','目前可先在角色資訊查看屬性與配點。'),
                      3:('任務日誌尚未開放','NPC 對話維持正常，日誌功能仍待製作。'),
                      4:('世界地圖尚未開放','六張已完成的場景仍能透過出入口探索。')}
            main,sub=text_for.get(self.tab,('功能準備中',''))
            txt(main,183,322,24,(248,212,149))
            txt(sub,184,376,16,(207,208,224))

        if self.tab>=0:
            back=self.rect(744,492,208,57)
            pygame.draw.rect(self.screen,(69,48,94),back,border_radius=max(4,round(7*s)))
            pygame.draw.rect(self.screen,(235,189,110),back,max(1,round(2*s)),
                             border_radius=max(4,round(7*s)))
            self._cached_text('返回選單', max(10,round(18*s)), (255,235,199))
            centered('返回選單',back,18,(255,235,199))
            txt('ESC 返回   ·   TAB 關閉',74,513,14,(184,179,201))
        else:
            txt('TAB 關閉   /   ESC 返回遊戲',75,507,14,(195,187,211))
            txt('ADVENTURER  •  MAGICAL CODEX',617,535,11,(171,159,183))
