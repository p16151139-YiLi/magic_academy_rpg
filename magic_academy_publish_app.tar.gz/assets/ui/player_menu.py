
import pygame
import json
from pathlib import Path

from ui.character_panel import CharacterPanel
from ui.inventory_panel import InventoryPanel
from ui.stat_allocation_panel import StatAllocationPanel

ROOT = Path(__file__).resolve().parents[1]


class PlayerMenu:

    TABS = [
        "角色資訊",
        "背包",
        "技能樹",
        "任務日誌",
        "世界地圖",
        "操作說明"
    ]

    def __init__(self, screen, draw_text=None):

        self.screen = screen
        self.draw_text = draw_text

        self.opened = False
        self.tab = -1  # -1 is the real six-button parent menu.
        self.hover = -1
        self.home_hover = -1

        self.template = pygame.image.load(
            str(
                ROOT /
                "assets/ui/player_menu/player_menu_template.png"
            )
        ).convert_alpha()

        with open(
            ROOT / "data/ui/controls.json",
            encoding="utf-8"
        ) as f:
            self.controls = json.load(f)

        # The unified stat overview now draws character information directly.
        # Do not allocate an unused second panel/font set on every game entry.
        self.character_info_panel = None
        self.character_panel = CharacterPanel()

        self.inventory_panel = InventoryPanel()
        self.stat_allocation_panel = StatAllocationPanel()

        self.font_path = str(
            ROOT / "assets/fonts/NotoSansTC-Regular.ttf"
        )

        self.fonts = {}

        self.origin = (0, 0)
        self.scale = 1.0
        self._shade_surface = None
        self._shade_size = None
        self._template_scaled = None
        self._template_scaled_size = None
        self._text_cache = {}
        self._tab_overlay_cache = {}
        self._info_canvas = None
        self._info_target = None

    def font(self, size):

        size = max(10, int(size))

        if size not in self.fonts:
            font_path = self.font_path if Path(self.font_path).is_file() else None
            self.fonts[size] = pygame.font.Font(font_path, size)

        return self.fonts[size]

    def _cached_text(self, value, size, color):
        key = (str(value), max(10,int(size)), tuple(color))
        image = self._text_cache.get(key)
        if image is None:
            image = self.font(key[1]).render(key[0], True, key[2])
            if len(self._text_cache) >= 384:
                self._text_cache.clear()
            self._text_cache[key] = image
        return image

    def text(
        self,
        value,
        x,
        y,
        size=22,
        color=(240, 230, 205)
    ):

        surf = self._cached_text(value, size, color)

        self.screen.blit(
            surf,
            (int(x), int(y))
        )

    def rect(self, x, y, w, h):

        ox, oy = self.origin
        s = self.scale

        return pygame.Rect(
            round(ox + x * s),
            round(oy + y * s),
            round(w * s),
            round(h * s)
        )

    def set_layout(self):

        sw, sh = self.screen.get_size()

        self.scale = min(
            sw / 1040,
            sh / 620,
            1.0
        )

        self.origin = (
            (sw - 1000 * self.scale) / 2,
            (sh - 580 * self.scale) / 2
        )

    def inventory_rect(self):
        sw, sh = self.screen.get_size()
        scale = min((sw-20)/1100,(sh-14)/620,1.25)
        w,h=round(1100*scale),round(620*scale)
        return pygame.Rect((sw-w)//2,(sh-h)//2,w,h)

    def inventory_back_rect(self):
        r=self.inventory_rect()
        scale=r.width/1100
        return pygame.Rect(r.x+round(28*scale),r.y+round(24*scale),
                           round(142*scale),round(47*scale))

    def open(self, tab=None):
        if tab is not None:
            self.tab = tab
        elif not self.opened:
            self.tab = -1
        self.opened = True
        if self.tab == 0 and hasattr(self, "stat_allocation_panel"):
            self.stat_allocation_panel.invalidate()
        if self.tab == 1:
            self.inventory_panel.closed = False
            self.inventory_panel.back_requested = False
            self.inventory_panel.manager.reload()

    def close(self):
        self.opened = False
        self.tab = -1
        self.inventory_panel.closed = False

    def return_from_inventory(self):
        """Keep the original V9.2 two-action design:

        Back returns to the character/player menu; Close exits to the world.
        Both keyboard and mouse use this single transition.
        """
        self.inventory_panel.back_requested = False
        self.inventory_panel.closed = False
        self.tab = -1
        self.opened = True

    def return_home(self):
        """Back means the six-item parent menu; never jump into character info."""
        self.inventory_panel.back_requested = False
        self.inventory_panel.closed = False
        self.tab = -1
        self.opened = True

    def handle_key(self, key):
        if not self.opened:
            return False
        if key == pygame.K_TAB:
            self.close()
            return True
        if key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
            if self.tab == -1:
                self.close()
            else:
                self.return_home()
            return True
        shortcuts = {pygame.K_c: 0, pygame.K_i: 1,
                     pygame.K_k: 2, pygame.K_m: 4, pygame.K_h: 5}
        if key in shortcuts:
            requested = shortcuts[key]
            if requested == self.tab:
                self.return_home()
            else:
                self.open(requested)
            return True
        if self.tab == 1 and self.inventory_panel.handle_key(key):
            if self.inventory_panel.back_requested:
                self.return_home()
            elif self.inventory_panel.closed:
                self.close()
            return True
        return False

    def handle_event(self, event):
        """滑鼠事件僅在玩家介面開啟時處理；鍵盤由 GameScene 發送。"""
        if not self.opened:
            return False

        self.set_layout()

        if self.tab != 1 and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect(875, 28, 85, 62).collidepoint(event.pos):
                self.close()
                return True
            if self.tab >= 0 and self.rect(744, 492, 208, 57).collidepoint(event.pos):
                self.return_home()
                return True

        if self.tab == 0 and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            destination=self.rect(58,260,880,226)
            if destination.collidepoint(event.pos):
                logical_x=(event.pos[0]-destination.x)*880/max(1,destination.width)
                logical_y=(event.pos[1]-destination.y)*226/max(1,destination.height)
                logical=pygame.event.Event(pygame.MOUSEBUTTONDOWN,{'button':1,
                    'pos':(round(logical_x),round(logical_y))})
                if self.stat_allocation_panel.handle_event(logical):
                    return True

        if self.tab == 1:
            self.inventory_panel.handle_event(event,self.inventory_rect())
            if self.inventory_panel.back_requested:
                self.return_from_inventory()
            elif self.inventory_panel.closed:
                self.close()
            return True

        if event.type == pygame.MOUSEMOTION:
            self.hover = -1
            self.home_hover = -1
            for i in range(len(self.TABS)):
                rect = self.rect(35 + i * 155, 102, 145, 62)
                if rect.collidepoint(event.pos):
                    self.hover = i
                    break
            if self.tab == -1:
                for i in range(len(self.TABS)):
                    if self._home_card_rect(i).collidepoint(event.pos):
                        self.home_hover = i
                        break
            return True

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i in range(len(self.TABS)):
                rect = self.rect(35 + i * 155, 102, 145, 62)
                if rect.collidepoint(event.pos):
                    self.open(i)  # Use the same initialization path as keyboard switching.
                    return True
            if self.tab == -1:
                for i in range(len(self.TABS)):
                    if self._home_card_rect(i).collidepoint(event.pos):
                        self.open(i)
                        return True
            return True

        return True

    # The same logical card coordinates are used for drawing, hover and clicks.
    def _home_card_rect(self, index):
        return self.rect(70 + (index % 3) * 293,
                         274 + (index // 3) * 104, 269, 91)

    def draw(self):
        if not self.opened:
            return
        self.set_layout()
        sw, sh = self.screen.get_size()
        s = self.scale
        ox, oy = self.origin

        if self._shade_size != (sw, sh):
            self._shade_surface = pygame.Surface((sw, sh), pygame.SRCALPHA)
            self._shade_surface.fill((3, 5, 18, 176))
            self._shade_size = (sw, sh)
        self.screen.blit(self._shade_surface, (0, 0))

        # Inventory is its own full-scale interactive layout. Keep its Back/Close
        # contract, equipment slots, item quantities and quickbar bindings.
        if self.tab == 1:
            self.inventory_panel.draw(self.screen, self.inventory_rect())
            return

        template_size = (round(1000 * s), round(580 * s))
        if template_size != self._template_scaled_size:
            self._template_scaled = pygame.transform.scale(self.template, template_size)
            self._template_scaled_size = template_size
        self.screen.blit(self._template_scaled, (round(ox), round(oy)))

        def txt(value, x, y, size=22, color=(241, 230, 210)):
            glyph = self._cached_text(value, max(10, round(size * s)), color)
            self.screen.blit(glyph,(round(ox + x*s), round(oy + y*s)))

        def panel(rect, fill=(32, 31, 57), edge=(155, 124, 83), width=1):
            target = self.rect(*rect)
            pygame.draw.rect(self.screen,fill,target,border_radius=max(3,round(8*s)))
            pygame.draw.rect(self.screen,edge,target,max(1,round(width*s)),
                             border_radius=max(3,round(8*s)))
            return target

        # Title and top-level navigation remain visible on every non-inventory tab.
        txt('魔法學院   /   冒險者手冊',119,35,25,(253,220,152))
        txt('THE LOST ANCIENT MAGIC',119,65,12,(172,161,189))
        close_rect = self.rect(875, 28, 85, 62)
        pygame.draw.rect(self.screen,(76,39,56),close_rect,border_radius=7)
        pygame.draw.rect(self.screen,(205,152,96),close_rect,2,border_radius=7)
        close_label = self._cached_text('關閉', max(10, round(19*s)), (255,233,196))
        self.screen.blit(close_label,close_label.get_rect(center=close_rect.center))

        for i,name in enumerate(self.TABS):
            r=self.rect(35+i*155,102,145,62)
            active=i==self.tab
            hover=i==self.hover
            pygame.draw.rect(self.screen,(92,67,108) if active else
                             (61,52,80) if hover else (35,35,61),r,
                             border_radius=max(4,round(7*s)))
            pygame.draw.rect(self.screen,(250,206,126) if active else
                             (161,133,105) if hover else (87,78,105),r,
                             max(1,round((2 if active else 1)*s)),
                             border_radius=max(4,round(7*s)))
            if active:
                underline=self.rect(52+i*155,160,111,3)
                pygame.draw.rect(self.screen,(244,195,103),underline)
            label=self._cached_text(name,max(10,round(18*s)),
                                    (255,229,168) if active else (226,216,216))
            self.screen.blit(label,label.get_rect(center=r.center))

        title=self.TABS[self.tab] if self.tab>=0 else '旅程總覽'
        txt(title,75,205,26,(252,216,145))
        descriptions={-1:'選擇要開啟的冒險功能',0:'角色狀態與屬性配點',
                      2:'查看魔法成長與技能規劃',3:'追蹤主線與支線進度',
                      4:'探索魔法學院的世界',5:'移動與互動快捷鍵'}
        txt(descriptions.get(self.tab,''),325,215,15,(172,171,195))

        if self.tab == -1:
            # 3×2 clickable function cards; not decorative, each opens its page.
            subtitles=('能力值 · 配點','道具 · 裝備','法術 · 成長',
                       '冒險 · 目標','探索 · 區域','按鍵 · 操作')
            symbols=('I','II','III','IV','V','VI')
            for i,name in enumerate(self.TABS):
                r=self._home_card_rect(i)
                active=i==self.home_hover
                pygame.draw.rect(self.screen,(68,57,93) if active else (36,35,63),r,
                                 border_radius=max(4,round(8*s)))
                pygame.draw.rect(self.screen,(237,193,112) if active else (108,92,115),r,
                                 max(1,round((2 if active else 1)*s)),
                                 border_radius=max(4,round(8*s)))
                glyph_box=self.rect(83+(i%3)*293,289+(i//3)*104,51,55)
                pygame.draw.rect(self.screen,(79,62,97),glyph_box,
                                 border_radius=max(3,round(6*s)))
                pygame.draw.rect(self.screen,(171,134,96),glyph_box,1,
                                 border_radius=max(3,round(6*s)))
                mark=self._cached_text(symbols[i],max(10,round(16*s)),(248,213,151))
                self.screen.blit(mark,mark.get_rect(center=glyph_box.center))
                xx=147+(i%3)*293; yy=287+(i//3)*104
                txt(name,xx,yy,20,(252,226,180))
                txt(subtitles[i],xx,yy+34,14,(184,181,203))

        elif self.tab == 0:
            # Stable logical panel: text and clickable upgrade buttons share
            # the same 880×226 coordinate mapping, including at 960×540.
            try:
                if self._info_canvas is None:
                    self._info_canvas = pygame.Surface((880, 226), pygame.SRCALPHA)
                self._info_canvas.fill((0, 0, 0, 0))
                self.stat_allocation_panel.draw(self._info_canvas,
                                                pygame.Rect(0, 0, 880, 226))
                dest=self.rect(58,260,880,226)
                if dest.size!=(880,226):
                    scaled=pygame.transform.scale(self._info_canvas,dest.size)
                else:
                    scaled=self._info_canvas
                self.screen.blit(scaled,dest.topleft)
            except Exception as exc:
                raise RuntimeError('PlayerMenu character tab rendering failed '
                                   f'({type(exc).__name__}: {exc})') from exc

        elif self.tab == 5:
            # Two columns prevent the last controls from overlapping Back.
            for i,(key,description) in enumerate(self.controls):
                col,row=i//5,i%5
                xx=70+col*435; yy=269+row*42
                panel((xx,yy,416,37),(35,39,65),(71,69,94))
                txt(key,xx+12,yy+8,15,(248,209,131))
                txt(description,xx+180,yy+8,13,(225,223,231))
        else:
            # These three features are intentionally non-interactive until
            # implemented, rather than drawing fake active controls.
            panel((75,277,850,185),(35,37,67),(105,94,128))
            text_for={2:('技能樹正在準備中','目前仍可使用角色資訊檢視能力值與配點。'),
                      3:('任務日誌正在準備中','現有 NPC 任務與對話功能保留，日誌介面尚未開放。'),
                      4:('世界地圖正在準備中','可透過遊戲場景中的出入口探索學院區域。')}
            main,sub=text_for.get(self.tab,('功能準備中',''))
            txt(main,113,312,24,(243,211,151))
            txt(sub,113,371,17,(212,214,233))

        if self.tab>=0:
            back=self.rect(744,492,208,57)
            pygame.draw.rect(self.screen,(65,48,89),back,border_radius=7)
            pygame.draw.rect(self.screen,(235,185,103),back,2,border_radius=7)
            label=self._cached_text('返回選單',max(12,round(18*s)),(255,233,196))
            self.screen.blit(label,label.get_rect(center=back.center))
            txt('Esc 返回  ·  Tab 關閉',73,512,15,(183,175,198))
        else:
            txt('Tab 關閉    /    Esc 返回遊戲',72,508,15,(188,183,204))
            txt('MAGIC ACADEMY  •  PLAYER MENU',591,531,11,(160,151,172))
