"""Library seated NPC head overlap is VISUAL ONLY and does not add physical walls."""
from systems.occlusion_fade import player_visual_box,rectangles_overlap

def npc_head_fade_alpha(player_rect,npc_position,visible_height=94):
    """Let player be visible when its sprite overlaps a seated NPC's head.

    The player's foot collision box is 24x18. Only when player feet are BEHIND
    the seated actor's seat depth is the seated sprite made translucent.
    Physical chair blockers stay unchanged.
    """
    px,py,pw,ph=map(int,player_rect)
    nx,ny=map(int,npc_position)
    player_feet=py+ph+7
    if player_feet>=ny-8:
        return 255
    # Head rectangle: top half of the 94px seated character (not whole sprite).
    head_box=(nx-30,ny-visible_height,60,52)
    return 164 if rectangles_overlap(player_visual_box((px,py,pw,ph)),head_box) else 255
