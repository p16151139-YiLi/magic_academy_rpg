"""Phase 8: real AI-generated sprites, offline dynamic NPCs, and synced shops.
No procedural character drawings; game logic handles AI, interaction and inventory.
"""
import json
from pathlib import Path
import pygame
from systems.npc_ai.ai_controller import Agent
from systems.npc_sprite_library import NPCSpriteLibrary
from systems.chair_system import ChairSystem
from systems.save_store import read_json, write_json
from systems.occlusion_fade import should_fade, ease_alpha

ROOT=Path(__file__).resolve().parents[1]
WORLD_PATH=ROOT/'data/player/world_state.json'

class NPCShopSystem:
    GOODS={
      'item_shop':[('hp_potion_small',30),('mp_potion_small',40),('mana_crystal',35),('mana_ring',125),('academy_medal',145)],
      'weapon_shop':[('apprentice_staff',120),('magic_blade',180),('apprentice_robe',100),('academy_boots',85)],
    }
    SHOP_NAMES={'item_shop':'星露雜貨店','weapon_shop':'赤鐵武器鋪'}

    def __init__(self,scene):
        self.scene=scene
        self.agents={}
        self.positions={}
        self.dialogue=None
        self.shop=None
        self.selected=0
        self.notice=''
        self.notice_timer=0
        self.font=scene.ctx.font_small
        self.sprites=NPCSpriteLibrary()
        self.chairs=ChairSystem(ROOT)
        self.quests=read_json(WORLD_PATH,{'ancient_record':False})
        # Bundle source stays fixed even if tests redirect save ROOT to a temp folder.
        profile_file=Path(__file__).resolve().parents[1]/'data/npcs/dialogue_profiles.json'
        self.dialogue_profiles=json.loads(profile_file.read_text(encoding='utf-8'))['profiles']
        self.time=0.0
        self.item_service=scene.get_item_service()
        self.item_service.grant_starting_gold_once()
        self.icons={}
        self.click_rows=[]
        self.close_rect=pygame.Rect(0,0,0,0)
        self.buy_rect=pygame.Rect(0,0,0,0)
        self._fade_cache={}
        self._occluder_masks={}
        self._player_occlusion_alpha=255.0
        self._player_overlay_pending=False
        self._player_fade_surface=None
        self._occlusion_dt=1/60
        try:
            self._actor_mask=pygame.mask.Mask((58,93),fill=True)
        except Exception:
            # pygame.mask unavailable in a minimal test shim or browser.
            self._actor_mask=None

    def npcs(self):
        return [n for n in self.scene.map_data.get('npcs',[])
                if not n.get('requires_quest') or self.quests.get(n['requires_quest'])]

    def agent(self,npc):
        key=self.scene.map_id,npc['id']
        if key not in self.agents:
            self.agents[key]=Agent(npc,self.scene.map_id,npc['position'])
        return self.agents[key]

    def seat_for_npc(self,npc):
        """Return the one authoritative chair assigned to a seated NPC."""
        seat_id = npc.get('seat_id')
        matching = [chair for chair in self.scene.map_data.get('chairs', [])
                    if chair.get('id') == seat_id]
        if len(matching) != 1 or matching[0].get('occupied_by') != npc['id']:
            raise ValueError(f"NPC {npc['id']} 缺少正確的座位對應：{seat_id}")
        if matching[0].get('facing') != npc.get('facing'):
            raise ValueError(
                f"NPC {npc['id']} 坐姿方向與椅子不一致："
                f"NPC={npc.get('facing')} / chair={matching[0].get('facing')}"
            )
        return matching[0]

    def pos(self,npc):
        # The chair is the source of truth for seated actors. A stale NPC JSON
        # point can never separate the seated sprite from its assigned chair.
        if npc.get('pose') == 'sit':
            return pygame.Vector2(self.seat_for_npc(npc)['seat_anchor'])
        if npc.get('behavior')=='utility':
            return self.agent(npc).pos
        return pygame.Vector2(npc['position'])

    def seat_visual_offset(self,npc):
        """Only the chair can decide its occupied sprite's visual alignment.

        Position used for interaction/pathfinding remains the seat anchor;
        screen-space feet are adjusted once, not twice by separate NPC JSON.
        """
        chair=self.seat_for_npc(npc)
        return int(chair.get('seated_foot_offset_y', 0))

    def npc_obstacles(self):
        # Seated characters already occupy furniture/benches drawn in the map.
        # Duplicating a collision around their chair blocks otherwise open aisles.
        return [pygame.Rect(round(self.pos(n).x-10),round(self.pos(n).y-6),20,13)
                for n in self.npcs() if n.get('pose') != 'sit']

    def update(self,dt):
        self._occlusion_dt=max(0.0,min(float(dt),0.1))
        self.time+=dt
        self.notice_timer=max(0,self.notice_timer-dt)
        if self.dialogue or self.shop or self.scene.player_menu.opened:return
        current=self.npcs()
        # A seated NPC is anchored to a chair and must never enter the AI
        # movement/turning loop, even if legacy map data still says utility.
        agents=[self.agent(n) for n in current
                if n.get('behavior')=='utility' and n.get('pose')!='sit']
        obstacles=self.scene.player_world.get_obstacles()
        # Give moving characters visual breathing room from bookcases/tables.
        # The player still uses the original exact solid colliders.
        obstacles=[r.inflate(20,18) for r in obstacles]
        # Free-roaming NPCs do not wander onto doorway thresholds or crowd
        # students already sitting on benches, desks or reading chairs.
        for exit_data in self.scene.map_manager.get_exits():
            rect=self.scene.player_world.get_exit_rect(exit_data)
            if rect:
                obstacles.append(rect.inflate(26, 25))
        for npc in current:
            if npc.get('behavior') != 'utility':
                p=self.pos(npc)
                size=(48, 36) if npc.get('pose') == 'sit' else (26, 20)
                obstacles.append(pygame.Rect(round(p.x-size[0]/2),round(p.y-size[1]/2),*size))
        bounds=pygame.Rect(0,0,self.scene.map_data['width'],self.scene.map_data['height'])
        player=pygame.Vector2(self.scene.player.rect.center)
        for agent in agents:
            agent.update(dt,obstacles,bounds,player,agents)

    def nearby(self):
        player=pygame.Vector2(self.scene.player.rect.center)
        options=[]
        for npc in self.npcs():
            d=player.distance_to(self.pos(npc))
            radius=float(npc.get('interaction_radius',95))
            if d<radius:
                # closer by relative interaction range; merchants behind counters remain accessible
                options.append((d/max(1,radius),d,npc))
        return min(options,key=lambda item:(item[0],item[1]))[2] if options else None

    def _profile(self, npc):
        return self.dialogue_profiles.get(npc.get('dialogue_profile',npc['id']), {})

    def actor_state(self,npc):
        """Shared three-state game model; controller determines which state."""
        if npc.get('pose')=='sit':
            return 'sitting'
        if npc.get('behavior')=='utility' and self.agent(npc).moving:
            return 'moving'
        return 'standing'

    def _activity(self, npc):
        """Return what the NPC is ACTUALLY doing now, never a scripted guess.

        Movement and intent are observable Agent state. Static workers declare
        a map-specific activity that matches their standing/seated sprite.
        """
        if npc.get('behavior') == 'utility':
            agent=self.agent(npc)
            if agent.moving:
                return 'patrol' if npc.get('role') in ('guard','patrol') else 'walk'
            intent=agent.intent
            if intent == 'explore' and agent.route:
                return 'walk'
            if intent == 'explore':
                return 'idle'
            if intent == 'social' and npc.get('role') in ('guard','patrol'):
                return 'observe'
            return intent if intent in ('rest','observe','social','review','idle') else 'idle'
        return npc.get('activity','idle')

    def _activity_line(self, npc, activity):
        profile=self._profile(npc)
        activities=profile.get('activity',{})
        return (activities.get(activity) or activities.get('idle')
                or next(iter(activities.values()), '我正在處理自己手邊的事。'))

    def _conversation_choices(self, npc):
        profile=self._profile(npc)
        choices=profile.get('choices')
        if choices:
            return [(str(label),str(action)) for label,action in choices]
        return [('你現在在忙什麼？','activity'),('最近有什麼消息？','rumor'),('再見','leave')]

    def _reply_text(self,npc,action,activity):
        if action=='activity':
            return self._activity_line(npc,activity)
        reply=self._profile(npc).get('replies',{}).get(action)
        if isinstance(reply,dict):
            return (reply.get(activity) or reply.get('default')
                    or self._activity_line(npc,activity))
        if isinstance(reply,str) and reply:
            return reply
        return self._activity_line(npc,activity)

    def _choose_dialogue(self):
        d=self.dialogue
        if d is None:
            return
        npc=d['npc']
        choices=self._conversation_choices(npc)
        selected=min(max(d.get('selected',0),0),len(choices)-1)
        _,action=choices[selected]
        if action=='leave':
            self.dialogue=None
            return
        if action=='shop':
            self.dialogue=None
            self.shop=npc.get('shop')
            self.selected=0
            self.notice=''
            return
        if action=='quest':
            already=self.quests.get('ancient_record',False)
            if not already:
                self.quests['ancient_record']=True
                write_json(WORLD_PATH,self.quests)
                text='謝謝你願意協助調查。請到一樓圖書館尋找古代魔法的記錄。'
            else:
                text='調查還在進行中。請先到圖書館尋找線索，再回來告訴我。'
        else:
            # The activity is captured at the start of interaction. An NPC
            # does not suddenly claim to be walking while the dialogue freezes it.
            text=self._reply_text(npc,action,d.get('activity','idle'))
        d['mode']='reply'
        d['reply']=text

    def interact(self):
        if self.shop:
            return True
        if self.dialogue:
            d = self.dialogue
            if d['mode'] == 'lines':
                d['index'] += 1
                if d['index'] >= len(d['lines']):
                    d['mode'] = 'choices'
                    d['selected'] = 0
            elif d['mode'] == 'choices':
                self._choose_dialogue()
            else:
                d['mode'] = 'choices'
            return True
        npc = self.nearby()
        if npc is None:
            return False
        activity=self._activity(npc)
        profile=self._profile(npc)
        intro=profile.get('greeting') or (npc.get('dialogue') or ['你好。'])[0]
        detail=self._activity_line(npc,activity)
        # 2 context-matched lines only, so the dialogue panel stays readable.
        lines=[intro,detail] if detail!=intro else [intro]
        if npc.get('behavior') == 'utility':
            moving_agent=self.agent(npc)
            moving_agent.pause_for_dialogue(
                pygame.Vector2(self.scene.player.rect.center))
        self.dialogue = {'npc': npc, 'index': 0, 'lines': lines,
                         'activity':activity,
                         'selected': 0, 'mode': 'lines', 'reply': ''}
        self.shop = None
        return True

    def buy_selected(self):
        if not self.shop:return False
        item_id,price=self.GOODS[self.shop][self.selected]
        result=self.item_service.buy_item(item_id,price)
        self.notice=result['message'];self.notice_timer=2.4
        self.scene.player_world.show_message(result['message'])
        if result['success']:
            # Same InventoryManager object is shared by bag UI and shop.
            self.scene.player_menu.inventory_panel.manager.reload()
        return result['success']

    def handle_key(self, key):
        if self.dialogue:
            d = self.dialogue
            if key in (pygame.K_ESCAPE, pygame.K_BACKSPACE, pygame.K_TAB):
                self.dialogue = None
            elif d['mode'] == 'choices' and key in (pygame.K_DOWN, pygame.K_s):
                d['selected'] = (d['selected'] + 1) % len(self._conversation_choices(d['npc']))
            elif d['mode'] == 'choices' and key in (pygame.K_UP, pygame.K_w):
                d['selected'] = (d['selected'] - 1) % len(self._conversation_choices(d['npc']))
            elif d['mode'] == 'choices' and key in (pygame.K_1, pygame.K_2, pygame.K_3):
                d['selected'] = min(key-pygame.K_1, len(self._conversation_choices(d['npc']))-1)
                self._choose_dialogue()
            elif key in (pygame.K_e, pygame.K_RETURN, pygame.K_SPACE):
                self.interact()
            return True
        if not self.shop:
            return False
        goods = self.GOODS[self.shop]
        if key in (pygame.K_ESCAPE, pygame.K_BACKSPACE, pygame.K_TAB):
            self.shop = None
            self.notice = ''
        elif key in (pygame.K_DOWN, pygame.K_s):
            self.selected = (self.selected + 1) % len(goods)
        elif key in (pygame.K_UP, pygame.K_w):
            self.selected = (self.selected - 1) % len(goods)
        elif key in (pygame.K_1, pygame.K_2, pygame.K_3):
            self.selected = min(len(goods)-1, (key-pygame.K_1))
        elif key in (pygame.K_RETURN, pygame.K_e, pygame.K_SPACE):
            self.buy_selected()
        return True

    def handle_event(self,event):
        if not self.shop and not self.dialogue:
            return False
        if event.type == pygame.MOUSEWHEEL and self.shop:
            self.selected = (self.selected - event.y) % len(self.GOODS[self.shop])
            return True
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return False
        if self.dialogue:
            if self.close_rect.collidepoint(event.pos):
                self.dialogue = None
                return True
            if self.dialogue['mode'] == 'choices':
                for i,rect in enumerate(self.click_rows):
                    if rect.collidepoint(event.pos):
                        self.dialogue['selected'] = i
                        self._choose_dialogue()
                        return True
            else:
                self.interact()
            return True
        if self.close_rect.collidepoint(event.pos):
            self.shop = None
            self.notice = ''
            return True
        if self.buy_rect.collidepoint(event.pos):
            self.buy_selected()
            return True
        for i,rect in enumerate(self.click_rows):
            if rect.collidepoint(event.pos):
                self.selected = i
                return True
        return True

    def _item_icon(self,item_id,size=56):
        key=item_id,size
        if key in self.icons:return self.icons[key]
        db=self.item_service.inventory.database.get(item_id,{})
        path=ROOT/db.get('icon','')
        if not db.get('icon') or not path.is_file():return None
        try:
            image=pygame.image.load(str(path)).convert_alpha()
            image=pygame.transform.scale(image,(size,size))
        except (pygame.error, OSError, ValueError) as exc:
            print(f"商店圖示載入失敗 {path}: {type(exc).__name__}: {exc}")
            return None
        self.icons[key]=image
        return image

    def _player_behind_tall_object(self):
        """Determine *visual* occlusion; never modify physical colliders.

        Furniture opt-in metadata from V9.8.8 is retained for backwards-
        compatible JSON, but it now marks objects that make the PLAYER fade.
        Transparent pixels are ignored; depth comes from fixture foot position.
        """
        player_rect=self.scene.player.rect
        box=(player_rect.x,player_rect.y,player_rect.width,player_rect.height)
        from systems.occlusion_fade import player_visual_box
        ax,ay,aw,ah=player_visual_box(box)
        if aw<=0 or ah<=0:
            return False
        # A full-sprite actor mask avoids triggering on the empty corners of
        # a player's 96x96 frame, not just the object's transparent margins.
        player_frame=self.scene.player.animator.get_frame()
        if player_frame is not None:
            shape=pygame.transform.scale(player_frame,(aw,ah))
            actor_mask=pygame.mask.from_surface(shape,40)
        else:
            actor_mask=pygame.mask.Mask((aw,ah),fill=True)

        def obscures(image, x, y, depth, alpha_enabled):
            if not alpha_enabled:
                return False
            from systems.occlusion_fade import should_fade
            item={'x':x,'y':y,'width':image.get_width(),
                  'height':image.get_height(),'depth_y':depth,
                  'fade_when_overlapping':True}
            if not should_fade(item,box):
                return False
            key=id(image)
            mask=self._occluder_masks.get(key)
            if mask is None:
                mask=pygame.mask.from_surface(image,80)
                self._occluder_masks[key]=mask
            return mask.overlap_area(actor_mask,(ax-int(x),ay-int(y)))>0

        settings={str(f['id']):f for f in self.scene.map_data.get('furniture',[])}
        for depth,image,x,y,fid in self.scene.map_renderer.furniture:
            if obscures(image,x,y,depth,settings.get(str(fid),{}).get('fade_when_overlapping',False)):
                return True
        for depth,image,x,y,fade_allowed in self.scene.map_renderer.occluders:
            if obscures(image,x,y,depth,fade_allowed):
                return True
        return False

    def _draw_grounded_world_sprite(self, screen, image, x, y, depth, item, kind='furniture'):
        """ONE draw only: fade upper imagery when a player stands behind it.

        Furniture collision rectangles and chair leg/seat colliders are untouched;
        this affects only the alpha of upper pixels of the already loaded sprite.
        Shadow/feet/base pixels are always kept opaque to avoid a ghost floor.
        """
        from systems.object_occlusion_contract import (
            furniture_fade_cutoff, chair_fade_cutoff, player_behind_upper_art)
        # V9.8.22: ordinary tables/desks do not behave like tall bookshelves.
        # Their accurate tabletop footprint is physical, not an alpha-faded
        # occluder.  Only declared tall fixtures can fade their upper art.
        if kind == 'furniture' and not item.get('fade_when_overlapping', False):
            cam=self.scene.camera
            screen.blit(image,(round(x-cam.x),round(y-cam.y)))
            return
        player=self.scene.player
        r=player.rect
        box=(r.x,r.y,r.width,r.height)
        cutoff=(chair_fade_cutoff(item) if kind=='chair' else furniture_fade_cutoff(item))
        fading=player_behind_upper_art(box,x,y,image.get_width(),cutoff,depth)
        if fading:
            # Match the actual nontransparent sprite shape instead of its empty PNG corners.
            actor_box=(r.centerx-48,r.bottom+7-96,96,96)
            ax,ay,aw,ah=actor_box
            actor_frame=player.animator.get_frame()
            if actor_frame is not None:
                actor=pygame.transform.scale(actor_frame,(aw,ah))
                actor_mask=pygame.mask.from_surface(actor,40)
            else:
                actor_mask=pygame.mask.Mask((aw,ah),fill=True)
            cache_key=id(image)
            object_mask=self._occluder_masks.get(cache_key)
            if object_mask is None:
                object_mask=pygame.mask.from_surface(image,80)
                self._occluder_masks[cache_key]=object_mask
            if object_mask.overlap_area(actor_mask,(ax-int(x),ay-int(y)))==0:
                fading=False
        if fading:
            # Cache a derived display surface. We never draw both original and faded copies.
            key=(id(image),cutoff,163)
            faded=self._fade_cache.get(key)
            if faded is None:
                faded=image.copy()
                faded.fill((255,255,255,163),(0,0,image.get_width(),cutoff),
                           special_flags=pygame.BLEND_RGBA_MULT)
                self._fade_cache[key]=faded
            image=faded
        cx,cy=self.scene.camera.x,self.scene.camera.y
        screen.blit(image,(round(x-cx),round(y-cy)))

    def _prepare_player_transparency(self):
        """A translucent player is composited ABOVE the world in a single pass.

        Avoid painting the normal player first: that would produce double-
        exposure through the same tall shelf or pillar. NPCs retain their
        normal depth sorting and physical collisions are completely untouched.
        """
        # V9.8.21 draws the fixture upper half transparent ONCE, not the player twice.
        if self.scene.map_data.get('independent_upper_occlusion_v9821',False):
            self._player_occlusion_alpha=255.0
            self._player_overlay_pending=False
            return False
        hidden=self._player_behind_tall_object()
        self._player_occlusion_alpha=ease_alpha(
            getattr(self,'_player_occlusion_alpha',255.0),hidden,
            getattr(self,'_occlusion_dt',1/60),target=128)
        self._player_overlay_pending=(hidden or self._player_occlusion_alpha<254.5)
        return self._player_overlay_pending

    def draw_player_transparency_overlay(self,screen):
        """Call after map foreground, before HUD. Only when fade is active."""
        if not getattr(self,'_player_overlay_pending',False):
            return
        player=self.scene.player
        rect=player.rect
        # PlayerEntity.draw() always renders a 96x96 frame anchored to its
        # feet. Draw the original sprite at local 0,0 and alpha-blit once.
        world_left=rect.centerx-48
        world_top=rect.bottom+7-96
        layer=getattr(self,'_player_fade_surface',None)
        if layer is None:
            layer=pygame.Surface((96,96),pygame.SRCALPHA)
            self._player_fade_surface=layer
        layer.fill((0,0,0,0))
        player.draw(layer,camera_offset=(world_left,world_top))
        layer.set_alpha(max(0,min(255,int(round(self._player_occlusion_alpha)))))
        camera=self.scene.camera
        screen.blit(layer,(round(world_left-camera.x),round(world_top-camera.y)))

    def _draw_tall_object(self,screen,image,x,y,key,setting,depth,player_drawn=True):
        """High objects are ALWAYS opaque; only the player can fade.

        Keep this single draw method for existing callers and draw-order
        compatibility. It MUST NOT change the fixture alpha or its hitbox.
        """
        ox,oy=self.scene.camera.x,self.scene.camera.y
        screen.blit(image,(round(x-ox),round(y-oy)))

    def draw_npcs(self, screen, include_player=False):
        ox,oy=self.scene.camera.x,self.scene.camera.y
        who=self.nearby() if not self.shop and not self.dialogue else None
        # V9.8.9: Tall fixtures remain opaque. A hidden player is delayed and
        # composited transparently once, ABOVE the world (no double drawing).
        # Tables, chairs and all physics/collision rectangles are unchanged.
        player_translucent=self._prepare_player_transparency() if include_player else False
        # depth is feet position, never sprite top. Foreground objects join the
        # same sorted display list: standing BEHIND a shelf hides the body;
        # walking IN FRONT displays the actor over the shelf image.
        entities=[(float(n.get('draw_depth',self.pos(n).y+5)),0,'npc',n) for n in self.npcs()]
        # Independent PNG furniture shares ONE depth-sorted world pass with actors.
        # Identical position/depth also owns the collision data in map_data['furniture'].
        baked = self.scene.map_data.get('background_baked_furniture', False)
        standalone_ids={f['id'] for f in self.scene.map_data.get('furniture', [])
                        if f.get('render_over_baked_background',False)}
        settings={str(i['id']):i for i in self.scene.map_data.get('furniture',[])}
        for depth,image,fx,fy,fid in self.scene.map_renderer.furniture:
            if not baked or fid in standalone_ids:
                entities.append((float(depth), -2, 'furniture',
                                 (image,fx,fy,fid,settings.get(str(fid),{}))))
        for chair in self.chairs.placements(self.scene.map_data):
            # A composite occupied-seat sprite already contains its one chair.
            # A virtual seat belongs to a bench baked into the approved hall map.
            if chair.get('occupied_embedded_art') or chair.get('virtual_seat'):
                continue
            # In the classroom the full rear of an OCCUPIED chair is drawn
            # exactly once, after its seated NPC, so the back hides the torso
            # while the head remains visible. Never overlay part of the same
            # chair a second time; never cut sprites from map images.
            if (self.scene.map_id == 'academy_classroom' and
                    chair.get('occupied_by') and chair.get('facing') == 'up' and
                    chair.get('chair_art_version','').startswith('V9827')):
                continue
            entities.append((float(chair['seat_anchor'][1]-1 if chair.get('occupied_by') else chair['y']+chair['height']-7),-1,'chair',chair))
        if include_player:
            entities.append((self.scene.player.rect.bottom+7,0,'player',None))
        for depth,asset,x,y,fade_allowed in self.scene.map_renderer.occluders:
            entities.append((depth,1,'occluder',(asset,x,y,fade_allowed)))
        entities.sort(key=lambda pair:(pair[0],pair[1]))
        for draw_depth,layer_order,kind,payload in entities:
            if kind == 'furniture':
                image,x,y,_id,setting=payload
                if self.scene.map_data.get('independent_upper_occlusion_v9821',False):
                    self._draw_grounded_world_sprite(screen,image,x,y,draw_depth,setting)
                elif setting.get('fade_when_overlapping'):
                    self._draw_tall_object(screen,image,x,y,str(_id),setting,draw_depth,include_player)
                else:
                    screen.blit(image,(round(x-ox),round(y-oy)))
                continue
            if kind == 'chair':
                chair=payload
                image=self.chairs.image(chair)
                if self.scene.map_data.get('independent_upper_occlusion_v9821',False):
                    self._draw_grounded_world_sprite(screen,image,chair['x'],chair['y'],
                                                     draw_depth,chair,kind='chair')
                else:
                    screen.blit(image,(round(chair['x']-ox),round(chair['y']-oy)))
                continue
            if kind == 'player':
                if not player_translucent:
                    self.scene.player.draw(screen,camera_offset=(ox,oy))
                continue
            if kind == 'occluder':
                image,x,y,fade_allowed=payload
                if fade_allowed:
                    self._draw_tall_object(
                        screen,image,x,y,f'occluder_{x}_{y}',
                        {'fade_when_overlapping':True,'fade_alpha':128},draw_depth,include_player)
                else:
                    screen.blit(image,(round(x-ox),round(y-oy)))
                continue
            npc=payload
            p=self.pos(npc);x,y=round(p.x-ox),round(p.y-oy)
            if not (-100<x<screen.get_width()+100 and -105<y<screen.get_height()+105):
                continue
            if npc.get('pose') == 'sit':
                # Seated pose has strict priority over AI behavior and player
                # facing. Use the assigned chair's facing as the source of
                # truth so a utility/legacy flag cannot show a front sprite
                # while the character is physically seated facing the desk.
                seat=self.seat_for_npc(npc)
                direction=seat['facing']
                moving=False
                frame=0
            elif npc.get('behavior')=='utility':
                agent=self.agent(npc)
                direction=agent.direction
                moving=agent.moving
                frame=int(agent.distance/11)%4 if moving else 0  # idle: no fake walking frame
                if self.dialogue and self.dialogue['npc'] is npc:
                    moving=False
                    frame=0  # No false 'walking in place' while speaking.
            else:
                # Fixed workers face their work; they only turn toward player
                # when they are not using a dedicated seated pose.
                direction=npc.get('facing','down')
                if npc.get('face_player',True):
                    pplayer=pygame.Vector2(self.scene.player.rect.center)
                    diff=pplayer-p
                    if diff.length_squared()<145**2:
                        if abs(diff.x)>abs(diff.y):
                            direction='right' if diff.x>0 else 'left'
                        else:
                            direction='down' if diff.y>0 else 'up'
                moving=False
                frame=0
            # A seated actor's visible feet are NOT its ground collision point.
            # Align the bespoke seated torso with the cushion, leaving the
            # chair's solid footprint and seat world anchor unchanged.
            visual_y = y + self.seat_visual_offset(npc) if npc.get('pose') == 'sit' else y
            npc_alpha=255
            if self.scene.map_data.get('independent_upper_occlusion_v9821',False):
                from systems.seated_head_occlusion import npc_head_fade_alpha
                pr=self.scene.player.rect
                npc_alpha=npc_head_fade_alpha((pr.x,pr.y,pr.width,pr.height),
                                             (int(p.x),int(p.y)),
                                             visible_height=94)
            elif npc.get('pose') == 'sit' and self.scene.map_id == 'academy_library':
                from systems.seated_head_occlusion import npc_head_fade_alpha
                pr=self.scene.player.rect
                npc_alpha=npc_head_fade_alpha((pr.x,pr.y,pr.width,pr.height),
                                              (int(p.x),int(p.y)))
            self.sprites.render(screen,npc['sprite'],direction,moving,frame,x,visual_y,
                                npc.get('sprite_scale',1.0), npc.get('pose','stand'),
                                alpha=npc_alpha,
                                fade_upper_only=self.scene.map_data.get(
                                    'independent_upper_occlusion_v9821',False),
                                clip_bottom_y=(npc['counter_clip_world_y']-oy)
                                    if self.scene.map_id=='item_shop' and
                                       npc.get('counter_clip_world_y') is not None
                                    else None)
            # Back-facing seated students need a FRONT chair-back pass.
            # Previously the entire NPC (including boots) was painted over the
            # chair. Depth-sorting alone cannot represent the tall seat back.
            # Keep chair art independent; never erase/crop NPC feet to hide it.
            if (npc.get('pose') == 'sit' and direction == 'up' and
                    self.scene.map_id == 'academy_classroom' and
                    self.seat_for_npc(npc).get('chair_art_version','').startswith('V9827')):
                # One chair and one NPC, both truly independent PNGs. The
                # rear-chair image is intentionally placed in FRONT of the
                # lower seated sprite; the actor's head remains above it.
                chair = self.seat_for_npc(npc)
                back = self.chairs.image(chair)
                if self.scene.map_data.get('independent_upper_occlusion_v9821',False):
                    self._draw_grounded_world_sprite(screen,back,chair['x'],chair['y'],
                                                     draw_depth,chair,kind='chair')
                else:
                    screen.blit(back,(round(chair['x']-ox),round(chair['y']-oy)))
            elif npc.get('pose') == 'sit' and direction == 'up' and not self.seat_for_npc(npc).get('occupied_embedded_art'):
                seat_id = npc.get('seat_id')
                seat = next((c for c in self.scene.map_data.get('chairs', [])
                             if c.get('id') == seat_id
                             and c.get('occupied_by') == npc.get('id')), None)
                if seat is not None:
                    backrest = self.chairs.front_backrest(seat)
                    if backrest is not None:
                        screen.blit(backrest, (round(seat['x']-ox),
                                               round(seat['y']-oy)))
            if who is npc:
                label=self.font.render(npc['name']+'  E 交談',True,(250,232,185))
                prompt_offset=int(npc.get('counter_prompt_offset_y',
                                          92 if npc.get('pose')=='sit' else 100))
                bg=label.get_rect(midbottom=(x,y-prompt_offset)).inflate(16,10)
                pygame.draw.rect(screen,(28,27,49),bg,border_radius=5)
                pygame.draw.rect(screen,(198,165,99),bg,1,border_radius=5)
                screen.blit(label,label.get_rect(center=bg.center))

    def _draw_wrapped(self,screen,text,pos,width,color):
        # Chinese text wraps by rendered pixel width, not English word count.
        x,y=pos; line=''
        for char in str(text):
            candidate=line+char
            if self.font.size(candidate)[0]>width and line:
                screen.blit(self.font.render(line,True,color),(x,y))
                y+=self.font.get_linesize()+4; line=char
            else: line=candidate
        if line: screen.blit(self.font.render(line,True,color),(x,y))

    def draw_overlay(self, screen):
        if not self.shop and not self.dialogue:
            self.click_rows = []
            return
        sw, sh = screen.get_size()
        self.click_rows = []
        if self.dialogue:
            d = self.dialogue
            mode = d['mode']
            panel = pygame.Rect((sw-800)//2, sh-314, 800, 279)
            pygame.draw.rect(screen, (24, 27, 47), panel, border_radius=11)
            pygame.draw.rect(screen, (222, 177, 100), panel, 3, border_radius=11)
            npc = d['npc']
            profile=self._profile(npc)
            descriptor=profile.get('label',str(npc.get('role','NPC')))
            header = self.font.render(npc['name']+'  ·  '+descriptor, True, (251, 218, 155))
            screen.blit(header, (panel.x+25, panel.y+15))
            self.close_rect = pygame.Rect(panel.right-114, panel.y+14, 95, 37)
            pygame.draw.rect(screen, (89, 75, 103), self.close_rect, border_radius=6)
            close_label = self.font.render('返回 Esc', True, (249, 227, 195))
            screen.blit(close_label, close_label.get_rect(center=self.close_rect.center))
            if mode == 'lines':
                msg = d['lines'][min(d['index'], len(d['lines'])-1)]
                tip = 'E / Enter / 點擊：下一句    Esc / Tab：關閉對話'
                self._draw_wrapped(screen,msg,(panel.x+29,panel.y+93),panel.width-59,(245,240,234))
                screen.blit(self.font.render(tip, True, (180, 193, 216)), (panel.x+29,panel.bottom-49))
            elif mode == 'reply':
                msg = d['reply']
                self._draw_wrapped(screen,msg,(panel.x+29,panel.y+96),panel.width-60,(246,235,216))
                screen.blit(self.font.render('E / Enter：返回選項', True, (187, 204, 222)), (panel.x+29,panel.bottom-48))
            else:
                options = self._conversation_choices(npc)
                for i,(text,_) in enumerate(options):
                    rect = pygame.Rect(panel.x+27, panel.y+68+i*57, panel.width-54, 49)
                    self.click_rows.append(rect)
                    pygame.draw.rect(screen, (86, 68, 109) if i==d['selected'] else (44, 47, 70),rect,border_radius=7)
                    if i==d['selected']:
                        pygame.draw.rect(screen,(236,192,100),rect,2,border_radius=7)
                    label=self.font.render(f'{i+1}.  {text}', True, (255, 239, 204))
                    screen.blit(label,(rect.x+18,rect.y+9))
                screen.blit(self.font.render('↑↓ 選擇 / Enter 確認 / Esc / Tab 關閉', True,(187,204,222)),
                            (panel.x+29,panel.bottom-26))
            return
        panel = pygame.Rect((sw-780)//2,max(4,(sh-660)//2),780,min(sh-8,660))
        pygame.draw.rect(screen,(25,27,47),panel,border_radius=13)
        pygame.draw.rect(screen,(218,175,99),panel,3,border_radius=13)
        gold=self.item_service.get_player().get('gold',0)
        title=self.font.render(self.SHOP_NAMES[self.shop]+'    金幣：'+str(gold)+' G',True,(251,216,148))
        screen.blit(title,(panel.x+30,panel.y+21))
        for i,(item_id,price) in enumerate(self.GOODS[self.shop]):
            info=self.item_service.inventory.database.get(item_id,{})
            rect=pygame.Rect(panel.x+32,panel.y+74+i*76,716,70)
            self.click_rows.append(rect)
            pygame.draw.rect(screen,(91,70,112) if i==self.selected else (39,41,67),rect,border_radius=8)
            if i==self.selected:pygame.draw.rect(screen,(248,210,123),rect,3,border_radius=8)
            icon=self._item_icon(item_id,50)
            if icon:screen.blit(icon,(rect.x+18,rect.y+11))
            name=self.font.render(f'{i+1}. {info.get("name",item_id)}    {price} G',True,(247,227,179))
            desc=self.font.render(info.get('description',''),True,(216,218,233))
            owned=self.item_service.inventory.get_item_count(item_id)
            qty=self.font.render('背包持有：'+str(owned),True,(169,211,192))
            screen.blit(name,(rect.x+86,rect.y+4))
            screen.blit(desc,(rect.x+86,rect.y+30))
            screen.blit(qty,(rect.x+530,rect.y+40))
        self.buy_rect=pygame.Rect(panel.x+375,panel.bottom-86,215,45)
        self.close_rect=pygame.Rect(panel.x+606,panel.bottom-86,138,45)
        for rect,text,color in ((self.buy_rect,'購買選取商品',(94,84,135)),
                                (self.close_rect,'返回地圖 Esc',(80,66,97))):
            pygame.draw.rect(screen,color,rect,border_radius=7)
            pygame.draw.rect(screen,(209,174,109),rect,2,border_radius=7)
            label=self.font.render(text,True,(255,238,199))
            screen.blit(label,label.get_rect(center=rect.center))
        help_msg=self.font.render('滑鼠點選 / ↑↓ 選擇    Enter / E 購買    Esc 關閉商店',True,(206,211,232))
        screen.blit(help_msg,(panel.x+29,panel.bottom-23))
        if self.notice_timer>0:
            notice=self.font.render(self.notice,True,(255,220,133))
            screen.blit(notice,(panel.x+30,panel.bottom-115))
