"""Detect tall foreground objects that require PLAYER translucency.

No physics/collision rectangle is modified by this module. Tables/chairs do
not opt in; they keep their exact V9.8.7 footprints and depth order.
"""

MAX_ALPHA=255
DEFAULT_FADE_ALPHA=128

def player_visual_box(player_rect):
    """96px player sprite anchored 7px below the collision-box bottom."""
    x,y,w,h=map(int,player_rect)
    feet=y+h+7
    return (x+w//2-48,feet-96,96,96)

def rectangles_overlap(a,b):
    ax,ay,aw,ah=a;bx,by,bw,bh=b
    return aw>0 and ah>0 and bw>0 and bh>0 and ax<bx+bw and bx<ax+aw and ay<by+bh and by<ay+ah

def should_fade(item, player_rect, player_depth=None):
    if not item.get('fade_when_overlapping',False):
        return False
    x,y,w,h=map(int,player_rect)
    depth=(y+h+7) if player_depth is None else float(player_depth)
    # Depth sorting owns occlusion: a fixture in the player's BACKGROUND must
    # stay fully opaque even if rectangular boundaries overlap.
    if depth>=float(item['depth_y']):
        return False
    obj=(int(item['x']),int(item['y']),int(item['width']),int(item['height']))
    return rectangles_overlap(obj,player_visual_box(player_rect))

def ease_alpha(current, obscures, dt, target=DEFAULT_FADE_ALPHA, speed=700.0):
    """Approach target with a frame-rate-independent maximum step."""
    destination=max(80,min(235,int(target))) if obscures else MAX_ALPHA
    current=max(0,min(255,float(current)))
    step=max(0,min(float(dt),0.1))*speed
    if current<destination: return min(destination,current+step)
    return max(destination,current-step)
