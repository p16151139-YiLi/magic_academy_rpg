"""Pixel-accurate collision rectangles and a route-audit occupancy grid.

The gameplay controller still resolves collision at the *original rectangle*
resolution (24x18 player foot box). Grid cells are for AI-route / QA checks;
we never replace precise boundaries with coarse 'all tile solid' air walls.
"""
from collections import deque


def validated_baked_colliders(m):
    result=[]
    for box in m.get('baked_collision_rects', []):
        if (not isinstance(box,list) or len(box)!=4 or
            not all(type(v) is int for v in box)):
            raise ValueError('已畫在背景的物件碰撞矩形格式錯誤')
        x,y,w,h=box
        if w<=0 or h<=0 or x<0 or y<0 or x+w>m['width'] or y+h>m['height']:
            raise ValueError('已畫在背景的物件碰撞超出地圖範圍')
        result.append(box)
    return result


def all_world_rects(m):
    from systems.furniture_geometry import map_furniture_world_rects
    from systems.chair_geometry import chair_walking_obstacles
    boxes=list(m['collision_rects'])
    if m.get('background_baked_furniture',False):
        from systems.furniture_geometry import baked_standalone_world_rects
        boxes += validated_baked_colliders(m) + baked_standalone_world_rects(m)
    else:
        boxes += map_furniture_world_rects(m)
    for chair in m.get('chairs',[]):
        boxes += chair_walking_obstacles(chair)
    return boxes


def point_free(x,y,boxes,half_width=12,half_height=9):
    # Exact pygame.Rect half-open intersection semantics, with player's feet.
    return all(x+half_width<=bx or x-half_width>=bx+bw or
               y+half_height<=by or y-half_height>=by+bh
               for bx,by,bw,bh in boxes)


def collision_cells(m,cell=16):
    """Center-sampled walkable grid including the player's 24x18 footprint."""
    boxes=all_world_rects(m)
    nx=(m['width']+cell-1)//cell
    ny=(m['height']+cell-1)//cell
    rows=[]
    for j in range(ny):
        row=[]
        for i in range(nx):
            x=min(m['width']-12,i*cell+cell//2)
            y=min(m['height']-9,j*cell+cell//2)
            row.append(x>=12 and y>=9 and x<m['width']-12 and y<m['height']-9 and
                       point_free(x,y,boxes))
        rows.append(row)
    return rows


def reachable_cells(grid,x,y,cell=16):
    if not grid or not grid[0]:return set()
    ny=len(grid);nx=len(grid[0])
    i,j=max(0,min(nx-1,int(x//cell))),max(0,min(ny-1,int(y//cell)))
    if not grid[j][i]:
        choices=[(i+di,j+dj) for rad in range(1,5)
                 for di in range(-rad,rad+1) for dj in range(-rad,rad+1)
                 if 0<=i+di<nx and 0<=j+dj<ny and grid[j+dj][i+di]]
        if not choices:return set()
        i,j=min(choices,key=lambda p:(p[0]*cell+cell//2-x)**2+(p[1]*cell+cell//2-y)**2)
    q=deque([(i,j)]);seen={(i,j)}
    while q:
        i,j=q.popleft()
        for a,b in ((i+1,j),(i-1,j),(i,j+1),(i,j-1)):
            if 0<=a<nx and 0<=b<ny and grid[b][a] and (a,b) not in seen:
                seen.add((a,b));q.append((a,b))
    return seen


def path_to_radius(reached,pos,radius,cell=16):
    x,y=pos
    return any((i*cell+cell//2-x)**2+(j*cell+cell//2-y)**2<=radius**2
               for i,j in reached)


def fingerprint(m):
    """The saved occupancy grid is invalidated by any obstacle or map size edit."""
    import hashlib,json
    data={k:m.get(k) for k in ('width','height','collision_rects','baked_collision_rects','background_baked_furniture','furniture','chairs')}
    # Rendering-only tall-object alpha settings do not modify geometry.
    # Exclude only these three keys so V9.8.7 saved collision cells remain valid.
    data['furniture']=[{k:v for k,v in item.items()
                         if k not in ('fade_when_overlapping','fade_alpha','fade_category')}
                       for item in m.get('furniture',[])]
    # Asset paths and visual depth alone are retained in checksum too, so map
    # layout changes automatically require regenerating the grid.
    return hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf-8')).hexdigest()


def save_grid(m,path,cell=16):
    import json
    from pathlib import Path
    grid=collision_cells(m,cell)
    result={'map_id':m['id'],'schema':'V987_PRECISE_COLLISION_GRID','cell_size':cell,
            'width_cells':len(grid[0]),'height_cells':len(grid),
            'source_sha256':fingerprint(m),
            'legend':{'1':'player 24x18 feet footprint is clear','0':'solid or border'},
            'rows':[''.join('1' if b else '0' for b in row) for row in grid]}
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return result


def load_grid(m,path):
    import json
    from pathlib import Path
    d=json.loads(Path(path).read_text(encoding='utf-8'))
    if d['map_id']!=m['id'] or d['source_sha256']!=fingerprint(m):
        raise ValueError('碰撞格和目前地圖碰撞資料版本不一致，請重新產生')
    if len(d['rows'])!=d['height_cells'] or any(len(row)!=d['width_cells'] for row in d['rows']):
        raise ValueError('碰撞格行列數不正確')
    return [[v=='1' for v in row] for row in d['rows']]
