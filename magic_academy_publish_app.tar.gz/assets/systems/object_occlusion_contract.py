"""V9.8.21 independent fixture upper-occlusion / feet-only physics contract.

Physical rectangles belong to furniture_geometry and chair_geometry ONLY.
The upper visual footprint is never appended to gameplay collisions.
Pure functions are shared by runtime, no-SDL audit and future maps.
"""
from systems.occlusion_fade import player_visual_box, rectangles_overlap


def furniture_fade_cutoff(item):
    """Local Y separating a fixture's upper art from its *ground* contacts."""
    h=int(item['height'])
    rectangles=item.get('collision_rects', [])
    if rectangles:
        # Base or individual legs can vary; never fade a painted physical foot.
        return max(0,min(h,int(min(p[1] for p in rectangles))))
    # Pure decor (no physical base) only fades if it visually occludes a walker.
    return max(0,h-6)


def chair_fade_cutoff(chair):
    """Chair upper art: backrest stays visual, seat and grounded legs stay solid."""
    h=int(chair['height'])
    return max(0,min(h,int(h*.58)))


def player_behind_upper_art(player_rect, world_x, world_y, width, cutoff, depth_y):
    """Candidate for a SINGLE upper-alpha render; collision remains unchanged.

    Transparent pixel overlap is checked separately by pygame.mask in runtime.
    """
    px,py,pw,ph=map(int,player_rect)
    feet=py+ph+7
    if feet>=float(depth_y) or cutoff<=0:return False
    return rectangles_overlap(player_visual_box((px,py,pw,ph)),
                              (int(world_x),int(world_y),int(width),int(cutoff)))


def map_fixture_support(item):
    """A complete declared object has either local ground rectangles or zero collision for decor."""
    from systems.furniture_geometry import furniture_world_rects
    return furniture_world_rects(item)
