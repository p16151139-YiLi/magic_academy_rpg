"""Pixel-aligned directional chair geometry, measured from actual transparent PNGs.

Physical chair-leg colliders are small independent rectangles.  The cushion
is a separately reserved seat area, never a third physical leg.  Ordinary
walking actors respect the reservation, while the designated stationary
occupant uses the seat anchor and does not run walk collision against itself.
"""

def chair_solid_rects(chair):
    # Painted bench seats are semantic reservations, not extra physical chair legs.
    if chair.get('virtual_seat'):
        return []
    parts=chair.get('collision_rects')
    if parts is not None:
        if len(parts)!=2 or not all(len(part)==4 for part in parts):
            raise ValueError('椅子必須提供兩個獨立椅腳碰撞矩形：'+str(chair.get('id')))
        return [list(p) for p in parts]
    return [list(chair['collision_rect'])] if 'collision_rect' in chair else []

def chair_seat_reservation(chair):
    """Access-controlled cushion footprint: excludes the named seated actor."""
    seat=chair.get('seat_block_rect')
    return list(seat) if seat else None

def chair_side_supports(chair):
    """Tiny *world-space* support blocks beside occupied seats, near seat/feet.

    Never extend a seated NPC's head/hair/image box into a physical barrier.
    Empty chairs and chairs on other maps keep their previous geometry.
    """
    parts=chair.get('occupied_side_foot_blocks', [])
    if not parts:
        return []
    if not chair.get('occupied_by') or len(parts)!=2:
        raise ValueError('坐姿 NPC 座位需左右各一個小型腳部碰撞：'+str(chair.get('id')))
    ax,ay=map(int,chair['seat_anchor'])
    result=[]
    for block in parts:
        if (not isinstance(block,list) or len(block)!=4 or
            not all(type(v) is int for v in block)):
            raise ValueError('左右座位碰撞格式錯誤')
        x,y,w,h=block
        if not (0<w<=10 and 0<h<=18 and abs(x+w/2-ax)<=31 and
                ay-10<=y<=ay+12 and chair['x']<=x and x+w<=chair['x']+chair['width'] and
                chair['y']<=y and y+h<=chair['y']+chair['height']):
            raise ValueError('座位碰撞必須貼近實際椅座／腳部，而非人物頭部：'+str(chair.get('id')))
        result.append(list(block))
    if not (result[0][0]+result[0][2]<=ax<=result[1][0]):
        raise ValueError('左右座位碰撞必須分居 NPC 兩側')
    return result


def chair_walking_obstacles(chair):
    """Solid obstacles for player and non-occupant walking NPCs."""
    parts=chair_solid_rects(chair)
    cushion=chair_seat_reservation(chair)
    return parts+([cushion] if cushion else [])+chair_side_supports(chair)

def seat_at(chair):
    return tuple(chair['seat_anchor'])
