# V9.8.2｜完整專案與 Colab 回歸修正

## 本次修正依據
依照使用者提供的 Colab 實際執行紀錄：55 項測試中 52 PASS、3 FAIL、0 SKIP，並已產生 191 張真實 SDL 截圖。三項失敗均為舊 SDL 測試與目前遊戲架構不一致，不以刪除測試或放寬遊戲規格處理。

## 三項 SDL 回歸測試修正
1. `test_v8_pygame_smoke.py`
   - 保留背包返回、Esc、五個裝備槽與六格快捷列測試。
   - 地圖素材檢查改為同時識別舊式 occluders 與新版獨立 furniture layer。
   - NPC 依 `pose` 呼叫 `NPCSpriteLibrary.preload()`；坐姿 NPC 使用專用坐姿 PNG，不呼叫站立圖集。
2. `test_v9_5_1_full_pygame_smoke.py`
   - 保留七張地圖、NPC 繪製、所有玩家選單頁、NPC 對話/商店 overlay 及錯誤復原測試。
   - 分別驗證 15 個四方向圖集、1 個 seated-only profile、3 個實際坐姿 NPC placement 及 13 個站立/漫遊 placement。
   - Selena、Cora、Leo 的坐姿渲染均使用專用 seated asset contract。
3. `test_v9_5_pygame_runtime.py`
   - 移除已過期的 T 型書架固定座標。
   - 由 `academy_library` 的 `library_table_01` 當前 `collision_rects` 動態取得真實分段碰撞。
   - 實際驗證玩家會被桌面碰撞阻擋、下方走道仍可通過、圖書館入口出生點保持暢通，並保留 NPC AI 左右方向測試。

## Colab 與建置修正
- 上傳 ZIP 不再依賴瀏覽器檔名完全相同；只接受單一 ZIP，並以完整專案 payload SHA256 作為唯一內容驗證。
- 加入 ZIP 路徑安全檢查與 `main.py`/release manifest 版本核對。
- 保留 pygame-ce 2.5.8、SDL dummy display、繁體中文字型與 Pygbag CLI preflight。
- 保留 55 項固定測試、40/15 分類、每項 240 秒 timeout、完整失敗彙總與零 SKIP 部署閘門。
- SDL 視覺檢查要求七張地圖各有實際 `*_world.png` 截圖；Colab 以原始地圖 JSON、背景圖層、獨立家具、椅子及 NPC 素材產生設計參考圖，再與真實遊戲畫面並排，輸出完整截圖 ZIP。
- Pygbag build 前保留完整原始 ZIP；只在測試通過後清除建置副本中的 `docs/`、`tests/`。
- APK/TAR 內容雜湊檢查涵蓋 runtime Python、JSON、data 與 assets。
- GitHub 清理只移除明確管理的舊版輸出；保留 `.git` 與 commit 歷史。

## 遊戲功能與地圖保留
- 不更動遊戲玩法、7 張地圖背景、家具座標、碰撞座標、NPC 美術、角色比例或場景流程。
- 保留 16 位 NPC、15 個四方向圖集、1 個 seated-only profile、3 個坐姿 placement。
- 保留獨立透明家具 PNG、物件 JSON、物件座標、深度排序、分段碰撞與座位保留。
- 保留玩家移動、NPC AI、對話、商店、背包、裝備、技能/角色 UI、快捷列與存檔。

## 驗證限制
本機診斷實際結果為 40 PASS / 0 FAIL / 15 SKIP；SKIP 是明確的本機診斷模式，不能視為完整通過。本機執行環境未安裝 pygame-ce，故 15 項 SDL 測試仍須在 Colab 執行。15 項 SDL 測試、Pygbag Build、GitHub Push 與 Pages 公開 APK SHA256 必須在 Colab 實際執行；未執行前不標示 PASS。
