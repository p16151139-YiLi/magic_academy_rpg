# Magic Academy RPG — 整合修正紀錄

## 本次整理

- 將玩家角色精靈圖載入整合回 `PlayerEntity`，移除執行期 monkey patch。
- 將自由配點面板整合回 `PlayerMenu`，移除執行期 monkey patch。
- 將職業初始資料與既有自由配點保留邏輯整合回 `PlayerClassManager`。
- 移除不存在的 `systems.font_manager` 可選匯入，統一使用專案內的 Noto Sans TC。
- 地圖出口提示及系統訊息改用共用中文字型，避免預設字型缺少中文字形。
- 將遊戲快捷鍵集中由 `GameScene` 輪詢 `pygame.key.get_pressed()`，補足瀏覽器環境可能漏送 `KEYDOWN` 的情況。
- ESC 在遊戲選單開啟時不再直接切回主選單。
- 物品數量欄位讀取簡化。

## 角色動畫素材狀態

- 均衡型法師目前有 `idle.png` 與 `walk.png`，尺寸符合動畫設定。
- 近戰型與遠程型法師尚無獨立角色精靈圖。
- 為避免這兩種職業完全沒有動畫，載入器暫時使用均衡型法師的待機／行走精靈圖，並以不同色調區分。
- 攻擊、施法、受傷動畫素材尚未提供，這些狀態不會憑空產生。

## 地圖素材狀態

目前入口與中央大廳的地圖圖層圖片存在。教室、圖書館、森林 JSON 指向的背景圖片在本次來源 ZIP 中不存在，尚未補造素材。

## 驗證

- Python 檔案 AST 語法檢查通過。
- JSON 檔案解析檢查通過。
- 均衡型法師待機與行走精靈圖尺寸符合 `animation_config.json`。
- 本次執行環境沒有安裝 Pygame／Pygbag，因此未能在此處進行實際遊戲視窗或瀏覽器互動測試。
- 重新部署前，請在 Colab 執行 Pygbag build，並使用新產生的 `build/web` 部署；不要沿用舊版網頁封裝。

## 建置

```bash
pip install pygame-ce pygbag
pygbag --build .
```

Build 完成後，部署 `build/web` 內的網頁內容至 GitHub Pages 指定發布來源。
