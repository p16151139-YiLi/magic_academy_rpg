# V9.4 全介面按鍵與 GitHub Pages 部署整合版

本版本以 V9.3 為基礎，保留原有場景、NPC、地圖圖片、角色圖、物品、商店、裝備與入口修正，不重新生成素材。

## 修正重點

- NPC 對話、商店滑鼠事件由原本意外重複呼叫兩次，改為一次；避免點擊下一句或購買時重複執行。
- 事件優先順序統一為「NPC 對話/商店 ＞ 玩家選單/背包 ＞ 世界互動」，避免滑鼠點透到角色或傳送門。
- 背包左上返回立即關閉背包；角色、地圖、技能、任務、操作說明頁右上返回立即關閉玩家介面。
- 對話與商店新增 Tab 返回；Esc / Backspace 亦可退出。玩家介面與背包 Esc / Tab / Backspace 關閉。
- 職業選擇支援方向鍵（或 A/D）切換、Enter/Space 確認、Esc 返回；標題頁支援方向鍵和 Enter/Space。
- 設定與製作團隊支援 Esc/Backspace 返回；設定頁返回時存檔。
- 移除主迴圈的全域 Esc 場景跳轉，改由各畫面自行決定關閉/返回行為。
- 遊戲畫面顯示 `V9.4 INPUT FIX`，以供 GitHub Pages 更新辨識。

## 遊戲快捷鍵

| 按鍵 | 世界畫面 | 玩家介面 | 對話/商店 |
|---|---|---|---|
| WASD/方向鍵 | 移動 | 背包可移動選取 | 選項/商品上下移動 |
| E | 互動/入口/NPC | 僅背包內部操作，絕不穿透 | 確認/推進/購買 |
| I/C/K/M/H | 背包/角色/技能/地圖/說明 | 切換頁面，再按同一鍵關閉 | 不影響世界快捷鍵 |
| Tab | 開啟玩家選單 | 關閉 | 關閉 |
| Esc/Backspace | 開啟操作說明（Esc） | 關閉 | 關閉 |
| 1~6 | 使用快捷道具 | 背包指定快捷鍵 | 對話選項/商店選商品 |

## 驗證情形

- 通過 Python 語法編譯、JSON 解析、V9.1/V9.2 大廳入口模擬、V9.4 輸入路由模擬。
- 通過 NPC 對話資料/互動邏輯、商店購買與背包同步、裝備取下與還原回歸測試。
- **沒有在實際 GitHub Pages 網頁與 Pygame 畫面中做滑鼠操作驗證**；瀏覽器端仍需確認遊戲畫面焦點、返回按鈕以及新版快取。

## 檔案

- 完整遊戲：`Magic_Academy_RPG_V9_4_Input_Full.zip`
- Colab 部署：`Magic_Academy_RPG_V9_4_Colab_Deploy.ipynb`（與 ZIP 分開提供）

## GitHub Pages 部署

在 Colab 上傳 ZIP，輸入 GitHub `帳號/儲存庫` 與具備 Contents 寫入權限的 Token，再執行建置與推送至 `gh-pages`。儲存庫 Settings > Pages 選擇 `Deploy from a branch` > `gh-pages` / `(root)`。部署後重新整理頁面，確認遊戲畫面顯示 `V9.4 INPUT FIX`。

此 ZIP 是**可供 Colab 建置的 Pygame 原始碼專案**，不是已編譯的 GitHub Pages HTML 目錄；瀏覽器版須先經 Pygbag 建置。不要直接把 Python ZIP 當成 HTML 網站上傳。
