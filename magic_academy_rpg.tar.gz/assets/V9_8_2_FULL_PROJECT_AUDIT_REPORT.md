# Magic Academy RPG V9.8.2 — Full Project / Colab Regression Audit

## Source baseline
- Input: V9.8.1 R1 full project ZIP.
- Project scope: complete source, data, maps, NPC manifests, furniture PNGs, tests, Colab Notebook and release metadata.
- The uploaded Colab log recorded 52 PASS / 3 FAIL / 0 SKIP out of 55, with 191 real SDL screenshots.
- The 3 failures were traced to stale SDL test expectations, not evidence of a new gameplay runtime regression.

## Repairs applied
- V8 smoke: recognizes the current independent furniture layer in the library while retaining legacy occluder checks for the two stores; NPC loading is pose-aware.
- V9.5.1 full smoke: checks all 15 four-direction atlases and all three seated placements using the dedicated seated rendering path.
- V9.5 runtime: derives collision test geometry from the current `library_table_01` segmented footprint rather than a superseded T-shelf coordinate.
- Project integrity: adds assertions that these legacy tests remain aligned with current map/NPC contracts.
- Upload cell: validates ZIP content SHA256, not a brittle exact browser filename; safe path checks remain.
- Notebook: builds seven independent map design references from JSON/PNG object assets, pairs them side-by-side with seven actual SDL world screenshots, and blocks deployment if any map screenshot is missing.
- Build verification: hashes runtime Python, JSON, and asset files inside Pygbag APK/TAR output.

## Preserved content
- Seven maps and their current backgrounds/layout data.
- Sixteen NPC profiles, 15 four-direction atlases, one seated-only profile, three seated placements.
- Independent furniture PNGs, map object records, depth ordering, segmented colliders, chair legs and separate seat reservations.
- Player movement, scene transitions, NPC AI/dialogue, shops, inventory/equipment, UI, quickbar, and persistent player data.
- No map art, furniture positions, NPC artwork, character scale, or gameplay mechanics were intentionally changed.

## Validation status
- The 3 failing SDL test sources have been updated to current runtime contracts.
- The fixed 55-test suite still contains 40 non-SDL and 15 real SDL tests; no test was deleted or reclassified.
- Local diagnostic run: 40 PASS / 0 FAIL / 15 SKIP (explicit `--skip-sdl` mode, which correctly remains a deployment blocker). Local environment has no pygame-ce package and no package network access, so SDL tests cannot be executed here.
- The 40 non-SDL suite and full static integrity checks must be run after packaging; the 15 SDL tests, Pygbag build, GitHub push, and Pages APK hash must be confirmed in Colab.
- No deployment is authorized unless the Colab runner reports exactly 55 PASS, 0 FAIL, 0 SKIP, zero preflight errors, and all seven world screenshots.
