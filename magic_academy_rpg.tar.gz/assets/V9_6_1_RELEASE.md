# V9.6.1｜椅子圖片載入與 Colab 顯示環境修正版

## 問題原因
V9.6 Colab 的「圖片載入健檢」在繪製六張地圖後呼叫了 `pygame.quit()`，卻繼續以 `ChairSystem.image()` 測試椅子。原 `ChairSystem.image()` 在顯示環境不存在時仍呼叫 `convert_alpha()`，因此發生 `pygame.error: cannot convert without pygame.display initialized`。

## 修改
- `systems/chair_system.py`：只有在 Pygame 顯示視窗已初始化時才使用 `convert_alpha()`；沒有視窗時，保留原始 PNG 的每像素 alpha，仍能檢查透明度。快取依「有無顯示環境」分開，遊戲繪圖仍優先使用轉換後的 Surface。
- **12 格原版 Colab**：保留原本儲存庫、main 分支、Secrets 與建置流程，讓椅子透明背景檢查在 `pygame.quit()` 之前完成；新增 `tests/test_v9_6_1_chair_display.py` 回歸測試。
- 顯示版本改為 `V9.6.1 CHAIR LOAD FIX`，方便部署後辨識是否真的換版。

## 完整性
原本七張地圖、教室與圖書館的 24 張椅子配置、地圖背景、碰撞、NPC、商店、玩家選單、背包與所有資源皆維持原樣；本版沒有重新生成或替換圖片。

## 測試界線
非圖形回歸與 ZIP 結構可在本地執行。涉及 Pygame 的 24 椅子圖片檢查、七地圖繪製與選單操作必須透過安裝 `pygame-ce` 的 Colab 執行；失敗時 Colab 中止部署。GitHub Pages 實際瀏覽器遊玩仍需要部署後確認。
