import pygame


class PlayerController:
    def __init__(self, x=640, y=360):
        self.position = pygame.Vector2(x, y)
        self.speed = 220
        self.direction = "down"
        self.state = "idle"
        self.size = (32, 42)
        self.rect = pygame.Rect(0, 0, *self.size)
        self.rect.center = (round(x), round(y))
        self.enabled = True

    def update(self, dt, obstacles=None, keys=None):
        if not self.enabled:
            self.state = "idle"
            return

        if keys is None:
            keys = pygame.key.get_pressed()

        dx = (
            int(keys[pygame.K_d] or keys[pygame.K_RIGHT])
            - int(keys[pygame.K_a] or keys[pygame.K_LEFT])
        )
        dy = (
            int(keys[pygame.K_s] or keys[pygame.K_DOWN])
            - int(keys[pygame.K_w] or keys[pygame.K_UP])
        )

        movement = pygame.Vector2(dx, dy)

        if movement.length_squared() == 0:
            self.state = "idle"
            return

        movement.normalize_ip()
        self.state = "walk"

        if abs(movement.x) > abs(movement.y):
            self.direction = (
                "right" if movement.x > 0 else "left"
            )
        else:
            self.direction = (
                "down" if movement.y > 0 else "up"
            )

        obstacles = obstacles or []
        delta = movement * self.speed * max(0, min(dt, 0.1))

        self.position.x += delta.x
        self._sync_rect()

        for obstacle in obstacles:
            if self.rect.colliderect(obstacle):
                if delta.x > 0:
                    self.rect.right = obstacle.left
                elif delta.x < 0:
                    self.rect.left = obstacle.right
                self.position.x = self.rect.centerx

        self.position.y += delta.y
        self._sync_rect()

        for obstacle in obstacles:
            if self.rect.colliderect(obstacle):
                if delta.y > 0:
                    self.rect.bottom = obstacle.top
                elif delta.y < 0:
                    self.rect.top = obstacle.bottom
                self.position.y = self.rect.centery

    def _sync_rect(self):
        self.rect.center = (
            round(self.position.x),
            round(self.position.y)
        )

    def teleport(self, x, y):
        self.position.update(x, y)
        self._sync_rect()
        self.state = "idle"
