
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class PlayerClassManager:

    def __init__(self):
        self.class_path = ROOT / "data/player/mage_classes.json"
        self.player_path = ROOT / "data/player/player_data.json"

        with open(self.class_path, encoding="utf-8") as f:
            self.classes = json.load(f)

    def apply_class(self, class_id):
        if class_id not in self.classes:
            raise ValueError(f"未知職業：{class_id}")

        job = self.classes[class_id]

        if self.player_path.exists():
            with open(self.player_path, encoding="utf-8") as f:
                player = json.load(f)
        else:
            player = {
                "name": "見習冒險者",
                "level": 1,
                "exp": 0,
                "exp_to_next_level": 100,
                "gold": 0,
                "attributes": {}
            }

        # 保留玩家名稱、等級、經驗值與金幣
        player["class_id"] = class_id
        player["class_name"] = job["name"]

        player["hp"] = job["hp"]
        player["max_hp"] = job["hp"]
        player["mp"] = job["mp"]
        player["max_mp"] = job["mp"]

        player.setdefault("attributes", {})
        player["attributes"]["attack"] = job["attack"]
        player["attributes"]["defense"] = job["defense"]

        self.player_path.parent.mkdir(
            parents=True, exist_ok=True
        )

        with open(self.player_path, "w", encoding="utf-8") as f:
            json.dump(player, f, ensure_ascii=False, indent=2)

        return player

# STAGE3_CLASS_INTEGRATION
from systems.character_progression import ensure as _ensure, defaults as _defaults, synchronize as _sync, write as _write, PLAYER as _PLAYER
_original_apply_class=PlayerClassManager.apply_class
def _stage3_apply_class(self,class_id):
    old=_ensure(__import__('json').load(open(_PLAYER,encoding='utf-8'))) if _PLAYER.exists() else None
    result=_original_apply_class(self,class_id)
    data=_ensure(result)
    if old and old.get('allocated_points',0)>0:
        data['base_stats']=old['base_stats']
        data['unspent_points']=old['unspent_points']
        data['allocated_points']=old['allocated_points']
        data['hidden_talents']=old['hidden_talents']
    else:
        data['base_stats']=_defaults(class_id)
    _sync(data)
    _write(_PLAYER,data)
    return data
PlayerClassManager.apply_class=_stage3_apply_class
