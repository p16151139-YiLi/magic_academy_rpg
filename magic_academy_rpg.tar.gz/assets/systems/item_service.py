import json
from pathlib import Path

from systems.inventory_manager import InventoryManager

ROOT = Path(__file__).resolve().parents[1]


class ItemService:
    def __init__(self, inventory=None):
        self.inventory = inventory or InventoryManager()
        self.player_path = ROOT / "data/player/player_data.json"

    def get_player(self):
        with open(self.player_path, encoding="utf-8") as f:
            return json.load(f)

    def refresh(self):
        self.inventory.reload()
        return self.get_snapshot()

    def get_snapshot(self):
        return {
            "player": self.get_player(),
            "inventory": self.inventory.data,
            "equipment_bonuses": self.inventory.get_equipment_bonuses(),
        }

    def give_item(self, item_id, amount=1):
        success = self.inventory.add_item(item_id, amount)
        return self.result(success)

    def take_item(self, item_id, amount=1):
        success = self.inventory.remove_item(item_id, amount)
        return self.result(success)

    def use_item(self, item_id):
        success = self.inventory.use_item(item_id)
        return self.result(success)

    def equip_item(self, item_id):
        success = self.inventory.equip_item(item_id)
        return self.result(success)

    def unequip_item(self, slot):
        success = self.inventory.unequip_item(slot)
        return self.result(success)

    def result(self, success):
        return {"success": bool(success), "message": self.inventory.last_message, "snapshot": self.get_snapshot()}

    def get_item_count(self, item_id):
        return self.inventory.get_item_count(item_id)

    def get_equipment_bonuses(self):
        return self.inventory.get_equipment_bonuses()
