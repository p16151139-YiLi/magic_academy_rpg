import pygame
from systems.player_controller import PlayerController
from systems.player_animator import PlayerAnimator


class PlayerEntity:
    def __init__(
        self, x=640, y=360,
        class_id="balanced_mage"
    ):
        self.controller = PlayerController(x, y)
        self.animator = PlayerAnimator(class_id)
        self.class_id = class_id

    @property
    def rect(self):
        return self.controller.rect

    def update(self, dt, obstacles=None, keys=None):
        self.controller.update(dt, obstacles, keys)
        self.animator.set_animation(
            self.controller.state,
            self.controller.direction
        )
        self.animator.update(dt)

    def draw(self, surface, camera_offset=(0, 0)):
        ox, oy = camera_offset
        destination = self.rect.move(-ox, -oy)
        frame = self.animator.get_frame()

        if frame is not None:
            image_rect = frame.get_rect(
                midbottom=destination.midbottom
            )
            surface.blit(frame, image_rect)
        else:
            # 素材尚未加入時的暫時顯示方式
            pygame.draw.rect(
                surface, (100, 165, 235),
                destination,
                border_radius=5
            )


# STAGE4_SPRITE_LOADER
from systems.player_sprite_loader import PlayerSpriteLoader

_stage4_original_player_init = PlayerEntity.__init__


def _stage4_player_init(self, *args, **kwargs):
    _stage4_original_player_init(self, *args, **kwargs)

    self.sprite_load_result = {
        "loaded": [],
        "missing": []
    }

    # Pygame 尚未建立顯示畫面時，暫不載入圖片
    if pygame.display.get_surface() is None:
        return

    loader = PlayerSpriteLoader()
    self.sprite_load_result = loader.load_into(
        self.animator
    )


PlayerEntity.__init__ = _stage4_player_init
