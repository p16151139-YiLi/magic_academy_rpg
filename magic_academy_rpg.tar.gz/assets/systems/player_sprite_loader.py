import json
from pathlib import Path
import pygame


class PlayerSpriteLoader:
    """載入每種職業的四方向動畫精靈圖。"""

    def __init__(self, root=None):
        self.root = (
            Path(root) if root
            else Path(__file__).resolve().parents[1]
        )

        config_file = (
            self.root / "data/characters/animation_config.json"
        )

        self.config = json.loads(
            config_file.read_text(encoding="utf-8")
        )

        self.sprite_root = (
            self.root / "assets/characters/sprites"
        )

    def load_into(self, animator):
        class_id = animator.class_id
        fw = int(self.config["frame_width"])
        fh = int(self.config["frame_height"])
        scale = int(self.config["display_scale"])

        directions = self.config["directions"]
        states = self.config["states"]

        loaded = []
        missing = []

        for state, count in states.items():
            path = (
                self.sprite_root
                / class_id
                / f"{state}.png"
            )

            if not path.exists():
                missing.append(str(path.relative_to(self.root)))
                continue

            sheet = pygame.image.load(str(path)).convert_alpha()

            expected = (fw * count, fh * len(directions))

            if sheet.get_size() != expected:
                raise ValueError(
                    f"精靈圖尺寸錯誤：{path.name} "
                    f"{sheet.get_size()}，應為 {expected}"
                )

            for row, direction in enumerate(directions):
                frames = []

                for column in range(count):
                    area = pygame.Rect(
                        column * fw,
                        row * fh,
                        fw,
                        fh
                    )

                    frame = sheet.subsurface(area).copy()

                    if scale != 1:
                        frame = pygame.transform.scale(
                            frame,
                            (fw * scale, fh * scale)
                        )

                    frames.append(frame)

                animator.register(
                    state, direction, frames
                )

            loaded.append(state)

        return {
            "class_id": class_id,
            "loaded": loaded,
            "missing": missing
        }
