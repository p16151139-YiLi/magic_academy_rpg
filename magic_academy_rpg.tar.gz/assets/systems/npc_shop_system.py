"""輕量 NPC / 商店 / 任務互動；無人物立繪或額外圖片。"""
import json, math, random
from pathlib import Path
import pygame

class NPCShopSystem:
    GOODS={
      'item_shop':[('小型生命藥水',30),('小型魔力藥水',40),('回城卷軸',100)],
      'weapon_shop':[('學徒木杖',120),('青銅短劍',180),('初級魔導書',250)]}
    def __init__(self, scene):
        self.scene=scene
        self.positions={}
        self.steps={}
        self.dialogue=None
        self.shop=None
        self.selected=0
        self.gold=500
        self.bag={}
        self.quests={}
        self.font=scene.ctx.font_small
        self.random=random.Random(481)
    def npcs(self):
        result=[]
        for npc in self.scene.map_data.get('npcs',[]):
            if npc.get('requires_quest') and not self.quests.get(npc['requires_quest']):continue
            result.append(npc)
        return result
    def pos(self,npc):
        key=(self.scene.map_id,npc['id'])
        if key not in self.positions:self.positions[key]=pygame.Vector2(npc['position'])
        return self.positions[key]
    def update(self,dt):
        if self.dialogue or self.shop or self.scene.player_menu.opened:return
        for npc in self.npcs():
            if npc.get('role') not in ('wander','patrol'):continue
            key=(self.scene.map_id,npc['id']); p=self.pos(npc)
            direction,t=self.steps.get(key,(pygame.Vector2(),0))
            t-=dt
            if t<=0:
                direction=pygame.Vector2(self.random.choice([-1,0,1]),self.random.choice([-1,0,1]))
                if direction.length_squared():direction.normalize_ip()
                t=self.random.uniform(0.7,2.1)
            area=npc.get('area',[p.x-50,p.y-50,p.x+50,p.y+50]);new=p+direction*40*dt
            footprint=pygame.Rect(round(new.x-10),round(new.y-8),20,16)
            if area[0]<=new.x<=area[2] and area[1]<=new.y<=area[3] and not any(footprint.colliderect(o) for o in self.scene.player_world.get_obstacles()):p.update(new)
            else:t=0
            self.steps[key]=(direction,t)
    def nearby(self):
        pp=pygame.Vector2(self.scene.player.rect.center)
        candidates=[(pp.distance_to(self.pos(n)),n) for n in self.npcs()]
        candidates=[(d,n) for d,n in candidates if d<95]
        return min(candidates,key=lambda x:x[0])[1] if candidates else None
    def interact(self):
        if self.shop:return True
        if self.dialogue:
            self.dialogue['index']+=1
            if self.dialogue['index']>=len(self.dialogue['npc'].get('dialogue',[])):
                npc=self.dialogue['npc'];self.dialogue=None
                if npc.get('role')=='merchant':self.shop=npc['shop'];self.selected=0
                if npc['id']=='edwin':self.quests['ancient_record']=True
            return True
        npc=self.nearby()
        if not npc:return False
        self.dialogue={'npc':npc,'index':0}
        return True
    def handle_key(self,key):
        if self.dialogue:
            if key in (pygame.K_e,pygame.K_RETURN,pygame.K_SPACE):self.interact()
            elif key==pygame.K_ESCAPE:self.dialogue=None
            return True
        if not self.shop:return False
        goods=self.GOODS[self.shop]
        if key in (pygame.K_ESCAPE,pygame.K_BACKSPACE):self.shop=None
        elif key in (pygame.K_DOWN,pygame.K_s):self.selected=(self.selected+1)%len(goods)
        elif key in (pygame.K_UP,pygame.K_w):self.selected=(self.selected-1)%len(goods)
        elif key in (pygame.K_RETURN,pygame.K_e):
            name,price=goods[self.selected]
            if self.gold>=price:
                self.gold-=price;self.bag[name]=self.bag.get(name,0)+1
                self.scene.player_world.show_message('購買成功：'+name)
            else:self.scene.player_world.show_message('金幣不足')
        return True
    def draw_npcs(self,screen):
        ox,oy=self.scene.camera.x,self.scene.camera.y
        for npc in self.npcs():
            p=self.pos(npc);x,y=round(p.x-ox),round(p.y-oy)
            if not (-35<x<screen.get_width()+35 and -40<y<screen.get_height()+40):continue
            # 傳統像素風小人：陰影、鞋、衣服、頭髮、膚色，無立繪
            c=npc.get('color',[120,120,165]);pygame.draw.ellipse(screen,(29,24,31),(x-14,y-5,28,10))
            pygame.draw.rect(screen,(47,40,54),(x-10,y-8,8,9));pygame.draw.rect(screen,(47,40,54),(x+3,y-8,8,9))
            pygame.draw.rect(screen,c,(x-13,y-30,26,25));pygame.draw.rect(screen,(229,184,147),(x-10,y-43,20,18))
            pygame.draw.rect(screen,(66,49,54),(x-12,y-46,24,8));pygame.draw.rect(screen,(40,34,48),(x-6,y-32,4,3));pygame.draw.rect(screen,(40,34,48),(x+4,y-32,4,3))
            if self.nearby() is npc:
                label=self.font.render(npc['name']+'  E 交談',True,(250,232,185));bg=label.get_rect(midbottom=(x,y-52)).inflate(14,9)
                pygame.draw.rect(screen,(35,32,55),bg,border_radius=5);screen.blit(label,label.get_rect(center=bg.center))
    def draw_overlay(self,screen):
        if not self.shop and not self.dialogue:return
        sw,sh=screen.get_size();panel=pygame.Rect(sw//2-330,sh-255,660,220)
        if self.shop:panel=pygame.Rect(sw//2-340,sh//2-205,680,410)
        pygame.draw.rect(screen,(26,27,48),panel,border_radius=11);pygame.draw.rect(screen,(206,173,103),panel,3,border_radius=11)
        if self.dialogue:
            npc=self.dialogue['npc'];index=min(self.dialogue['index'],len(npc['dialogue'])-1)
            lines=[npc['name'],npc['dialogue'][index],'E / Enter：繼續    Esc：離開']
        else:
            goods=self.GOODS[self.shop];lines=[('星露雜貨店' if self.shop=='item_shop' else '赤鐵武器鋪')+'     金幣：'+str(self.gold)]
            lines += [('▶ ' if i==self.selected else '   ')+name+'    '+str(price)+' G   (持有 '+str(self.bag.get(name,0))+')' for i,(name,price) in enumerate(goods)]
            lines += ['↑↓ 選擇    Enter / E 購買    Esc 離開']
        for i,line in enumerate(lines):
            text=self.font.render(line,True,(245,224,173) if i==0 else (231,230,239));screen.blit(text,(panel.x+30,panel.y+27+i*51))
