
import pygame
from pathlib import Path


class FontManager:

    def __init__(self, base_dir):

        # 字型檔案位置
        self.font_path = (
            Path(base_dir)
            / "assets"
            / "fonts"
            / "NotoSansTC-Regular.ttf"
        )

        # 字型快取
        self.font_cache = {}

        # 確認字型檔存在
        if not self.font_path.exists():
            raise FileNotFoundError(
                f"找不到中文字型：{self.font_path}"
            )

    def get(self, size):

        # 如果字型尚未載入，就載入一次
        if size not in self.font_cache:

            self.font_cache[size] = pygame.font.Font(
                str(self.font_path),
                size
            )

        return self.font_cache[size]

    def render(
        self,
        text,
        size,
        color=(255, 255, 255),
        antialias=True
    ):

        font = self.get(size)

        return font.render(
            str(text),
            antialias,
            color
        )

    def clear(self):

        self.font_cache.clear()
