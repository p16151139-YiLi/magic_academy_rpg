import pygame
from scenes.scene_base import BaseScene


class CreditsScene(BaseScene):

    def __init__(self, ctx):
        super().__init__(ctx)
        self.back_button = pygame.Rect(500, 510, 280, 55)

    def draw(self):
        ctx = self.ctx
        ctx.screen.fill(ctx.colors["background"])

        ctx.draw_panel(pygame.Rect(300, 120, 680, 480))

        ctx.draw_text(
            "製作團隊",
            ctx.font_large,
            ctx.colors["gold"],
            640, 210
        )

        ctx.draw_text(
            ctx.game_title,
            ctx.font_small,
            ctx.colors["white"],
            640, 300
        )

        ctx.draw_text(
            "Version 0.1.0",
            ctx.font_small,
            ctx.colors["gray"],
            640, 360
        )

        ctx.draw_button(
            self.back_button,
            "返回",
            pygame.mouse.get_pos()
        )

    def handle_event(self, event):

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:

            if self.back_button.collidepoint(event.pos):
                return "title"

        return None
