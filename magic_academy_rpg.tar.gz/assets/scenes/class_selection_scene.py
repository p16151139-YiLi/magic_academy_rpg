import pygame
from scenes.scene_base import BaseScene


class ClassSelectionScene(BaseScene):

    def __init__(self, ctx):
        super().__init__(ctx)

        self.card_rects = [
            pygame.Rect(55, 185, 365, 390),
            pygame.Rect(457, 185, 365, 390),
            pygame.Rect(859, 185, 365, 390)
        ]

        self.confirm_button = pygame.Rect(470, 610, 340, 65)
        self.back_button = pygame.Rect(30, 30, 145, 50)

    def draw_wrapped_text(
        self,
        text,
        font,
        color,
        rect,
        y,
        max_lines=2
    ):
        """讓職業介紹自動換行。"""

        lines = []
        current = ""

        for char in str(text):

            test = current + char

            if font.size(test)[0] <= rect.width:
                current = test
            else:
                if current:
                    lines.append(current)

                current = char

        if current:
            lines.append(current)

        for i, line in enumerate(lines[:max_lines]):

            self.ctx.draw_text(
                line,
                font,
                color,
                rect.centerx,
                y + i * 25
            )

    def draw(self):
        ctx = self.ctx
        screen = ctx.screen
        mouse = pygame.mouse.get_pos()

        screen.fill((19, 22, 43))

        # 標題
        ctx.draw_text(
            "選擇你的魔法職業",
            ctx.font_large,
            (238, 220, 170),
            640, 65
        )

        ctx.draw_text(
            "Choose Your Class",
            ctx.font_small,
            (165, 177, 205),
            640, 115
        )

        ctx.draw_button(
            self.back_button,
            "返回",
            mouse
        )

        for index, character_class in enumerate(ctx.classes):

            rect = self.card_rects[index]

            selected = index == ctx.selected_class
            hovered = rect.collidepoint(mouse)

            # 滑鼠懸停或已選取時反黃
            if hovered:
                card_color = (100, 83, 42)
                border_color = (255, 225, 120)

            elif selected:
                card_color = (75, 65, 42)
                border_color = (238, 203, 115)

            else:
                card_color = (33, 39, 65)
                border_color = (91, 105, 139)

            pygame.draw.rect(
                screen,
                card_color,
                rect,
                border_radius=15
            )

            pygame.draw.rect(
                screen,
                border_color,
                rect,
                3 if selected or hovered else 2,
                border_radius=15
            )

            # 職業名稱
            ctx.draw_text(
                character_class["name"],
                ctx.font_medium,
                (255, 225, 155),
                rect.centerx,
                rect.y + 32
            )

            # 英文副標題
            ctx.draw_text(
                character_class.get("subtitle", ""),
                ctx.font_small,
                (190, 200, 225),
                rect.centerx,
                rect.y + 68
            )

            # 職業介紹
            self.draw_wrapped_text(
                character_class.get("description", ""),
                ctx.font_small,
                ctx.colors["white"],
                rect.inflate(-35, 0),
                rect.y + 105,
                max_lines=2
            )

            # 戰鬥風格
            ctx.draw_text(
                "戰鬥風格：" + character_class.get("combat_style", ""),
                ctx.font_small,
                (240, 215, 150),
                rect.centerx,
                rect.y + 165
            )

            ctx.draw_text(
                "攻擊距離：" + character_class.get("attack_range", ""),
                ctx.font_small,
                ctx.colors["white"],
                rect.centerx,
                rect.y + 198
            )

            ctx.draw_text(
                "生存能力：" + character_class.get("survivability", ""),
                ctx.font_small,
                ctx.colors["white"],
                rect.centerx,
                rect.y + 230
            )

            # 能力值
            stats = character_class.get("stats", {})

            ctx.draw_text(
                f"HP {stats.get('hp', 0)}   MP {stats.get('mp', 0)}",
                ctx.font_small,
                (175, 220, 190),
                rect.centerx,
                rect.y + 270
            )

            ctx.draw_text(
                f"ATK {stats.get('attack', 0)}   DEF {stats.get('defense', 0)}",
                ctx.font_small,
                (175, 220, 190),
                rect.centerx,
                rect.y + 300
            )

            # 職業特色
            mechanics = character_class.get("mechanics", [])

            for i, feature in enumerate(mechanics[:2]):

                ctx.draw_text(
                    "・" + feature,
                    ctx.font_small,
                    ctx.colors["white"],
                    rect.centerx,
                    rect.y + 345 + i * 25
                )

        # 確認按鈕
        ctx.draw_button(
            self.confirm_button,
            "確認職業",
            mouse
        )

    def handle_event(self, event):

        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return None

        pos = event.pos

        # 返回主選單
        if self.back_button.collidepoint(pos):
            return "title"

        # 選擇職業
        for index, rect in enumerate(self.card_rects):

            if rect.collidepoint(pos):
                self.ctx.selected_class = index
                return None

        # 確認職業
        if self.confirm_button.collidepoint(pos):

            self.ctx.selected_character_class = (
                self.ctx.classes[self.ctx.selected_class]
            )

            return "game"

        return None
