import pygame
from scenes.scene_base import BaseScene


class ClassSelectionScene(BaseScene):

    def __init__(self, ctx):
        super().__init__(ctx)

        self.cards = [
            pygame.Rect(55, 175, 365, 405),
            pygame.Rect(457, 175, 365, 405),
            pygame.Rect(859, 175, 365, 405),
        ]

        self.back_button = pygame.Rect(35, 30, 150, 52)
        self.confirm_button = pygame.Rect(470, 615, 340, 62)

        self.gold = (235, 190, 95)
        self.bright_gold = (255, 225, 110)
        self.white = (245, 240, 255)
        self.gray = (170, 180, 205)

        self.themes = [
            {
                "background": (30, 39, 75),
                "accent": (115, 155, 245),
                "symbol": "✦",
            },
            {
                "background": (72, 38, 48),
                "accent": (235, 145, 105),
                "symbol": "◆",
            },
            {
                "background": (29, 65, 64),
                "accent": (125, 215, 180),
                "symbol": "✧",
            },
        ]

    def draw_background(self):
        screen = self.ctx.screen
        screen.fill((15, 13, 35))

        pygame.draw.circle(
            screen, (35, 30, 70),
            (640, 360), 350
        )

        pygame.draw.circle(
            screen, (76, 61, 115),
            (640, 360), 335, 2
        )

        pygame.draw.circle(
            screen, (48, 42, 88),
            (640, 360), 300, 1
        )

        pygame.draw.line(
            screen, self.gold,
            (370, 140), (910, 140), 2
        )

        pygame.draw.circle(
            screen, self.bright_gold,
            (640, 140), 5
        )

    def draw_button(self, rect, label, mouse, enabled=True):
        screen = self.ctx.screen
        hovered = enabled and rect.collidepoint(mouse)

        background = (
            (100, 78, 40)
            if hovered else (43, 36, 77)
        )

        border = (
            self.bright_gold if hovered
            else self.gold
        )

        pygame.draw.rect(
            screen, background, rect,
            border_radius=12
        )

        pygame.draw.rect(
            screen, border, rect, 2,
            border_radius=12
        )

        self.ctx.draw_text(
            label,
            self.ctx.font_medium,
            self.bright_gold if hovered else self.white,
            rect.centerx,
            rect.centery
        )

    def draw_wrapped_text(
        self, text, font, color,
        center_x, start_y, max_width,
        max_lines=2, line_height=25
    ):
        lines = []
        current = ""

        for char in str(text):
            trial = current + char

            if font.size(trial)[0] <= max_width:
                current = trial
            else:
                if current:
                    lines.append(current)
                current = char

        if current:
            lines.append(current)

        for index, line in enumerate(lines[:max_lines]):
            self.ctx.draw_text(
                line, font, color,
                center_x,
                start_y + index * line_height
            )

    def draw_card(self, index, info, mouse):
        screen = self.ctx.screen
        ctx = self.ctx

        rect = self.cards[index]
        theme = self.themes[index]

        selected = index == ctx.selected_class
        hovered = rect.collidepoint(mouse)

        # 陰影
        pygame.draw.rect(
            screen,
            (7, 7, 20),
            rect.move(5, 7),
            border_radius=16
        )

        # 卡片底色
        background = theme["background"]

        if hovered:
            background = tuple(
                min(255, c + 15)
                for c in background
            )

        pygame.draw.rect(
            screen,
            background,
            rect,
            border_radius=16
        )

        # 選取或懸停時金色邊框
        if hovered:
            border = self.bright_gold
            border_width = 4
        elif selected:
            border = self.gold
            border_width = 3
        else:
            border = theme["accent"]
            border_width = 2

        pygame.draw.rect(
            screen,
            border,
            rect,
            border_width,
            border_radius=16
        )

        # 內框
        inner = rect.inflate(-16, -16)
        pygame.draw.rect(
            screen,
            theme["accent"],
            inner,
            1,
            border_radius=12
        )

        cx = rect.centerx
        top = rect.top

        # 魔法符號
        ctx.draw_text(
            theme["symbol"],
            ctx.font_large,
            theme["accent"],
            cx,
            top + 43
        )

        # 職業名稱
        ctx.draw_text(
            info["name"],
            ctx.font_medium,
            self.bright_gold if hovered else self.white,
            cx,
            top + 91
        )

        # 英文副標題
        ctx.draw_text(
            info.get("subtitle", ""),
            ctx.font_small,
            theme["accent"],
            cx,
            top + 125
        )

        pygame.draw.line(
            screen,
            theme["accent"],
            (rect.left + 45, top + 151),
            (rect.right - 45, top + 151),
            1
        )

        # 職業介紹
        self.draw_wrapped_text(
            info.get("description", ""),
            ctx.font_small,
            self.white,
            cx,
            top + 178,
            rect.width - 40,
            max_lines=2
        )

        # 戰鬥特性
        ctx.draw_text(
            "戰鬥風格：" + info.get("combat_style", ""),
            ctx.font_small,
            self.bright_gold,
            cx,
            top + 235
        )

        ctx.draw_text(
            "攻擊距離：" + info.get("attack_range", ""),
            ctx.font_small,
            self.white,
            cx,
            top + 267
        )

        ctx.draw_text(
            "生存能力：" + info.get("survivability", ""),
            ctx.font_small,
            self.white,
            cx,
            top + 298
        )

        stats = info.get("stats", {})

        pygame.draw.line(
            screen,
            theme["accent"],
            (rect.left + 45, top + 320),
            (rect.right - 45, top + 320),
            1
        )

        ctx.draw_text(
            f"HP {stats.get('hp', 0)}"
            f"    MP {stats.get('mp', 0)}",
            ctx.font_small,
            (185, 235, 200),
            cx,
            top + 344
        )

        ctx.draw_text(
            f"ATK {stats.get('attack', 0)}"
            f"    DEF {stats.get('defense', 0)}",
            ctx.font_small,
            (185, 235, 200),
            cx,
            top + 374
        )

        # 已選取標記，放在卡片右上角
        if selected:
            pygame.draw.circle(
                screen,
                self.bright_gold,
                (rect.right - 24, rect.top + 24),
                11
            )
            pygame.draw.circle(
                screen,
                (45, 35, 70),
                (rect.right - 24, rect.top + 24),
                5
            )

    def draw(self):
        ctx = self.ctx
        mouse = pygame.mouse.get_pos()

        self.draw_background()

        ctx.draw_text(
            "選擇你的魔法職業",
            ctx.font_large,
            self.bright_gold,
            640, 65
        )

        ctx.draw_text(
            "Choose Your Class",
            ctx.font_small,
            self.gray,
            640, 112
        )

        self.draw_button(
            self.back_button,
            "返回",
            mouse
        )

        for index, info in enumerate(ctx.classes[:3]):
            self.draw_card(index, info, mouse)

        self.draw_button(
            self.confirm_button,
            "確認職業",
            mouse
        )

    def handle_event(self, event):

        if (
            event.type != pygame.MOUSEBUTTONDOWN
            or event.button != 1
        ):
            return None

        if self.back_button.collidepoint(event.pos):
            return "title"

        for index, rect in enumerate(self.cards):
            if rect.collidepoint(event.pos):
                self.ctx.selected_class = index
                return None

        if self.confirm_button.collidepoint(event.pos):
            self.ctx.selected_character_class = (
                self.ctx.classes[self.ctx.selected_class]
            )
            return "game"

        return None
