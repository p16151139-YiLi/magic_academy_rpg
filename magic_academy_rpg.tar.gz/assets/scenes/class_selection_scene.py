import pygame
from scenes.scene_base import BaseScene


class ClassSelectionScene(BaseScene):

    def __init__(self, ctx):
        super().__init__(ctx)

        self.card_rects = [
            pygame.Rect(55, 185, 365, 390),
            pygame.Rect(457, 185, 365, 390),
            pygame.Rect(859, 185, 365, 390)
        ]

        self.confirm_button = pygame.Rect(470, 610, 340, 65)
        self.back_button = pygame.Rect(30, 30, 145, 50)

    def draw(self):
        ctx = self.ctx
        ctx.screen.fill((19, 22, 43))

        ctx.draw_text(
            "選擇你的魔法職業",
            ctx.font_large,
            (238, 220, 170),
            640, 65
        )

        ctx.draw_text(
            "Choose Your Class",
            ctx.font_small,
            (165, 177, 205),
            640, 115
        )

        ctx.draw_button(
            self.back_button,
            "返回",
            pygame.mouse.get_pos()
        )

        for index, character_class in enumerate(ctx.classes):

            rect = self.card_rects[index]
            selected = index == ctx.selected_class

            card_color = (48, 57, 87) if selected else (33, 39, 65)
            border_color = (238, 203, 115) if selected else (91, 105, 139)

            pygame.draw.rect(
                ctx.screen, card_color, rect, border_radius=15
            )

            pygame.draw.rect(
                ctx.screen, border_color, rect, 3, border_radius=15
            )

            ctx.draw_text(
                character_class["name"],
                ctx.font_medium,
                (255, 225, 155),
                rect.centerx, rect.y + 35
            )

            ctx.draw_text(
                character_class.get("subtitle", ""),
                ctx.font_small,
                (174, 190, 220),
                rect.centerx, rect.y + 75
            )

            ctx.draw_text(
                character_class.get("combat_style", ""),
                ctx.font_small,
                (225, 230, 245),
                rect.centerx, rect.y + 115
            )

            ctx.draw_text(
                character_class.get("attack_range", ""),
                ctx.font_small,
                (205, 215, 235),
                rect.centerx, rect.y + 150
            )

            stats = character_class.get("stats", {})

            ctx.draw_text(
                f"HP {stats.get('hp', 0)}    MP {stats.get('mp', 0)}",
                ctx.font_small,
                ctx.colors["white"],
                rect.centerx, rect.y + 205
            )

            ctx.draw_text(
                f"ATK {stats.get('attack', 0)}    DEF {stats.get('defense', 0)}",
                ctx.font_small,
                ctx.colors["white"],
                rect.centerx, rect.y + 240
            )

            mechanics = character_class.get("mechanics", [])

            for i, feature in enumerate(mechanics[:3]):
                ctx.draw_text(
                    feature,
                    ctx.font_small,
                    ctx.colors["green"],
                    rect.centerx,
                    rect.y + 290 + i * 27
                )

        ctx.draw_button(
            self.confirm_button,
            "確認職業",
            pygame.mouse.get_pos()
        )

    def handle_event(self, event):

        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return None

        pos = event.pos

        if self.back_button.collidepoint(pos):
            return "title"

        for index, rect in enumerate(self.card_rects):

            if rect.collidepoint(pos):
                self.ctx.selected_class = index
                return None

        if self.confirm_button.collidepoint(pos):

            self.ctx.selected_character_class = self.ctx.classes[
                self.ctx.selected_class
            ]

            return "game"

        return None
