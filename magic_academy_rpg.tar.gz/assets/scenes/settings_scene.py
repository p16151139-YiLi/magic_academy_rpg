import pygame
from scenes.scene_base import BaseScene


class SettingsScene(BaseScene):

    MUSIC_Y = 310
    SFX_Y = 415
    SLIDER_X = 450
    SLIDER_WIDTH = 380

    def __init__(self, ctx):
        super().__init__(ctx)

        self.fullscreen_button = pygame.Rect(430, 490, 420, 55)
        self.back_button = pygame.Rect(500, 565, 280, 50)

        self.dragging = None

    def draw_slider(self, y, value):
        ctx = self.ctx
        x = self.SLIDER_X
        width = self.SLIDER_WIDTH

        pygame.draw.line(
            ctx.screen, ctx.colors["gray"],
            (x, y), (x + width, y), 6
        )

        pygame.draw.line(
            ctx.screen, ctx.colors["gold"],
            (x, y), (x + int(width * value), y), 6
        )

        pygame.draw.circle(
            ctx.screen, ctx.colors["white"],
            (x + int(width * value), y), 11
        )

    def draw(self):
        ctx = self.ctx

        ctx.screen.fill(ctx.colors["background"])

        ctx.draw_panel(pygame.Rect(300, 100, 680, 550))

        ctx.draw_text(
            "遊戲設定",
            ctx.font_large,
            ctx.colors["gold"],
            640, 165
        )

        ctx.draw_text(
            f"音樂音量：{int(ctx.music_volume * 100)}%",
            ctx.font_medium,
            ctx.colors["white"],
            640, 265
        )

        self.draw_slider(self.MUSIC_Y, ctx.music_volume)

        ctx.draw_text(
            f"音效音量：{int(ctx.sfx_volume * 100)}%",
            ctx.font_medium,
            ctx.colors["white"],
            640, 370
        )

        self.draw_slider(self.SFX_Y, ctx.sfx_volume)

        ctx.draw_button(
            self.fullscreen_button,
            "切換全螢幕",
            pygame.mouse.get_pos()
        )

        ctx.draw_button(
            self.back_button,
            "返回",
            pygame.mouse.get_pos()
        )

    def update_slider(self, pos, slider):
        value = max(
            0.0,
            min(1.0, (pos[0] - self.SLIDER_X) / self.SLIDER_WIDTH)
        )

        if slider == "music":
            self.ctx.music_volume = value
            self.ctx.audio.set_music_volume(value)

        elif slider == "sfx":
            self.ctx.sfx_volume = value
            self.ctx.audio.set_sfx_volume(value)

    def handle_event(self, event):

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:

            if self.fullscreen_button.collidepoint(event.pos):
                self.ctx.change_fullscreen()
                return None

            if self.back_button.collidepoint(event.pos):
                self.ctx.save_settings()
                return "title"

            if abs(event.pos[1] - self.MUSIC_Y) <= 18:
                self.dragging = "music"
                self.update_slider(event.pos, self.dragging)
                return None

            if abs(event.pos[1] - self.SFX_Y) <= 18:
                self.dragging = "sfx"
                self.update_slider(event.pos, self.dragging)
                return None

        elif event.type == pygame.MOUSEMOTION:

            if self.dragging and event.buttons[0]:
                self.update_slider(event.pos, self.dragging)

        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:

            if self.dragging:
                self.update_slider(event.pos, self.dragging)
                self.dragging = None
                self.ctx.save_settings()

        return None
