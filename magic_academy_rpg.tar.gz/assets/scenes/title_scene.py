import pygame
from scenes.scene_base import BaseScene


class TitleScene(BaseScene):

    def __init__(self, ctx):
        super().__init__(ctx)

        self.buttons = {
            "start": pygame.Rect(60, 290, 350, 75),
            "settings": pygame.Rect(60, 380, 350, 75),
            "credits": pygame.Rect(60, 470, 350, 75),
            "quit": pygame.Rect(60, 560, 350, 75),
        }

    def draw(self):
        ctx = self.ctx

        if ctx.title_background is not None:
            ctx.screen.blit(ctx.title_background, (0, 0))
        else:
            ctx.screen.fill(ctx.colors["background"])

            ctx.draw_text(
                "MAGIC ACADEMY",
                ctx.font_large,
                ctx.colors["gold"],
                640, 220
            )

            ctx.draw_text(
                "The Lost Ancient Magic",
                ctx.font_medium,
                ctx.colors["white"],
                640, 275
            )

        mouse = pygame.mouse.get_pos()

        for rect in self.buttons.values():
            if rect.collidepoint(mouse):
                highlight = pygame.Surface(
                    rect.size, pygame.SRCALPHA
                )
                highlight.fill((255, 220, 140, 35))
                ctx.screen.blit(highlight, rect.topleft)

    def handle_event(self, event):

        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return None

        for name, rect in self.buttons.items():

            if rect.collidepoint(event.pos):

                if name == "quit":
                    return "quit"

                return {
                    "start": "class_selection",
                    "settings": "settings",
                    "credits": "credits"
                }[name]

        return None
