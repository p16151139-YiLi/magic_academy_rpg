import pygame
from scenes.scene_base import BaseScene


class GameScene(BaseScene):

    def __init__(self, ctx):
        super().__init__(ctx)
        self.back_button = pygame.Rect(500, 520, 280, 55)

    def draw(self):
        ctx = self.ctx
        ctx.screen.fill(ctx.colors["background"])

        ctx.draw_text(
            "魔法學院冒險即將開始",
            ctx.font_large,
            ctx.colors["gold"],
            640, 250
        )

        selected = ctx.selected_character_class

        ctx.draw_text(
            f"目前職業：{selected['name']}",
            ctx.font_medium,
            ctx.colors["white"],
            640, 330
        )

        ctx.draw_text(
            "正式地圖、角色與戰鬥系統將於後續階段加入",
            ctx.font_small,
            ctx.colors["gray"],
            640, 400
        )

        ctx.draw_button(
            self.back_button,
            "返回主選單",
            pygame.mouse.get_pos()
        )

    def handle_event(self, event):

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:

            if self.back_button.collidepoint(event.pos):
                return "title"

        return None
