import pygame
from scenes.scene_base import BaseScene


class GameScene(BaseScene):

    def __init__(self, ctx):
        super().__init__(ctx)

        self.panel = pygame.Rect(260, 85, 760, 550)
        self.back_button = pygame.Rect(475, 555, 330, 58)

        self.gold = (235, 190, 95)
        self.bright_gold = (255, 225, 110)
        self.white = (245, 240, 255)
        self.gray = (170, 180, 205)

    def draw(self):
        ctx = self.ctx
        screen = ctx.screen
        mouse = pygame.mouse.get_pos()

        screen.fill((15, 13, 35))

        pygame.draw.circle(
            screen, (35, 30, 70),
            (640, 360), 330
        )

        pygame.draw.circle(
            screen, (75, 60, 115),
            (640, 360), 310, 2
        )

        pygame.draw.rect(
            screen, (7, 7, 20),
            self.panel.move(8, 10),
            border_radius=18
        )

        pygame.draw.rect(
            screen, (28, 24, 57),
            self.panel,
            border_radius=18
        )

        pygame.draw.rect(
            screen, self.gold,
            self.panel, 3,
            border_radius=18
        )

        ctx.draw_text(
            "魔法學院冒險即將開始",
            ctx.font_large,
            self.bright_gold,
            640, 155
        )

        pygame.draw.line(
            screen, self.gold,
            (370, 215), (910, 215), 2
        )

        selected = ctx.selected_character_class

        if selected is None:
            selected = ctx.classes[ctx.selected_class]

        stats = selected.get("stats", {})

        ctx.draw_text(
            "目前選擇職業",
            ctx.font_small,
            self.gray,
            640, 255
        )

        ctx.draw_text(
            selected["name"],
            ctx.font_large,
            self.bright_gold,
            640, 305
        )

        ctx.draw_text(
            selected.get("subtitle", ""),
            ctx.font_small,
            self.gray,
            640, 345
        )

        ctx.draw_text(
            selected.get("description", ""),
            ctx.font_small,
            self.white,
            640, 390
        )

        ctx.draw_text(
            f"HP {stats.get('hp', 0)}"
            f"    MP {stats.get('mp', 0)}"
            f"    ATK {stats.get('attack', 0)}"
            f"    DEF {stats.get('defense', 0)}",
            ctx.font_small,
            (175, 225, 190),
            640, 440
        )

        ctx.draw_text(
            "正式冒險地圖與戰鬥系統將於第二階段加入",
            ctx.font_small,
            self.gray,
            640, 500
        )

        hovered = self.back_button.collidepoint(mouse)

        pygame.draw.rect(
            screen,
            (105, 82, 42) if hovered else (45, 38, 80),
            self.back_button,
            border_radius=12
        )

        pygame.draw.rect(
            screen,
            self.bright_gold if hovered else self.gold,
            self.back_button,
            2,
            border_radius=12
        )

        ctx.draw_text(
            "返回主選單",
            ctx.font_medium,
            self.bright_gold if hovered else self.white,
            self.back_button.centerx,
            self.back_button.centery
        )

    def handle_event(self, event):
        if (
            event.type == pygame.MOUSEBUTTONDOWN
            and event.button == 1
        ):
            if self.back_button.collidepoint(event.pos):
                return "title"

        return None
