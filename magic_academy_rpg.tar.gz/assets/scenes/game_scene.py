# PLAYER_MENU_INTEGRATION_V1
from ui.player_menu import PlayerMenu

from pathlib import Path

import pygame

from scenes.scene_base import BaseScene
from systems.map_manager import MapManager
from systems.map_renderer import MapRenderer
from systems.camera import Camera


class GameScene(BaseScene):

    def __init__(self, ctx):
        super().__init__(ctx)

        self.root = Path(__file__).resolve().parents[1]

        # 地圖管理器
        self.map_manager = MapManager(self.root)

        # 地圖渲染器
        self.map_renderer = MapRenderer(self.root)

        # 攝影機
        self.camera = Camera(
            ctx.screen.get_width(),
            ctx.screen.get_height()
        )

        self.map_id = "academy_entrance"

        # 讀取地圖 JSON
        self.map_data = self.map_manager.load_map(
            self.map_id
        )

        # 取得角色預定出生位置
        self.spawn = self.map_manager.get_spawn()

        # 依出生位置設定攝影機
        self.camera.follow(
            self.spawn[0],
            self.spawn[1],
            self.map_data["width"],
            self.map_data["height"]
        )

        # 延後圖片載入，確保顯示畫面已初始化
        self.map_loaded = False

        # 返回按鈕
        self.back_button = pygame.Rect(
            18, 18, 190, 48
        )

        # 地圖資訊面板
        self.info_panel = pygame.Rect(
            18, 80, 280, 84
        )
        # 初始化玩家介面
        self.player_menu = PlayerMenu(self.ctx.screen)

        # STAGE4_PLAYER_WORLD_INTEGRATION
        from systems.player_world_bridge import PlayerWorldBridge
        self.player_world = PlayerWorldBridge(self)
        self.player = self.player_world.player

    def ensure_map_loaded(self):
        """首次繪製時載入地圖圖片。"""

        if not self.map_loaded:
            self.map_renderer.load(self.map_data)
            self.map_loaded = True

    def draw(self):
        ctx = self.ctx
        screen = ctx.screen

        self.ensure_map_loaded()

        screen.fill((20, 25, 30))

        # 依序繪製地圖圖層
        self.map_renderer.draw_ground(
            screen, self.camera
        )

        self.map_renderer.draw_objects(
            screen, self.camera
        )

        # 前景遮擋層
        # 玩家繪製於物件與前景之間
        self.player_world.draw(screen)

        self.map_renderer.draw_foreground(
            screen, self.camera
        )

        # ----------------------------------
        # 返回主選單按鈕
        # ----------------------------------

        mouse = pygame.mouse.get_pos()
        hovered = self.back_button.collidepoint(mouse)

        pygame.draw.rect(
            screen,
            (65, 55, 95) if hovered else (30, 28, 55),
            self.back_button,
            border_radius=8
        )

        pygame.draw.rect(
            screen,
            (235, 190, 95),
            self.back_button,
            2,
            border_radius=8
        )

        ctx.draw_text(
            "返回主選單",
            ctx.font_small,
            (245, 240, 255),
            self.back_button.centerx,
            self.back_button.centery
        )

        # ----------------------------------
        # 地圖資訊
        # ----------------------------------

        pygame.draw.rect(
            screen,
            (28, 30, 48),
            self.info_panel,
            border_radius=8
        )

        pygame.draw.rect(
            screen,
            (150, 135, 90),
            self.info_panel,
            2,
            border_radius=8
        )

        ctx.draw_text(
            self.map_data["name"],
            ctx.font_small,
            (245, 225, 170),
            self.info_panel.centerx,
            108
        )

        ctx.draw_text(
            "第一章：魔法學院",
            ctx.font_small,
            (210, 215, 235),
            self.info_panel.centerx,
            140
        )
        # 地圖與場景繪製完成後，顯示玩家介面
        self.player_menu.draw()

    def update(self, dt):
        # 玩家移動尚未加入
        # 下一階段會在這裡更新角色與攝影機
        self.player_world.update(dt)

    def handle_event(self, event):

        # 玩家介面事件處理
        if self.player_menu.opened:
            self.player_menu.handle_event(event)
            return None

        # STAGE4_PORTAL_EVENT_INTEGRATION
        if self.player_world.handle_event(event):
            return None

        if event.type == pygame.KEYDOWN:
            shortcuts = {
                pygame.K_c: 0,
                pygame.K_i: 1,
                pygame.K_k: 2,
                pygame.K_m: 4,
                pygame.K_h: 5,
            }

            if event.key == pygame.K_TAB:
                self.player_menu.open()
                return None

            if event.key in shortcuts:
                self.player_menu.open(shortcuts[event.key])
                return None

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if self.back_button.collidepoint(event.pos):
                    return "title"

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                return "title"

        return None

    # INVENTORY_SERVICE_INTEGRATION_V1

    def get_item_service(self):
        from systems.item_service import ItemService

        if not hasattr(self, "_item_service"):
            self._item_service = ItemService()

        return self._item_service

    def inventory_snapshot(self):
        return self.get_item_service().refresh()

    def give_player_item(self, item_id, amount=1):
        return self.get_item_service().give_item(
            item_id, amount
        )

    def remove_player_item(self, item_id, amount=1):
        return self.get_item_service().take_item(
            item_id, amount
        )

    def use_player_item(self, item_id):
        return self.get_item_service().use_item(item_id)

    def equip_player_item(self, item_id):
        return self.get_item_service().equip_item(item_id)

    def unequip_player_item(self, slot):
        return self.get_item_service().unequip_item(slot)

    def get_player_resources(self):
        data = self.get_item_service().get_player()
        return {
            "hp": data.get("hp", 0),
            "max_hp": data.get("max_hp", 0),
            "mp": data.get("mp", 0),
            "max_mp": data.get("max_mp", 0)
        }

    def get_player_equipment_bonuses(self):
        return (
            self.get_item_service()
            .get_equipment_bonuses()
        )
