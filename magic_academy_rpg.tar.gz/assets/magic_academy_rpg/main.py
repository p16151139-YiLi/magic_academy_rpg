import pygame
import asyncio
import random
import math
from pathlib import Path

# =========================================================
# 魔法學院：失落的古代魔法
# Pygame + Pygbag 網頁版
# =========================================================
pygame.init()
WIDTH, HEIGHT = 960, 640
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("魔法學院：失落的古代魔法")
clock = pygame.time.Clock()
FPS = 60
BASE_DIR = Path(__file__).resolve().parent
FONT_FILE = BASE_DIR / "assets" / "fonts" / "NotoSansTC-Regular.ttf"

def get_font(size):
    # 網頁部署時請將 NotoSansTC-Regular.ttf 放入 assets/fonts/
    try:
        if FONT_FILE.exists():
            return pygame.font.Font(str(FONT_FILE), size)
    except Exception:
        pass
    return pygame.font.SysFont(["Microsoft JhengHei", "Noto Sans CJK TC", "sans"], size)

FONT_S = get_font(17)
FONT = get_font(22)
FONT_L = get_font(34)
FONT_XL = get_font(48)

WHITE=(245,245,255); BLACK=(15,15,25); GOLD=(245,205,90)
RED=(225,85,90); BLUE=(90,165,245); GREEN=(95,205,135)
PURPLE=(175,120,225); GRAY=(165,165,180); DARK=(25,22,45)

CLASSES = {
    "elementalist": {"name":"元素法師","hp":105,"mp":130,"atk":27,"desc":"遠距離元素魔法，擅長範圍傷害。"},
    "magic_swordsman": {"name":"魔法劍士","hp":155,"mp":95,"atk":34,"desc":"近戰能力優秀，生命與防禦較高。"},
    "dual_walker": {"name":"雙形態使者","hp":120,"mp":110,"atk":29,"desc":"可切換近戰與遠程形態，機動性高。"}
}
SKILLS = {
    "elementalist":["烈焰術","寒霜護盾","魔力共鳴"],
    "magic_swordsman":["弧月斬","守護姿態","戰意爆發"],
    "dual_walker":["雙影斬","迅捷步伐","靈能脈衝"]
}
SKILL_DESC = ["提升攻擊力","提升最大生命","提升最大魔力"]

# 場景：標題、職業選擇、學院、遺跡、勝利
scene = "menu"
running = True
selected_class = "elementalist"
player = pygame.Rect(460, 490, 34, 42)
player_facing = "up"
player_speed = 230
player_hp=105; player_max_hp=105; player_mp=130; player_max_mp=130
player_level=1; player_exp=0; exp_needed=100; attack_power=27; skill_points=0
gold=35
potions={"health":2,"mana":2}
materials={"魔物核心":0,"魔力結晶":0}
skill_levels={k:[0,0,0] for k in CLASSES}
dual_form=0
speed_boost_until=0
last_attack=0; last_skill=0; last_mp_regen=0; invincible_until=0
game_over=False

# 所有遊戲物件均有固定名稱，方便管理與辨識
OBJECTS = {
    "player": "玩家角色",
    "mentor_elara": "艾菈拉導師",
    "merchant_milo": "米洛商人",
    "slime_scout": "迷霧史萊姆",
    "ember_wolf": "餘燼狼",
    "rune_guardian": "符文守衛",
    "ancient_guardian": "古代魔法守護者",
    "academy_gate": "魔法學院大門",
    "ancient_portal": "古代遺跡傳送門"
}
mentor = pygame.Rect(105, 405, 38, 48)
merchant = pygame.Rect(810, 405, 38, 48)
obstacles = [
    pygame.Rect(220,180,120,52), pygame.Rect(620,180,120,52),
    pygame.Rect(385,265,190,48), pygame.Rect(110,300,110,38),
    pygame.Rect(740,300,110,38)
]
monster_templates = [
    {"name":"迷霧史萊姆","hp":55,"atk":8,"exp":25,"gold":8,"color":(100,205,150)},
    {"name":"餘燼狼","hp":85,"atk":12,"exp":40,"gold":13,"color":(225,115,75)},
    {"name":"符文守衛","hp":125,"atk":16,"exp":60,"gold":20,"color":(145,125,220)}
]
monster = pygame.Rect(450, 330, 42, 38)
monster_kind=0; monster_hp=55; monster_max_hp=55
monster_alive=True; monster_respawn_at=0; monster_direction=1
wave=1; wave_total=5; wave_defeated=0
boss = pygame.Rect(445,190,78,78)
boss_hp=520; boss_max_hp=520; boss_direction=1; boss_last_attack=0
projectiles=[]; enemy_projectiles=[]

# 劇情任務狀態
quest_state="intro"  # intro, gather, ready, boss, completed
dialogue_open=False; dialogue_page=0
inventory_open=False; shop_open=False; skill_tree_open=False
message="歡迎來到星霜魔法學院。"
message_until=0
story_log=[
    "序章：失落的古代魔法",
    "艾菈拉導師：學院地下的古代封印正在減弱。",
    "你必須調查異常魔力，找出封印失衡的原因。"
]
def now(): return pygame.time.get_ticks()
def set_message(text, duration=2600):
    global message,message_until
    message=text; message_until=now()+duration
def draw_text(text,x,y,color=WHITE,f=FONT):
    screen.blit(f.render(str(text),True,color),(x,y))
def center_text(text,y,color=WHITE,f=FONT):
    im=f.render(str(text),True,color); screen.blit(im,(WIDTH//2-im.get_width()//2,y))
def bar(x,y,w,h,value,maximum,color):
    pygame.draw.rect(screen,(48,42,62),(x,y,w,h))
    if maximum>0: pygame.draw.rect(screen,color,(x,y,max(0,min(w,int(w*value/maximum))),h))
    pygame.draw.rect(screen,WHITE,(x,y,w,h),1)
def near(rect,d=95):
    return abs(player.centerx-rect.centerx)<d and abs(player.centery-rect.centery)<d
def overlays():
    return inventory_open or shop_open or skill_tree_open or dialogue_open
def close_overlays():
    global inventory_open,shop_open,skill_tree_open,dialogue_open
    inventory_open=shop_open=skill_tree_open=dialogue_open=False

def reset_game():
    global player,player_hp,player_max_hp,player_mp,player_max_mp,player_level,player_exp
    global exp_needed,attack_power,skill_points,gold,potions,materials,skill_levels
    global quest_state,game_over,monster_alive,monster_hp,monster_max_hp,wave,wave_defeated
    global boss_hp,projectiles,enemy_projectiles,dual_form,invincible_until,last_attack,last_skill,last_mp_regen
    data=CLASSES[selected_class]
    player=pygame.Rect(460,490,34,42)
    player_max_hp=data["hp"]; player_hp=player_max_hp
    player_max_mp=data["mp"]; player_mp=player_max_mp
    player_level=1; player_exp=0; exp_needed=100; attack_power=data["atk"]; skill_points=0
    gold=35; potions={"health":2,"mana":2}; materials={"魔物核心":0,"魔力結晶":0}
    skill_levels={k:[0,0,0] for k in CLASSES}
    quest_state="intro"; game_over=False
    monster_alive=True; wave=1; wave_defeated=0
    monster_kind=0; monster_max_hp=monster_templates[0]["hp"]; monster_hp=monster_max_hp
    monster.x,monster.y=450,330
    boss_hp=boss_max_hp
    projectiles=[]; enemy_projectiles=[]
    dual_form=0; invincible_until=0; last_attack=0; last_skill=0; last_mp_regen=now()
    close_overlays()

def level_up():
    global player_level,player_exp,exp_needed,player_max_hp,player_max_mp,player_hp,player_mp,attack_power,skill_points
    while player_exp>=exp_needed:
        player_exp-=exp_needed; player_level+=1; exp_needed=int(exp_needed*1.28)
        player_max_hp+=18; player_max_mp+=12
        player_hp=min(player_max_hp,player_hp+35); player_mp=min(player_max_mp,player_mp+25)
        attack_power+=4; skill_points+=1
        set_message(f"升級！目前等級 LV {player_level}，獲得 1 點技能點。")
def gain_exp(n):
    global player_exp
    player_exp+=n; level_up()

def move_player(dx,dy):
    player.x+=dx
    for wall in obstacles:
        if player.colliderect(wall):
            if dx>0: player.right=wall.left
            elif dx<0: player.left=wall.right
    player.y+=dy
    for wall in obstacles:
        if player.colliderect(wall):
            if dy>0: player.bottom=wall.top
            elif dy<0: player.top=wall.bottom
    player.clamp_ip(pygame.Rect(18,85,WIDTH-36,HEIGHT-110))

def hurt_player(damage):
    global player_hp,invincible_until,game_over
    if now()<invincible_until or game_over: return
    player_hp=max(0,player_hp-damage); invincible_until=now()+850
    if player_hp<=0: game_over=True; set_message("你暫時失去了戰鬥能力，按 R 重新挑戰。")

def update_player(dt):
    global player_speed,player_mp,last_mp_regen
    if now()>=speed_boost_until: player_speed=230
    keys=pygame.key.get_pressed(); dx=dy=0
    if keys[pygame.K_LEFT] or keys[pygame.K_a]: dx-=1; set_facing("left")
    if keys[pygame.K_RIGHT] or keys[pygame.K_d]: dx+=1; set_facing("right")
    if keys[pygame.K_UP] or keys[pygame.K_w]: dy-=1; set_facing("up")
    if keys[pygame.K_DOWN] or keys[pygame.K_s]: dy+=1; set_facing("down")
    if dx and dy: dx*=0.707; dy*=0.707
    move_player(int(dx*player_speed*dt),int(dy*player_speed*dt))
    if now()-last_mp_regen>1000:
        player_mp=min(player_max_mp,player_mp+3); last_mp_regen=now()
    if scene=="game" and monster_alive and player.colliderect(monster): hurt_player(monster_templates[monster_kind]["atk"])
    if scene=="boss" and player.colliderect(boss): hurt_player(20)
def set_facing(direction):
    global player_facing
    player_facing=direction

def projectile(damage,color,speed=430):
    dx,dy={"up":(0,-1),"down":(0,1),"left":(-1,0),"right":(1,0)}[player_facing]
    projectiles.append({"rect":pygame.Rect(player.centerx-7,player.centery-7,14,14),
                        "dx":dx*speed,"dy":dy*speed,"damage":damage,"color":color})
def attack_area(distance):
    if player_facing=="up": return pygame.Rect(player.centerx-distance//2,player.top-distance,distance+34,distance)
    if player_facing=="down": return pygame.Rect(player.centerx-distance//2,player.bottom,distance+34,distance)
    if player_facing=="left": return pygame.Rect(player.left-distance,player.centery-distance//2,distance,distance+42)
    return pygame.Rect(player.right,player.centery-distance//2,distance,distance+42)
def melee(damage,distance=100):
    if scene=="boss":
        if attack_area(distance).colliderect(boss): damage_boss(damage)
    elif monster_alive and attack_area(distance).colliderect(monster):
        damage_monster(damage)
def basic_attack():
    global last_attack
    if now()-last_attack<420: return
    last_attack=now()
    if selected_class=="elementalist": projectile(attack_power,BLUE)
    elif selected_class=="magic_swordsman": melee(attack_power,105)
    elif dual_form==0: melee(attack_power,105)
    else: projectile(attack_power,GREEN)

def use_skill(key):
    global player_mp,last_skill,player_hp,player_speed,speed_boost_until
    if now()-last_skill<1000: set_message("技能冷卻中。"); return
    if selected_class=="elementalist":
        cost=22 if key==pygame.K_q else 30
        if player_mp<cost: set_message("魔力不足。"); return
        player_mp-=cost
        if key==pygame.K_q: projectile(attack_power*2,RED,520); set_message("烈焰術：火球飛出！")
        else:
            for _ in range(3):
                projectile(attack_power,BLUE,390)
            set_message("寒霜術：連續冰晶！")
    elif selected_class=="magic_swordsman":
        cost=22 if key==pygame.K_q else 25
        if player_mp<cost: set_message("魔力不足。"); return
        player_mp-=cost
        if key==pygame.K_q: melee(attack_power*2,145); set_message("弧月斬！")
        else: player_hp=min(player_max_hp,player_hp+30); set_message("守護姿態：恢復 30 HP！")
    else:
        cost=20 if key==pygame.K_q else 15
        if player_mp<cost: set_message("魔力不足。"); return
        player_mp-=cost
        if key==pygame.K_q: melee(attack_power,130); projectile(attack_power,GREEN); set_message("雙影連擊！")
        else: player_speed=360; speed_boost_until=now()+3000; set_message("迅捷步伐：速度提升 3 秒！")
    last_skill=now()

def damage_monster(damage):
    global monster_hp
    if not monster_alive: return
    monster_hp-=damage
    if monster_hp<=0: defeat_monster()
def damage_boss(damage):
    global boss_hp
    boss_hp=max(0,boss_hp-damage)
    if boss_hp==0: finish_boss()

def spawn_wave_monster():
    global monster_kind,monster_hp,monster_max_hp,monster_alive,monster
    monster_kind=min(wave_defeated//2,len(monster_templates)-1)
    data=monster_templates[monster_kind]
    monster_max_hp=data["hp"]+max(0,wave-3)*18
    monster_hp=monster_max_hp
    monster_alive=True
    monster.x=random.randint(260,660); monster.y=random.randint(260,420)

def defeat_monster():
    global monster_alive,wave_defeated,gold
    if not monster_alive: return
    monster_alive=False
    data=monster_templates[monster_kind]
    gold+=data["gold"]+random.randint(0,5)
    gain_exp(data["exp"])
    materials["魔物核心"]+=1
    wave_defeated+=1
    # 每兩隻魔物保證取得一枚魔力結晶，避免主線任務因隨機掉落而卡住
    if wave_defeated % 2 == 0 or random.random()<0.35: materials["魔力結晶"]+=1
    set_message(f"擊敗{data['name']}！獲得經驗、金幣與材料。")
    if wave_defeated<wave_total:
        # 下一隻在短暫提示後出現；每個任務階段固定三隻，不會無限生成
        pygame.time.set_timer(pygame.USEREVENT+1,1300,loops=1)
    else:
        set_message("本區域魔物已清除，回去向艾菈拉導師回報！",4000)
        check_quest_progress()
def update_monster(dt):
    if not monster_alive: return
    monster.x+=int(monster_direction*85*dt)
    if monster.x>690: monster_direction=-1
    if monster.x<245: monster_direction=1

def check_quest_progress():
    global quest_state
    if quest_state=="gather" and materials["魔物核心"]>=5 and materials["魔力結晶"]>=2:
        quest_state="ready"; set_message("材料已足夠！回去找艾菈拉導師。",4000)

def update_projectiles(dt):
    for p in projectiles[:]:
        p["rect"].x+=int(p["dx"]*dt); p["rect"].y+=int(p["dy"]*dt)
        if not screen.get_rect().colliderect(p["rect"]): projectiles.remove(p); continue
        target=boss if scene=="boss" else monster
        if p["rect"].colliderect(target):
            if scene=="boss": damage_boss(p["damage"])
            elif monster_alive: damage_monster(p["damage"])
            if p in projectiles: projectiles.remove(p)
    for p in enemy_projectiles[:]:
        p["rect"].x+=int(p["dx"]*dt); p["rect"].y+=int(p["dy"]*dt)
        if not screen.get_rect().colliderect(p["rect"]): enemy_projectiles.remove(p); continue
        if p["rect"].colliderect(player):
            hurt_player(p["damage"]); enemy_projectiles.remove(p)

def update_boss(dt):
    global boss_direction,boss_last_attack
    boss.x+=int(boss_direction*105*dt)
    if boss.right>850: boss_direction=-1
    if boss.left<110: boss_direction=1
    if now()-boss_last_attack>1450:
        boss_last_attack=now()
        dx=player.centerx-boss.centerx; dy=player.centery-boss.centery
        length=max(1,math.hypot(dx,dy))
        enemy_projectiles.append({"rect":pygame.Rect(boss.centerx-8,boss.centery-8,16,16),
            "dx":dx/length*260,"dy":dy/length*260,"damage":14})

def finish_boss():
    global scene,quest_state
    scene="victory"; quest_state="completed"; close_overlays()
    story_log.append("終章：守護者揭示了真相，古代魔法是維持學院結界的核心。")
    set_message("古代封印恢復，魔法學院得救了！",5000)

def use_potion(kind):
    global player_hp,player_mp
    if potions[kind]<=0: set_message("藥水數量不足。"); return
    if kind=="health":
        if player_hp>=player_max_hp: set_message("生命值已滿。"); return
        potions[kind]-=1; player_hp=min(player_max_hp,player_hp+45); set_message("使用生命藥水，恢復 45 HP。")
    else:
        if player_mp>=player_max_mp: set_message("魔力值已滿。"); return
        potions[kind]-=1; player_mp=min(player_max_mp,player_mp+45); set_message("使用魔力藥水，恢復 45 MP。")

def buy_item(kind):
    global gold
    if gold<25: set_message("金幣不足，無法購買。"); return
    gold-=25; potions[kind]+=1
    set_message("購買生命藥水成功！" if kind=="health" else "購買魔力藥水成功！")

def upgrade_skill(i):
    global skill_points,attack_power,player_max_hp,player_hp,player_max_mp,player_mp
    levels=skill_levels[selected_class]
    if skill_points<=0: set_message("技能點數不足。"); return
    if levels[i]>=5: set_message("技能已達最高等級。"); return
    levels[i]+=1; skill_points-=1
    if i==0: attack_power+=3
    elif i==1: player_max_hp+=12; player_hp+=12
    else: player_max_mp+=12; player_mp+=12
    set_message(f"{SKILLS[selected_class][i]}提升至 {levels[i]} 級。")

def interact_mentor():
    global quest_state,scene,wave,wave_defeated
    if quest_state=="intro":
        dialogue_open=True
        story_log.append("艾菈拉：請先清除學院外圍的魔物，收集至少 5 個魔物核心與 2 個魔力結晶。")
    elif quest_state=="gather":
        set_message(f"任務進度：魔物核心 {materials['魔物核心']}/5，魔力結晶 {materials['魔力結晶']}/2")
    elif quest_state=="ready":
        dialogue_open=True
    elif quest_state=="boss":
        set_message("遺跡深處的守護者仍在等待你的挑戰。")
    elif quest_state=="completed":
        set_message("艾菈拉：你是學院的英雄，感謝你守護了這裡。")
def advance_dialogue():
    global dialogue_open,quest_state,wave,wave_defeated,scene,boss_hp,boss_last_attack
    if quest_state=="intro":
        quest_state="gather"; wave=1; wave_defeated=0; spawn_wave_monster()
        set_message("新任務：收集 5 個魔物核心與 2 個魔力結晶。",4000)
    elif quest_state=="ready":
        materials["魔物核心"]-=5; materials["魔力結晶"]-=2
        quest_state="boss"; scene="boss"; boss_hp=boss_max_hp
        boss.x,boss.y=440,190; boss_last_attack=now()
        enemy_projectiles.clear(); projectiles.clear()
        set_message("遺跡大門開啟！古代魔法守護者現身！",4000)
    dialogue_open=False

def draw_background():
    screen.fill((30,28,58))
    for i in range(50):
        x=(i*173+37)%WIDTH; y=(i*97+23)%HEIGHT
        pygame.draw.circle(screen,(95,90,145),(x,y),1)
    pygame.draw.circle(screen,(235,220,170),(820,95),38)
    pygame.draw.rect(screen,(67,65,88),(0,100,WIDTH,HEIGHT-100))
    pygame.draw.rect(screen,(94,77,119),(0,100,WIDTH,8))
def draw_academy():
    draw_background()
    pygame.draw.rect(screen,(83,66,112),(330,105,300,145))
    pygame.draw.polygon(screen,(140,103,170),[(305,115),(480,35),(655,115)])
    for x in (370,455,540): pygame.draw.rect(screen,(220,195,135),(x,145,42,65))
    for w in obstacles:
        pygame.draw.rect(screen,(105,83,125),w); pygame.draw.rect(screen,(165,140,180),w,2)
    pygame.draw.rect(screen,(238,190,95),mentor); draw_text("艾菈拉導師",mentor.x-28,mentor.y-27,GOLD,FONT_S)
    pygame.draw.rect(screen,(90,175,135),merchant); draw_text("米洛商人",merchant.x-16,merchant.y-27,GREEN,FONT_S)
    if monster_alive:
        color=monster_templates[monster_kind]["color"]
        pygame.draw.ellipse(screen,color,monster)
        draw_text(monster_templates[monster_kind]["name"],monster.x-30,monster.y-25,WHITE,FONT_S)
        bar(monster.x-4,monster.y-10,50,6,monster_hp,monster_max_hp,RED)
def draw_ruins():
    screen.fill((28,25,43)); pygame.draw.rect(screen,(65,61,76),(0,100,WIDTH,540))
    for x in (120,270,680,830):
        pygame.draw.rect(screen,(105,99,116),(x,135,48,390))
        pygame.draw.rect(screen,(155,145,165),(x-8,128,64,18))
    pygame.draw.circle(screen,(110,80,180),(480,300),115,4)
    pygame.draw.circle(screen,(175,130,225),(480,300),75,3)
    center_text("古代遺跡：封印之間",105,GOLD,FONT_L)
def draw_player():
    color=WHITE if now()<invincible_until else (105,190,245)
    pygame.draw.rect(screen,color,player); pygame.draw.rect(screen,WHITE,player,2)
    # 面向標記
    offsets={"up":(17,4),"down":(17,37),"left":(4,20),"right":(29,20)}
    pygame.draw.circle(screen,(30,35,55),(player.x+offsets[player_facing][0],player.y+offsets[player_facing][1]),3)
def draw_hud():
    draw_text(f"LV {player_level}",18,14,GOLD,FONT)
    draw_text(f"HP {player_hp}/{player_max_hp}",110,13,RED,FONT_S); bar(110,38,145,11,player_hp,player_max_hp,RED)
    draw_text(f"MP {player_mp}/{player_max_mp}",285,13,BLUE,FONT_S); bar(285,38,145,11,player_mp,player_max_mp,BLUE)
    draw_text(f"EXP {player_exp}/{exp_needed}",460,13,GOLD,FONT_S); bar(460,38,145,11,player_exp,exp_needed,GOLD)
    draw_text(f"ATK {attack_power}",650,13,WHITE,FONT_S); draw_text(f"金幣 {gold}",790,13,GOLD,FONT_S)
    draw_text(f"核心 {materials['魔物核心']}　結晶 {materials['魔力結晶']}",650,43,WHITE,FONT_S)
def draw_controls():
    draw_text("移動：WASD／方向鍵　攻擊：SPACE　技能：Q／E",18,565,WHITE,FONT_S)
    draw_text("互動：F　背包：I　技能樹：K　藥水：H／M　形態切換：SHIFT",18,590,GOLD,FONT_S)
def draw_message():
    if now()<message_until:
        pygame.draw.rect(screen,(25,20,42),(145,510,670,38))
        pygame.draw.rect(screen,GOLD,(145,510,670,38),1)
        im=FONT_S.render(message,True,WHITE); screen.blit(im,(480-im.get_width()//2,520))
def draw_panel(title,lines):
    pygame.draw.rect(screen,(25,20,45),(145,125,670,370))
    pygame.draw.rect(screen,GOLD,(145,125,670,370),2)
    center_text(title,145,GOLD,FONT_L)
    for i,line in enumerate(lines): draw_text(line,195,220+i*48,WHITE,FONT_S)
    center_text("按 ESC 關閉",450,GRAY,FONT_S)
def draw_game():
    draw_academy()
    for p in projectiles: pygame.draw.circle(screen,p["color"],p["rect"].center,7)
    draw_player(); draw_hud(); draw_controls()
    if near(mentor): draw_text("F：與艾菈拉導師交談",75,465,GOLD,FONT_S)
    if near(merchant): draw_text("F：與米洛商人交易",735,465,GOLD,FONT_S)
    if quest_state=="gather": draw_text(f"任務：清除魔物並收集材料（{wave_defeated+1 if wave_defeated<wave_total else wave_total}/{wave_total}）",18,78,GOLD,FONT_S)
    elif quest_state=="ready": draw_text("任務完成：回去找艾菈拉導師",18,78,GOLD,FONT_S)
    elif quest_state=="intro": draw_text("主線：與艾菈拉導師交談",18,78,GOLD,FONT_S)
    draw_message()
def draw_boss():
    draw_ruins()
    pygame.draw.ellipse(screen,(150,85,185),boss); pygame.draw.ellipse(screen,(225,180,240),boss,4)
    center_text("古代魔法守護者",160,WHITE,FONT)
    bar(300,60,360,18,boss_hp,boss_max_hp,RED)
    for p in enemy_projectiles: pygame.draw.circle(screen,PURPLE,p["rect"].center,8)
    for p in projectiles: pygame.draw.circle(screen,p["color"],p["rect"].center,7)
    draw_player(); draw_hud(); draw_controls(); draw_message()
def draw_menu():
    draw_background(); center_text("MAGIC ACADEMY",170,GOLD,FONT_XL)
    center_text("魔法學院：失落的古代魔法",245,WHITE,FONT_L)
    center_text("一段關於封印、勇氣與古代真相的冒險",305,GRAY,FONT)
    center_text("ENTER：開始冒險",400,GOLD,FONT)
    center_text("操作：WASD 移動／SPACE 攻擊／F 互動",455,WHITE,FONT_S)
def draw_class_select():
    draw_background(); center_text("選擇你的職業",75,GOLD,FONT_XL)
    for i,(key,data) in enumerate(CLASSES.items()):
        y=175+i*125; pygame.draw.rect(screen,(48,38,78),(170,y,620,95)); pygame.draw.rect(screen,GOLD,(170,y,620,95),2)
        draw_text(f"{i+1}. {data['name']}",200,y+12,GOLD,FONT)
        draw_text(data["desc"],200,y+48,WHITE,FONT_S)
        draw_text(f"HP {data['hp']}　MP {data['mp']}　ATK {data['atk']}",590,y+30,WHITE,FONT_S)
    center_text("按 1／2／3 選擇職業",565,WHITE,FONT_S)
def draw_victory():
    draw_background(); center_text("古代魔法再次甦醒",125,GOLD,FONT_XL)
    center_text("守護者揭示真相：封印並非牢籠，而是保護學院的結界。",245,WHITE,FONT)
    center_text("你修復了古代封印，星霜魔法學院恢復和平。",310,WHITE,FONT)
    center_text("艾菈拉：真正的魔法，是理解力量並承擔責任。",375,GOLD,FONT)
    center_text("R：返回學院　ESC：主選單",480,WHITE,FONT)
def draw_overlay():
    if inventory_open:
        draw_panel("冒險者背包",[
            f"金幣：{gold}",
            f"生命藥水：{potions['health']}（H 使用）",
            f"魔力藥水：{potions['mana']}（M 使用）",
            f"魔物核心：{materials['魔物核心']}　魔力結晶：{materials['魔力結晶']}"
        ])
    elif shop_open:
        draw_panel("米洛的補給商店",[
            f"目前金幣：{gold}",
            "按 1 購買生命藥水（25 金幣）",
            "按 2 購買魔力藥水（25 金幣）",
            "商人米洛：旅途漫長，記得補充補給。"
        ])
    elif skill_tree_open:
        draw_panel("職業技能樹",[
            f"可用技能點：{skill_points}",
            f"1. {SKILLS[selected_class][0]}　Lv.{skill_levels[selected_class][0]}/5　{SKILL_DESC[0]}",
            f"2. {SKILLS[selected_class][1]}　Lv.{skill_levels[selected_class][1]}/5　{SKILL_DESC[1]}",
            f"3. {SKILLS[selected_class][2]}　Lv.{skill_levels[selected_class][2]}/5　{SKILL_DESC[2]}",
            "按 1／2／3 升級技能"
        ])
    elif dialogue_open:
        if quest_state=="intro":
            lines=["艾菈拉：冒險者，學院地下的封印正在減弱。",
                   "請清除外圍魔物，收集 5 個魔物核心與 2 個魔力結晶。",
                   "完成後回來找我，我會開啟古代遺跡。","按 ENTER 接受任務"]
        else:
            lines=["艾菈拉：材料已經收集完成。","遺跡中的守護者可能知道封印失衡的原因。",
                   "準備好後，我會送你前往封印之間。","按 ENTER 前往古代遺跡"]
        draw_panel("艾菈拉導師",lines)
def draw_game_over():
    pygame.draw.rect(screen,(20,15,30),(0,0,WIDTH,HEIGHT))
    center_text("冒險暫時中止",220,RED,FONT_XL)
    center_text("按 R 重新挑戰目前區域",315,WHITE,FONT)

def handle_event(e):
    global running,scene,selected_class,inventory_open,shop_open,skill_tree_open,dialogue_open
    global quest_state,monster_alive,wave_defeated,monster_kind,monster_hp,monster_max_hp
    global boss_hp,game_over
    if e.type==pygame.QUIT: running=False; return
    if e.type==pygame.USEREVENT+1 and scene=="game" and quest_state=="gather" and wave_defeated<wave_total:
        spawn_wave_monster(); return
    if e.type!=pygame.KEYDOWN: return
    if scene=="menu":
        if e.key==pygame.K_RETURN: scene="class_select"
        elif e.key==pygame.K_ESCAPE: running=False
        return
    if scene=="class_select":
        choices={pygame.K_1:"elementalist",pygame.K_2:"magic_swordsman",pygame.K_3:"dual_walker"}
        if e.key in choices:
            selected_class=choices[e.key]; reset_game(); scene="game"
            set_message(f"你選擇了{CLASSES[selected_class]['name']}。先去找艾菈拉導師！",4000)
        return
    if scene=="victory":
        if e.key==pygame.K_r: reset_game(); scene="game"
        elif e.key==pygame.K_ESCAPE: scene="menu"
        return
    if e.key==pygame.K_ESCAPE:
        if overlays(): close_overlays()
        else: scene="menu"
        return
    if game_over:
        if e.key==pygame.K_r:
            if scene=="boss": boss_hp=boss_max_hp; player_hp=player_max_hp; player_mp=player_max_mp; player.x,player.y=460,500; enemy_projectiles.clear(); game_over=False
            else: reset_game(); scene="game"
        return
    if dialogue_open:
        if e.key==pygame.K_RETURN: advance_dialogue()
        elif e.key==pygame.K_ESCAPE: dialogue_open=False
        return
    if shop_open:
        if e.key==pygame.K_1: buy_item("health")
        elif e.key==pygame.K_2: buy_item("mana")
        return
    if inventory_open:
        if e.key==pygame.K_i: inventory_open=False
        elif e.key==pygame.K_h: use_potion("health")
        elif e.key==pygame.K_m: use_potion("mana")
        return
    if skill_tree_open:
        if e.key==pygame.K_k: skill_tree_open=False
        elif e.key in (pygame.K_1,pygame.K_2,pygame.K_3): upgrade_skill(e.key-pygame.K_1)
        return
    if e.key==pygame.K_i: inventory_open=True
    elif e.key==pygame.K_k: skill_tree_open=True
    elif e.key==pygame.K_h: use_potion("health")
    elif e.key==pygame.K_m: use_potion("mana")
    elif e.key==pygame.K_SPACE: basic_attack()
    elif e.key in (pygame.K_q,pygame.K_e): use_skill(e.key)
    elif e.key in (pygame.K_LSHIFT,pygame.K_RSHIFT) and selected_class=="dual_walker":
        global dual_form
        dual_form=1-dual_form; set_message("切換形態成功。")
    elif e.key==pygame.K_f and scene=="game":
        if near(mentor):
            if quest_state in ("intro","ready"): interact_mentor(); dialogue_open=True
            elif quest_state=="gather": set_message(f"材料進度：核心 {materials['魔物核心']}/5、結晶 {materials['魔力結晶']}/2")
            else: interact_mentor()
        elif near(merchant): shop_open=True

async def main():
    global running
    while running:
        dt=min(clock.tick(FPS)/1000,0.04)
        for event in pygame.event.get(): handle_event(event)
        if scene in ("game","boss") and not game_over and not overlays():
            update_player(dt); update_projectiles(dt)
            if scene=="game" and quest_state=="gather":
                update_monster(dt); check_quest_progress()
            elif scene=="boss": update_boss(dt)
        if scene=="menu": draw_menu()
        elif scene=="class_select": draw_class_select()
        elif scene=="game": draw_game(); draw_overlay()
        elif scene=="boss": draw_boss(); draw_overlay()
        elif scene=="victory": draw_victory()
        if game_over: draw_game_over()
        pygame.display.flip()
        await asyncio.sleep(0)
    pygame.quit()

asyncio.run(main())
