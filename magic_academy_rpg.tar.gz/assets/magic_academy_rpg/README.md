# 魔法學院：失落的古代魔法

一款使用 Python、Pygame 與 Pygbag 製作的 2D 魔法冒險遊戲。

## 遊戲特色
- 三種職業：元素法師、魔法劍士、雙形態使者
- 主線任務：與艾菈拉導師交談、清除魔物、收集材料、挑戰古代魔法守護者
- 三種具名魔物：迷霧史萊姆、餘燼狼、符文守衛
- 升級、技能樹、背包、藥水與商店
- 使用繪圖圖形建立角色、地圖與怪物，不依賴外部圖片素材

## 操作方式
| 按鍵 | 功能 |
|---|---|
| WASD / 方向鍵 | 移動 |
| SPACE | 普通攻擊 |
| Q / E | 職業技能 |
| F | 與 NPC 互動 |
| I | 背包 |
| K | 技能樹 |
| H / M | 使用生命／魔力藥水 |
| SHIFT | 雙形態使者切換形態 |
| ENTER | 確認對話／選擇 |
| ESC | 關閉介面或返回主選單 |
| R | 失敗後重試／結局返回學院 |

## 中文字型
為確保瀏覽器能顯示繁體中文，請取得合法可再散布的 Noto Sans TC 字型檔，命名為：

`assets/fonts/NotoSansTC-Regular.ttf`

放入上述路徑。若沒有字型檔，程式會嘗試使用系統字型，但不同瀏覽器環境不保證中文顯示正常。

## 在 Google Colab 建置網頁版
在 Colab 上傳或建立此專案後，執行：

```bash
pip install pygame-ce pygbag
python -m pygbag --build .
```

Pygbag 產生的網頁檔案通常位於 `build/web/`。

## GitHub Pages
1. 將 `build/web/` **裡面的所有內容**上傳到 GitHub Repository 的 `main` 分支根目錄。
2. 確認 `index.html` 位於 Repository 根目錄，不要只上傳 `main.py`，也不要把整個 `web` 資料夾再包一層。
3. Repository 設為 Public。
4. Settings → Pages → Source 選 `Deploy from a branch`。
5. Branch 選 `main`，Folder 選 `/(root)`，儲存設定。
6. 等待 GitHub Pages 部署完成後，網址格式為：
   `https://你的GitHub帳號.github.io/Repository名稱/`

## 專案檔案說明
- `main.py`：遊戲主程式
- `assets/fonts/`：繁體中文字型
- `assets/images/`：預留圖片資源資料夾
- `assets/sounds/`：預留音效資源資料夾
- `requirements.txt`：Python 套件需求
