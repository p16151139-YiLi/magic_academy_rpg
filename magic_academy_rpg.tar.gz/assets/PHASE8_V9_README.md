# Magic Academy — 第八階段 V9：NPC 行為與對話同步版

以 V8 完整專案為基礎，不刪除兩張商店地圖、五種裝備、道具使用與六格快捷欄功能。

## 本輪新增

- `data/npcs/dialogue_profiles.json`：16 位 NPC 各自擁有專屬開場白、實際工作／生活狀態台詞與三個對話選項。
- `systems/npc_shop_system.py`：依 NPC 即時行動狀態組合對話，在對話期間暫停移動並面向玩家；選項與回應依身分及狀態變更。
- `systems/npc_ai/ai_controller.py`：新增自主學生「默想複習」行為，巡邏停止與休息正確回報，避免台詞說正在巡邏但角色已停下。
- 16 位 NPC 的地圖預設 `dialogue` 文本已同步更新，移除站姿卻自稱正在坐著、書寫等矛盾描述。
- `tests/test_v9_npc_dialogues.py`：針對 16 位 NPC、每種 AI 狀態、選項、商店、任務解鎖、休息巡邏回應做檢查。
- `docs/npc_behavior_dialogue_audit_v9.md`：角色與對話狀態逐一核對清單。

## 遊戲互動

接近 NPC 按 E → 讀取 NPC 當前動作 → 顯示個人化開場白與當前行動描述 → 選擇三個選項（上下鍵／滑鼠／1~3，Enter／E 確認），Esc 離開。

## 檢查與限制

在本地執行：

```bash
python tests/test_v8.py
python tests/test_shop_logic.py
python tests/test_guard_ai_v7.py
python tests/test_v9_npc_dialogues.py
```

目前環境無 Pygame 圖形套件，無法執行真正的畫面與 GitHub Pages 實際測試；新版 Colab 可執行 Pygame dummy-display 測試，再進行網頁建置。

重要：部分站立學生是「回想課業」，不是實際閱讀／抄寫精靈。要增加翻書、書寫手部動畫，需要另外生成對應角色的專用圖集。
