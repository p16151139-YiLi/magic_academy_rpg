
import pygame
from pathlib import Path
from systems.inventory_manager import InventoryManager

ROOT = Path(__file__).resolve().parents[1]

class InventoryPanel:
    # 模板原始設計座標：1536 × 1024
    BASE_W, BASE_H = 1536, 1024

    CATEGORIES = [
        ("全部", "all", (76, 183, 142, 93)),
        ("消耗品", "consumable", (230, 183, 133, 93)),
        ("武器", "weapon", (378, 183, 137, 93)),
        ("防具", "armor", (525, 183, 137, 93)),
        ("材料", "material", (672, 183, 137, 93)),
    ]

    def __init__(self):
        self.manager = InventoryManager()
        self.category = "all"
        self.selected = None
        self.hover = None
        self.closed = False
        self.message = ""

        self.fonts = {}
        self.icons = {}

        path = ROOT / "assets/ui/inventory/inventory_template.png"
        self.template = pygame.image.load(str(path)).convert_alpha()

        self.rect = pygame.Rect(140, 27, 1000, 666)

    def font(self, size):
        if size not in self.fonts:
            path = ROOT / "assets/fonts/NotoSansTC-Regular.ttf"
            self.fonts[size] = pygame.font.Font(
                str(path) if path.exists() else None,
                size
            )
        return self.fonts[size]

    def text(self, surface, value, x, y, size=24,
             color=(240, 232, 210), max_width=None):
        font = self.font(size)
        value = str(value)

        if max_width is not None:
            while value and font.size(value)[0] > max_width:
                value = value[:-1]

        if value:
            surface.blit(
                font.render(value, True, color),
                (x, y)
            )

    def icon(self, item_id, size):
        key = (item_id, size)

        if key in self.icons:
            return self.icons[key]

        info = self.manager.database.get(item_id, {})
        relative = info.get("icon", "")
        path = ROOT / relative

        if not relative or not path.exists():
            return None

        image = pygame.image.load(str(path)).convert_alpha()
        image = pygame.transform.scale(image, (size, size))
        self.icons[key] = image
        return image

    def items(self):
        result = []

        for entry in self.manager.data.get("items", []):
            info = self.manager.database.get(
                entry["item_id"], {}
            )

            if (
                self.category == "all"
                or info.get("type") == self.category
            ):
                result.append(entry)

        return result

    def slot_rect(self, index):
        col = index % 5
        row = index // 5

        return pygame.Rect(
            96 + col * 145,
            324 + row * 145,
            116,
            112
        )

    def buttons(self):
        return [
            ("使用", pygame.Rect(877, 797, 180, 82)),
            ("裝備", pygame.Rect(1083, 797, 180, 82)),
            ("卸下", pygame.Rect(1291, 797, 180, 82)),
        ]

    def hitboxes(self):
        boxes = []

        for label, category, rect in self.CATEGORIES:
            boxes.append((
                ("category", category),
                pygame.Rect(rect)
            ))

        for i in range(20):
            boxes.append((
                ("slot", i),
                self.slot_rect(i)
            ))

        for label, rect in self.buttons():
            boxes.append((
                ("button", label),
                rect
            ))

        boxes.append((
            ("close", None),
            pygame.Rect(1378, 135, 86, 83)
        ))

        return boxes

    def local_pos(self, screen_pos):
        x = (
            (screen_pos[0] - self.rect.x)
            * self.BASE_W / self.rect.width
        )
        y = (
            (screen_pos[1] - self.rect.y)
            * self.BASE_H / self.rect.height
        )
        return x, y

    def get_hit(self, screen_pos):
        if not self.rect.collidepoint(screen_pos):
            return None

        point = self.local_pos(screen_pos)

        for key, rect in self.hitboxes():
            if rect.collidepoint(point):
                return key

        return None

    def draw_highlight(self, surface, rect, selected=False):
        overlay = pygame.Surface(
            (rect.width, rect.height),
            pygame.SRCALPHA
        )

        overlay.fill(
            (255, 213, 80, 65)
            if not selected else (255, 210, 65, 90)
        )

        surface.blit(overlay, rect.topleft)

        pygame.draw.rect(
            surface,
            (255, 225, 112),
            rect,
            4
        )

    def draw(self, surface, rect=None):
        if self.closed:
            return

        if rect is not None:
            self.rect = pygame.Rect(rect)

        canvas = pygame.transform.scale(
            self.template,
            (self.BASE_W, self.BASE_H)
        ).copy()

        entries = self.items()

        # 分類選取和滑鼠懸停反黃
        for label, category, area in self.CATEGORIES:
            box = pygame.Rect(area)

            if self.category == category:
                self.draw_highlight(canvas, box, True)
            elif self.hover == ("category", category):
                self.draw_highlight(canvas, box)

        # 物品格
        for i in range(20):
            box = self.slot_rect(i)

            if self.selected == i:
                self.draw_highlight(canvas, box, True)
            elif self.hover == ("slot", i):
                self.draw_highlight(canvas, box)

            if i >= len(entries):
                continue

            entry = entries[i]
            item_id = entry["item_id"]
            image = self.icon(item_id, 78)

            if image is not None:
                canvas.blit(
                    image,
                    image.get_rect(center=box.center)
                )

            quantity = entry.get("amount", entry.get("quantity", 1))

            if quantity > 1:
                self.text(
                    canvas,
                    str(quantity),
                    box.right - 33,
                    box.bottom - 33,
                    23
                )

        # 物品詳細資訊
        if self.selected is not None and self.selected < len(entries):
            entry = entries[self.selected]
            item_id = entry["item_id"]
            info = self.manager.database.get(item_id, {})

            image = self.icon(item_id, 130)

            if image is not None:
                canvas.blit(image, (950, 265))

            self.text(
                canvas,
                info.get("name", "未知物品"),
                1105, 288, 31,
                max_width=350
            )

            self.text(
                canvas,
                "持有數量：" + str(entry.get("amount", entry.get("quantity", 1))),
                1105, 345, 24
            )

            self.text(
                canvas,
                info.get("description", ""),
                904, 515, 26,
                max_width=520
            )

            bonuses = info.get("bonuses", {})
            bonus_y = 572

            for stat, value in bonuses.items():
                self.text(
                    canvas,
                    f"{stat.upper()} +{value}",
                    904, bonus_y, 24,
                    (255, 218, 120)
                )
                bonus_y += 34

        else:
            self.text(
                canvas,
                "請選擇物品",
                930, 520, 29
            )

        # 操作按鈕：文字與功能完全由程式控制
        for label, box in self.buttons():
            if self.hover == ("button", label):
                self.draw_highlight(canvas, box)

            font = self.font(31)
            img = font.render(
                label, True, (255, 239, 199)
            )
            canvas.blit(
                img,
                img.get_rect(center=box.center)
            )

        if self.hover == ("close", None):
            self.draw_highlight(
                canvas,
                pygame.Rect(1378, 135, 86, 83)
            )

        if self.message:
            self.text(
                canvas,
                self.message,
                920, 740, 24,
                (255, 218, 120)
            )

        result = pygame.transform.scale(
            canvas, self.rect.size
        )

        surface.blit(result, self.rect.topleft)

    def _handle_event_local(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hover = self.get_hit(event.pos)
            return self.hover is not None

        if event.type != pygame.MOUSEBUTTONDOWN:
            return False

        if event.button != 1:
            return False

        hit = self.get_hit(event.pos)
        if hit is None:
            return False

        kind, value = hit

        if kind == "close":
            self.closed = True
            return True

        if kind == "category":
            self.category = value
            self.selected = None
            self.message = ""
            return True

        if kind == "slot":
            entries = self.items()
            self.selected = (
                value if 0 <= value < len(entries) else None
            )
            self.message = ""
            return True

        if kind != "button":
            return False

        if value == "卸下":
            equipment = self.manager.data.get(
                "equipment", {}
            )

            if self.category == "weapon":
                slots = ["weapon"]
            elif self.category == "armor":
                slots = ["armor"]
            else:
                slots = ["weapon", "armor"]

            equipped = [
                slot for slot in slots
                if equipment.get(slot)
            ]

            if not equipped:
                self.message = "目前沒有可卸下的裝備"
                return True

            if len(equipped) > 1:
                self.message = "請先選擇武器或防具分類"
                return True

            self.manager.unequip_item(equipped[0])
            self.message = self.manager.last_message
            self.selected = None
            return True

        entries = self.items()

        if (
            self.selected is None
            or self.selected >= len(entries)
        ):
            self.message = "請先選擇物品"
            return True

        item_id = entries[self.selected]["item_id"]
        info = self.manager.get_item_info(item_id)

        if value == "使用":
            if info.get("type") not in (
                "consumable", "potion"
            ):
                self.message = "這個物品無法使用"
                return True

            success = self.manager.use_item(item_id)

        elif value == "裝備":
            if info.get("slot") not in (
                "weapon", "armor"
            ):
                self.message = "這個物品無法裝備"
                return True

            success = self.manager.equip_item(item_id)

        else:
            return False

        self.message = self.manager.last_message

        if success:
            self.selected = None

        return True


    def handle_event(self, event, rect=None):
        if rect is not None:
            self.rect = pygame.Rect(rect)

        if self.closed:
            return False

        return self._handle_event_local(event)

