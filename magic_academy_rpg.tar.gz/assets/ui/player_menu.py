
import pygame
import json
from pathlib import Path

from ui.character_info_panel import CharacterInfoPanel
from ui.character_panel import CharacterPanel
from ui.inventory_panel import InventoryPanel
from ui.stat_allocation_panel import StatAllocationPanel

ROOT = Path(__file__).resolve().parents[1]


class PlayerMenu:

    TABS = [
        "角色資訊",
        "背包",
        "技能樹",
        "任務日誌",
        "世界地圖",
        "操作說明"
    ]

    def __init__(self, screen, draw_text=None):

        self.screen = screen
        self.draw_text = draw_text

        self.opened = False
        self.tab = 5
        self.hover = -1

        self.template = pygame.image.load(
            str(
                ROOT /
                "assets/ui/player_menu/player_menu_template.png"
            )
        ).convert_alpha()

        with open(
            ROOT / "data/ui/controls.json",
            encoding="utf-8"
        ) as f:
            self.controls = json.load(f)

        self.character_info_panel = CharacterInfoPanel()
        self.character_panel = CharacterPanel()

        self.inventory_panel = InventoryPanel()
        self.stat_allocation_panel = StatAllocationPanel()

        self.font_path = str(
            ROOT / "assets/fonts/NotoSansTC-Regular.ttf"
        )

        self.fonts = {}

        self.origin = (0, 0)
        self.scale = 1.0

    def font(self, size):

        size = max(10, int(size))

        if size not in self.fonts:
            font_path = self.font_path if Path(self.font_path).is_file() else None
            self.fonts[size] = pygame.font.Font(font_path, size)

        return self.fonts[size]

    def text(
        self,
        value,
        x,
        y,
        size=22,
        color=(240, 230, 205)
    ):

        surf = self.font(size).render(
            str(value),
            True,
            color
        )

        self.screen.blit(
            surf,
            (int(x), int(y))
        )

    def rect(self, x, y, w, h):

        ox, oy = self.origin
        s = self.scale

        return pygame.Rect(
            round(ox + x * s),
            round(oy + y * s),
            round(w * s),
            round(h * s)
        )

    def set_layout(self):

        sw, sh = self.screen.get_size()

        self.scale = min(
            sw / 1040,
            sh / 620,
            1.0
        )

        self.origin = (
            (sw - 1000 * self.scale) / 2,
            (sh - 580 * self.scale) / 2
        )

    def inventory_rect(self):

        sw, sh = self.screen.get_size()

        # 保持原始模板 3:2 比例
        scale = min(
            (sw - 40) / 1536,
            (sh - 30) / 1024
        )

        w = round(1536 * scale)
        h = round(1024 * scale)

        return pygame.Rect(
            (sw - w) // 2,
            (sh - h) // 2,
            w,
            h
        )

    def open(self, tab=None):
        if tab is not None:
            self.tab = tab
        self.opened = True
        if self.tab == 1:
            self.inventory_panel.closed = False
            self.inventory_panel.manager.reload()

    def close(self):
        self.opened = False
        self.inventory_panel.closed = False

    def handle_key(self, key):
        """由 GameScene 統一輪詢鍵盤，避免瀏覽器 KEYDOWN 漏接。"""
        if not self.opened:
            return False

        if key in (pygame.K_ESCAPE, pygame.K_TAB):
            self.close()
            return True

        shortcuts = {
            pygame.K_c: 0,
            pygame.K_i: 1,
            pygame.K_k: 2,
            pygame.K_m: 4,
            pygame.K_h: 5,
        }

        if key in shortcuts:
            self.tab = shortcuts[key]
            if self.tab == 1:
                self.inventory_panel.closed = False
                self.inventory_panel.manager.reload()
            return True

        return False

    def handle_event(self, event):
        """處理滑鼠操作；鍵盤快捷鍵由 GameScene 輪詢。"""
        if not self.opened:
            return False

        self.set_layout()

        if self.tab == 0 and self.stat_allocation_panel.handle_event(event):
            return True

        if self.tab == 1:
            self.inventory_panel.handle_event(
                event, self.inventory_rect()
            )
            if self.inventory_panel.closed:
                self.close()
            return True

        if event.type == pygame.MOUSEMOTION:
            self.hover = -1
            for i in range(len(self.TABS)):
                rect = self.rect(35 + i * 155, 102, 145, 62)
                if rect.collidepoint(event.pos):
                    self.hover = i
                    break
            return True

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i in range(len(self.TABS)):
                rect = self.rect(35 + i * 155, 102, 145, 62)
                if rect.collidepoint(event.pos):
                    self.tab = i
                    if i == 1:
                        self.inventory_panel.closed = False
                        self.inventory_panel.manager.reload()
                    return True
            return True

        return True

    def draw(self):

        if not self.opened:
            return

        self.set_layout()

        sw, sh = self.screen.get_size()

        s = self.scale
        ox, oy = self.origin

        # 背景遮罩
        shade = pygame.Surface(
            (sw, sh),
            pygame.SRCALPHA
        )

        shade.fill((0, 0, 0, 155))
        self.screen.blit(shade, (0, 0))

        # 背包使用獨立完整模板
        if self.tab == 1:

            self.inventory_panel.draw(
                self.screen,
                self.inventory_rect()
            )

            return

        # 一般玩家選單
        template = pygame.transform.scale(
            self.template,
            (
                round(1000 * s),
                round(580 * s)
            )
        )

        self.screen.blit(
            template,
            (
                round(ox),
                round(oy)
            )
        )

        def txt(
            value,
            x,
            y,
            size=22,
            color=(240, 230, 205)
        ):

            self.text(
                value,
                ox + x * s,
                oy + y * s,
                size * s,
                color
            )

        txt(
            "冒 險 者 手 冊",
            390,
            43,
            28,
            (242, 212, 151)
        )

        # 分頁按鈕
        for i, name in enumerate(self.TABS):

            r = self.rect(
                35 + i * 155,
                102,
                145,
                62
            )

            if i == self.tab:
                color = (215, 165, 75, 110)

            elif i == self.hover:
                color = (255, 220, 120, 95)

            else:
                color = None

            if color:

                overlay = pygame.Surface(
                    r.size,
                    pygame.SRCALPHA
                )

                overlay.fill(color)

                self.screen.blit(
                    overlay,
                    r.topleft
                )

            if i == self.tab or i == self.hover:

                pygame.draw.rect(
                    self.screen,
                    (248, 215, 128),
                    r,
                    max(1, round(2 * s))
                )

            label = self.font(19 * s).render(
                name,
                True,
                (255, 235, 185)
            )

            self.screen.blit(
                label,
                label.get_rect(center=r.center)
            )

        # 內容標題
        txt(
            self.TABS[self.tab],
            75,
            208,
            27,
            (242, 212, 151)
        )

        pygame.draw.line(
            self.screen,
            (145, 118, 93),
            (
                round(ox + 70 * s),
                round(oy + 252 * s)
            ),
            (
                round(ox + 930 * s),
                round(oy + 252 * s)
            ),
            max(1, round(2 * s))
        )

        # 操作說明
        if self.tab == 5:

            for i, (key, description) in enumerate(
                self.controls
            ):

                y = 273 + i * 27

                txt(
                    key,
                    85,
                    y,
                    17,
                    (245, 205, 135)
                )

                txt(
                    description,
                    370,
                    y,
                    17
                )

        # 角色資訊
        elif self.tab == 0:

            self.character_info_panel.draw(
                self.screen,
                self.rect(
                    50,
                    205,
                    900,
                    470
                )
            )

            self.stat_allocation_panel.draw(
                self.screen,
                self.rect(50, 205, 900, 390)
            )

        # 技能樹
        elif self.tab == 2:

            txt("技能樹", 85, 280, 22)

            txt(
                "職業技能與技能點數將顯示在此。",
                85,
                335,
                19
            )

        # 任務日誌
        elif self.tab == 3:

            txt("任務日誌", 85, 280, 22)

            txt(
                "主線、支線及已完成任務將顯示在此。",
                85,
                335,
                19
            )

        # 世界地圖
        elif self.tab == 4:

            txt("世界地圖", 85, 280, 22)

            txt(
                "已探索地區與傳送點將顯示在此。",
                85,
                335,
                19
            )

        txt(
            "Tab / Esc 關閉",
            765,
            507,
            15,
            (188, 176, 159)
        )
