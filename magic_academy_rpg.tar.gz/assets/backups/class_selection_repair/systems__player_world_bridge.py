
import json
from pathlib import Path
import pygame

from systems.player_entity import PlayerEntity


class PlayerWorldBridge:

    def __init__(self, scene):
        self.scene = scene

        root = Path(__file__).resolve().parents[1]
        player_file = root / "data/player/player_data.json"

        class_id = "balanced_mage"

        if player_file.exists():
            try:
                data = json.loads(
                    player_file.read_text(encoding="utf-8")
                )
                class_id = data.get("class_id", class_id)
            except (OSError, ValueError):
                pass

        x, y = scene.map_manager.get_spawn()

        self.player = PlayerEntity(
            x=x,
            y=y,
            class_id=class_id
        )

        self.transition_cooldown = 0.0
        self.fade_alpha = 0
        self.message = ""
        self.message_timer = 0.0

        self.nearby_exit = None

        self.update_camera()

    # --------------------------------------
    # 碰撞
    # --------------------------------------

    def get_obstacles(self):
        raw = self.scene.map_manager.get_collisions()
        obstacles = []

        for item in raw:

            if isinstance(item, pygame.Rect):
                obstacles.append(item.copy())

            elif isinstance(item, (list, tuple)):
                if len(item) == 4:
                    obstacles.append(pygame.Rect(*item))

            elif isinstance(item, dict):

                if "rect" in item:
                    obstacles.append(
                        pygame.Rect(*item["rect"])
                    )

                elif all(
                    key in item
                    for key in ("x", "y", "width", "height")
                ):
                    obstacles.append(
                        pygame.Rect(
                            item["x"],
                            item["y"],
                            item["width"],
                            item["height"]
                        )
                    )

        return obstacles

    # --------------------------------------
    # 攝影機
    # --------------------------------------

    def update_camera(self):
        scene = self.scene

        self.scene.camera.follow(
            self.player.rect.centerx,
            self.player.rect.centery,
            scene.map_data["width"],
            scene.map_data["height"]
        )

    # --------------------------------------
    # 出口資料
    # --------------------------------------

    def get_exit_rect(self, exit_data):

        raw = exit_data.get("rect")

        if not isinstance(raw, (list, tuple)):
            return None

        if len(raw) != 4:
            return None

        return pygame.Rect(*raw)

    def find_nearby_exit(self):

        player_rect = self.player.rect

        # 擴大偵測範圍，方便玩家接近出口
        detection = player_rect.inflate(70, 70)

        for exit_data in self.scene.map_manager.get_exits():

            exit_rect = self.get_exit_rect(exit_data)

            if exit_rect is None:
                continue

            if detection.colliderect(exit_rect):
                return exit_data

        return None

    def is_exit_unlocked(self, exit_data):

        condition = exit_data.get("unlock_condition")

        if not condition:
            return True

        # 預留任務系統接口
        quest_system = getattr(
            self.scene, "quest_system", None
        )

        if quest_system is None:
            return False

        if hasattr(quest_system, "is_completed"):
            return bool(
                quest_system.is_completed(condition)
            )

        return False

    # --------------------------------------
    # 訊息
    # --------------------------------------

    def show_message(self, message, duration=2.0):
        self.message = str(message)
        self.message_timer = duration

    # --------------------------------------
    # 地圖切換
    # --------------------------------------

    def transition(self, exit_id):

        scene = self.scene

        result = scene.map_manager.transition(exit_id)

        scene.map_id = result["map_id"]
        scene.map_data = scene.map_manager.current_map
        scene.spawn = result["spawn"]

        scene.map_loaded = False

        self.player.controller.teleport(
            *scene.spawn
        )

        self.player.controller.direction = "down"

        self.player.animator.set_animation(
            "idle", "down"
        )

        self.transition_cooldown = 1.0

        self.fade_alpha = 210

        self.nearby_exit = None

        self.update_camera()

        self.show_message(
            f"已進入：{scene.map_data['name']}",
            2.5
        )

        print(
            "地圖切換成功：",
            scene.map_id,
            "出生點：",
            scene.spawn
        )

        return result

    # --------------------------------------
    # E 鍵互動
    # --------------------------------------

    def handle_event(self, event):

        if event.type != pygame.KEYDOWN:
            return False

        if event.key != pygame.K_e:
            return False

        if self.transition_cooldown > 0:
            return True

        exit_data = self.find_nearby_exit()

        if exit_data is None:
            return False

        if not self.is_exit_unlocked(exit_data):

            condition = exit_data.get(
                "unlock_condition", "未知條件"
            )

            self.show_message(
                f"此傳送門尚未解鎖：{condition}"
            )

            return True

        target = exit_data.get("target")

        target_file = (
            self.scene.root
            / "data/maps"
            / f"{target}.json"
        )

        if not target_file.is_file():

            self.show_message(
                f"目的地尚未開放：{target}"
            )

            return True

        try:
            self.transition(exit_data["id"])

        except Exception as error:

            self.show_message(
                f"傳送失敗：{error}"
            )

            print("地圖切換錯誤：", error)

        return True

    # --------------------------------------
    # 更新
    # --------------------------------------

    def update(self, dt):

        scene = self.scene

        dt = max(0.0, min(dt, 0.1))

        self.transition_cooldown = max(
            0.0,
            self.transition_cooldown - dt
        )

        self.fade_alpha = max(
            0,
            self.fade_alpha - 400 * dt
        )

        self.message_timer = max(
            0.0,
            self.message_timer - dt
        )

        if scene.player_menu.opened:

            self.player.controller.state = "idle"

            self.player.animator.set_animation(
                "idle",
                self.player.controller.direction
            )

            self.player.animator.update(dt)
            self.nearby_exit = None
            return

        self.player.update(
            dt,
            obstacles=self.get_obstacles()
        )

        # 地圖邊界
        rect = self.player.rect

        bounds = pygame.Rect(
            0, 0,
            scene.map_data["width"],
            scene.map_data["height"]
        )

        rect.clamp_ip(bounds)

        self.player.controller.position.update(
            rect.centerx,
            rect.centery
        )

        self.update_camera()

        # 更新附近出口
        self.nearby_exit = self.find_nearby_exit()

    # --------------------------------------
    # 繪製
    # --------------------------------------

    def draw(self, screen):

        scene = self.scene

        self.player.draw(
            screen,
            camera_offset=(
                scene.camera.x,
                scene.camera.y
            )
        )

        # 出口互動提示
        if self.nearby_exit is not None:

            unlocked = self.is_exit_unlocked(
                self.nearby_exit
            )

            label = (
                "E  進入傳送門"
                if unlocked
                else "E  尚未解鎖"
            )

            font = pygame.font.Font(None, 30)

            text = font.render(
                label,
                True,
                (255, 230, 170)
            )

            panel = pygame.Rect(
                0, 0,
                text.get_width() + 36,
                46
            )

            panel.center = (
                screen.get_width() // 2,
                screen.get_height() - 65
            )

            pygame.draw.rect(
                screen,
                (25, 20, 45),
                panel,
                border_radius=10
            )

            pygame.draw.rect(
                screen,
                (225, 185, 100),
                panel,
                2,
                border_radius=10
            )

            screen.blit(
                text,
                text.get_rect(center=panel.center)
            )

        # 操作訊息
        if self.message_timer > 0:

            font = pygame.font.Font(None, 26)

            text = font.render(
                self.message,
                True,
                (255, 235, 190)
            )

            panel = text.get_rect(
                center=(
                    screen.get_width() // 2,
                    45
                )
            ).inflate(30, 18)

            pygame.draw.rect(
                screen,
                (25, 20, 45),
                panel,
                border_radius=8
            )

            screen.blit(
                text,
                text.get_rect(center=panel.center)
            )

        # 傳送後的淡入效果
        if self.fade_alpha > 0:

            overlay = pygame.Surface(
                screen.get_size(),
                pygame.SRCALPHA
            )

            overlay.fill((
                12, 8, 30,
                int(self.fade_alpha)
            ))

            screen.blit(overlay, (0, 0))
