# V9.4.3 — 大廳畫面繪製錯誤修復

## 這次找到的確定錯誤

使用者在 Colab `tests/test_v9_4_2_hall_runtime.py` 回報：

`ValueError: too many values to unpack (expected 3)`，發生於 `systems/map_renderer.py` 的 `draw_decals()`。

V9.4.2 為分批載入，會將貼圖儲存成 `(sprite, x, y, fade_when_overlapping)` 四個值；繪製程式卻仍使用 `for sprite, x, y in self.decals`。此錯誤會使遊戲在 E 鍵進入大廳、素材載入完成後無法完成繪圖，呈現卡住或錯誤畫面。

## 修正範圍

- 修正 `draw_decals()` 同時支援舊三欄位及新版四欄位的貼圖資料格式；不移除貼圖、動畫或 NPC。
- 原版入口 E 鍵、返回與關閉、背包、技能頁、NPC 對話、商店、裝備、快捷列及七張地圖維持原樣。
- 保留 V9.4.2 的分批地圖/NPC 資產載入與錯誤提示流程。
- 新增 `tests/test_v9_4_3_decals.py`，確認大廳四片門貼圖完整繪製及舊格式相容。
- 保留 `tests/test_v9_4_2_hall_runtime.py`，在 Colab 中繼續做真實 Pygame 大廳繪製與返回測試，不跳過失敗。
- 遊戲版本標示：`V9.4.3 HALL DRAW FIX`。

## 驗證界線

在本地已執行全部不依賴 pygame 的既有回歸測試、程式語法、檔案完整性與新增貼圖測試。
目前環境無法安裝 Pygame，因此無法本地執行兩個 Pygame 圖形測試；新版 Colab 將在 GitHub 推送前執行 `test_v8_pygame_smoke.py` 與 `test_v9_4_2_hall_runtime.py`，若失敗則停止部署。GitHub Pages 遊玩仍需部署後確認。
